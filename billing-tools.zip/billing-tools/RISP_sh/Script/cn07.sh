#!/bin/bash
# source ./config.sh
# source ./risp_sql.sh
# bill_period="$2/$3"

cn07="select  a.* , b.totalcost as AWSconsole, (b.totalcost - a.totalmoney) as 差異   
FROM(
select bir.bill_period, bir.cno, bc.PayerAccountId, lpad(bir.LinkedAccountId,12,'0') as LinkedAccountId, bir.linkedaccountname, bir.totalmoney  
from bill_invoice_revenue bir  
left join bill_customer bc on (bc.LinkedAccountId = bir.LinkedAccountId) 
where bir.bill_period ='$bill_period' 
and bir.totalmoney > 0 
and bc.PayerAccountId = '579748889092'
) a  
left join (
select sum(bmcr.TotalCost) as TotalCost , LinkedAccountId   
FROM bill_monthly_cost_report bmcr   
where bill_period ='$bill_period'  
and PayerAccountId = '579748889092'
and RecordType = 'LinkedLineItem'  
group by LinkedAccountId
) b on b.LinkedAccountId = a.linkedaccountid    
order by b.LinkedAccountId"

mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 << EOF | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$cn07_CSV
$cn07
EOF

file=$cn07_CSV

cat $RISP_DIR$file > $RISP_DIR$file".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$file
cat $RISP_DIR$file".temp" >> $RISP_DIR$file
rm $RISP_DIR$file".temp"