C0000538_Before="SELECT a.bill_period , a.cno , a.linkedaccountid , a.linkedaccountname , a.totalmoney ,c.revenue AS 'Enterprise Support',b.totalcost AS AWSconsole, 
(b.totalcost - a.totalmoney - c.revenue) AS 差異, 
b.PayeraccountID
FROM (
SELECT bill_period, cno, LPAD(LinkedAccountId,12,'0') AS LinkedAccountId, linkedaccountname, totalmoney
FROM bill_invoice_revenue bir
WHERE bill_period = '$bill_period' 
AND totalmoney > 0 
AND cno = 'C0000538' 
) a
LEFT JOIN(
SELECT SUM(bmcr.TotalCost) AS TotalCost,PayeraccountID, LinkedAccountId
FROM bill_monthly_cost_report bmcr
WHERE bill_period = '$bill_period' 
AND payeraccountid = '832574149964' 
AND RecordType = 'LinkedLineItem'
GROUP BY PayeraccountID, LinkedAccountId 
) b ON a.linkedaccountid = b.linkedaccountid
LEFT JOIN(
SELECT LPAD(bi.linkedaccountid,12,'0') AS 'linkedaccount', bi.bill_product_name, SUM(bi.revenue) AS 'revenue'
FROM bill_item bi
WHERE bi.bill_period = '$bill_period' 
AND bi.payeraccountid = '832574149964' 
AND bi.bill_product_name = 'AWS Support (Enterprise)'
GROUP BY linkedaccount, bill_product_name 
) c ON a.LinkedAccountId = c.linkedaccount"

C0000538_After="select i.bill_period, i.cno, i.LinkedAccountId, i.LinkedAccountName,
i.totalmoney as  AWS服務費用,  
i.business_support_exec as 'ECV技術服務5%', 
i.totalmoney1 as 應繳總金額,
ri.ri 
from bill_invoice_revenue i 
left join(
select a.linkedaccountid, sum(a.TotalCost) as ri 
from bill_item a 
where a.bill_period='$bill_period' 
and substring(a.ItemDescription,1,31) = 'Sign up charge for subscription' 
group by a.linkedaccountid
) as ri on i.LinkedAccountId=ri.linkedaccountid 
where i.bill_period='$bill_period' 
and i.cno='C0000538'"

if  [ $output == "C0000538_Before" ]
then
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 << EOF | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$C0000538_B_CSV 
    $C0000538_Before
EOF
elif [ $output = "C0000538_After" ]
then
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 << EOF | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$C0000538_A_CSV 
    $C0000538_After
EOF
fi

if  [ $output == "C0000538_Before" ]
then
    file=$C0000538_B_CSV
    cat $RISP_DIR$file > $RISP_DIR$file".temp"
    printf "\xEF\xBB\xBF" > $RISP_DIR$file
    cat $RISP_DIR$file".temp" >> $RISP_DIR$file
    rm $RISP_DIR$file".temp"
elif [ $output = "C0000538_After" ]
then
    file=$C0000538_A_CSV
    cat $RISP_DIR$file > $RISP_DIR$file".temp"
    printf "\xEF\xBB\xBF" > $RISP_DIR$file
    cat $RISP_DIR$file".temp" >> $RISP_DIR$file
    rm $RISP_DIR$file".temp"
fi