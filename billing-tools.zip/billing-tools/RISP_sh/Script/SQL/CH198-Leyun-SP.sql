select bi.bill_period, bc.cno, bc.cname, bm.name, 
bi.payeraccountid, bi.linkedaccountid, bc.LinkedAccountName, 
bi.bill_product, bi.product_location, 
bi.product_instancetype, bi.os, 
-- 如果找SP，totalcost > 0。如果找RI，判斷totalcost=0然後抓Revenue。 
round(sum(bi.profit),2) as "節省數",
case when bi.linkedaccountid in ('309020745930','465618896709','750626855058','83122115652') then round(sum(bi.profit) * -0.66, 2)
else round(sum(bi.profit) * -0.6, 2)
end "應退金額"  


from bill_item bi 
left join bill_customer as bc on (bi.bill_customer = bc.id) 
left join bill_master as bm on (bc.ecloud_sales = bm.id) 

where bi.bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")  
and bc.hide = 'n' 
and bi.hide = 'n' 
and bi.riusagedescription in ('customer_used_sp_of_ecv')  
-- and bi.riusagedescription in (@RI, @SP)  
-- and bi.riusagedescription in (@RI)  
and bi.bill_product = 3 
and bi.payeraccountid = "072395932046"
and substring(bi.savingsplan_arn,23,12) in ('298687018628','318283988205','582111693318','930511469552','295651633298','503203804842','143529714568')
-- and bc.cno = '' 
-- and bi.linkedaccountid = '' 
group by bi.bill_period, bc.cno, bc.cname, bi.payeraccountid, bc.linkedaccountid, bi.bill_product, bi.bill_product,  
bi.product_location,bi.product_instancetype,bi.os

order by '節省數' desc;