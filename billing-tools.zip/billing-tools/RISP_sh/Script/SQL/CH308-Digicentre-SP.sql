select bi.bill_period, bc.cno, bc.cname, bm.name, 
bi.payeraccountid, bi.linkedaccountid, bc.LinkedAccountName, 
bi.bill_product, bi.product_location, 
bi.product_instancetype, bi.os, 
-- 如果找SP，totalcost > 0。如果找RI，判斷totalcost=0然後抓Revenue。 
round(sum(bi.totalcost),2) as "牌價",
round(sum(bi.profit),2) as "節省數",
round(sum(bi.profit) * -0.6, 2) as "應退金額"  


from bill_item bi 
left join bill_customer as bc on (bi.bill_customer = bc.id) 
left join bill_master as bm on (bc.ecloud_sales = bm.id) 

where bi.bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")  
and bc.hide = 'n' 
and bi.hide = 'n' 
and bi.riusagedescription in ('customer_used_sp_of_ecv')  
-- and bi.riusagedescription in (@RI, @SP)  
-- and bi.riusagedescription in (@RI)  
and bi.bill_product = 3 
and bi.totalcost > 0
and bi.payeraccountid = "036730985906"
and substring(bi.savingsplan_arn,23,12) in ('775178235604','158184228448','076842260316','031550695163','760578773652','021847923261')
-- and bc.cno = '' 
-- and bi.linkedaccountid = '' 
group by bi.bill_period, bc.cno, bc.cname, bi.payeraccountid, bc.linkedaccountid, bi.bill_product, bi.bill_product,  
bi.product_location,bi.product_instancetype,bi.os 

order by '節省數' desc;