select bi.bill_period, bc.cno, bc.cname, bm.name, 
bi.payeraccountid, bi.linkedaccountid, bc.LinkedAccountName, 
bi.bill_product, bi.product_location, 
bi.product_instancetype, bi.os, 
round(sum(bi.profit),2) as '節省數',
round(sum(bi.profit) * -0.5, 2) as '應退金額'

from bill_item bi 
left join bill_customer as bc on (bi.bill_customer = bc.id) 
left join bill_master as bm on (bc.ecloud_sales = bm.id) 

where bi.bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and bc.hide = 'n' 
and bi.hide = 'n' 
and bi.riusagedescription = 'customer_used_sp_of_ecv'  
and bi.bill_product = 3 
and bi.payeraccountid = '539968354237'
and SUBSTRING(bi.savingsplan_arn,23,12) = '539968354237'
and bc.cno = 'C0000461'

group by bi.bill_period, bc.cno, bc.cname, bi.payeraccountid, bc.linkedaccountid, bi.bill_product, bi.bill_product,  
bi.product_location,bi.product_instancetype,bi.os;