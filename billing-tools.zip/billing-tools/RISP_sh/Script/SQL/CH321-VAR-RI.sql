select bi.bill_period, bc.cno, bc.cname, bm.name, 
bi.payeraccountid, bi.linkedaccountid, bc.LinkedAccountName, 
bi.bill_product, bi.product_location, 
bi.product_instancetype, bi.os, 
round(sum(bi.revenue),2) as '牌價',
round(sum(bi.revenue) * -0.28,2) as '應退金額'

from bill_item bi 
left join bill_customer as bc on (bi.bill_customer = bc.id) 
left join bill_master as bm on (bc.ecloud_sales = bm.id) 

where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and bc.hide = 'n' 
and bi.hide = 'n' 

-- and bi.riusagedescription in ("customer_used_sp_of_ecv","others used ri of ecv") 
-- and bi.riusagedescription in ("others used ri of ecv") 
and bi.riusagedescription in ("customer_used_sp_of_ecv") 
and bi.bill_product = 3 
and bi.payeraccountid = '624240097397' 
and bi.linkedaccountid = '842753783225'
and product_instancetype in ('t3.nano','t3.micro','t2.micro','t3a.small','t3.small','t2.small',
't3a.medium','t3.medium','t3a.large','t3.large')
and bi.os = 'Linux' 
and bi.totalcost > 0

group by bi.bill_period, bc.cno, bc.cname, bm.name ,bi.payeraccountid, bc.linkedaccountid,bc.LinkedAccountName, 
bi.bill_product,bi.product_location,bi.product_instancetype,bi.os 

order by '牌價' desc;