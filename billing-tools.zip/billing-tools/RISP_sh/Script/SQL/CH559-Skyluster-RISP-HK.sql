select a.bill_period as BillMonth, a.PayerAccountId, a.linkedaccountid, a.cno, a.cname, a.LinkedAccountName, 
a.name, a.product_location, a.product_instancetype, a.os, 
a.totalcost as '牌價', 
(a.totalcost * -0.2) as '應退金額'

from ( 
select bi.bill_period, bc.cno, bc.cname, bm.name, 
bi.payeraccountid, bi.linkedaccountid, bc.LinkedAccountName, 
bi.bill_product, bi.product_location, 
bi.product_instancetype, bi.os, 
-- 如果找SP，totalcost > 0。如果找RI，判斷totalcost=0然後抓Revenue。 
round(sum(case when bi.totalcost > 0 then bi.totalcost when bi.totalcost = 0 then bi.revenue end),2) as 'totalcost'

from bill_item bi 
left join bill_customer as bc on (bi.bill_customer = bc.id) 
left join bill_master as bm on (bc.ecloud_sales = bm.id) 

where bi.bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and bc.hide = 'n' 
and bi.hide = 'n' 
and bi.riusagedescription in ('others used ri of ecv','customer_used_sp_of_ecv') 
-- and bi.riusagedescription in (@SP)  
-- and bi.riusagedescription in (@RI)  
and bi.bill_product = 3 
and bi.product_location = 'Asia Pacific (Hong Kong)' 
-- and bi.payeraccountid in  ('') 
-- and bc.cno = '' 
and bi.linkedaccountid = '828260729926' 

group by bi.bill_period, bc.cno, bc.cname, bi.payeraccountid, bc.linkedaccountid, bi.bill_product, bi.bill_product,  
bi.product_location,bi.product_instancetype,bi.os 
) a 

order by a.totalcost desc;