select bi.bill_period, bc.cno, bc.cname, bm.name, 
bi.payeraccountid, bi.linkedaccountid, bc.LinkedAccountName, 
bi.bill_product, bi.product_location, 
bi.product_instancetype, bi.os, 
round(sum(bi.revenue),2) as '牌價',
round(sum(bi.revenue) * -0.25,2) as '應退金額'
from bill_item bi 
left join bill_customer as bc on (bi.bill_customer = bc.id) 
left join bill_master as bm on (bc.ecloud_sales = bm.id) 
where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and bc.hide = 'n' 
and bi.hide = 'n' 
and bi.product_location = 'Asia Pacific (Tokyo)'
-- and bi.riusagedescription in ("customer_used_sp_of_ecv","others used ri of ecv") 
-- and bi.riusagedescription in ("others used ri of ecv") 
and bi.riusagedescription in ("customer_used_sp_of_ecv") 
and bi.bill_product = 3 
and bi.payeraccountid = '769053800601' 
and bi.linkedaccountid = '789943651249' 
and bi.product_instancetype in (
	'c5.4xlarge','c5.large',
    'c5a.4xlarge',
	'r5.large',
    't2.medium',
	't3.large','t3.medium','t3.small',
    't3a.large'
    )
and bi.os = 'Linux' 
and bi.totalcost > 0
group by product_instancetype
order by '牌價' desc;