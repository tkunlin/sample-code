 select bi.bill_period as BillMonth,
        bi.payeraccountid,
        bi.linkedaccountid,
        bc.cno, 
        bc.cname,
        bc.LinkedAccountName, 
        bm.name,
        bi.product_location,
        bi.product_instancetype, 
        bi.os,
        round(sum(bi.profit),2) as '節省數',
        (round(sum(bi.profit),2) * -0.6) as '應退金額'
 
-- 如果找SP，totalcost > 0。如果找RI，判斷totalcost=0然後抓Revenue。
-- round(sum(case when bi.totalcost > 0 then bi.totalcost when bi.totalcost = 0 then bi.revenue end),2) as '牌價'
-- ('牌價' * -0.22) as '應退金額'
-- round(sum(bi.profit),2) as "profit"
 
from bill_item bi
left join bill_customer as bc on (bi.bill_customer = bc.id)
left join bill_master as bm on (bc.ecloud_sales = bm.id)

where bi.bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and bc.hide = 'n'
and bi.hide = 'n'
 
-- and bi.riusagedescription in ('others used ri of ecv')
-- and bi.riusagedescription in (@RI,@SP)
and bi.riusagedescription in ('customer_used_sp_of_ecv') 
 
and bi.payeraccountid = '742095137571'
and bc.cno = 'CH424'
and bi.linkedaccountid != '789943651249' 
and bi.bill_product = 3
and bi.os = 'Linux' 
and bi.totalcost > 0
 
group by bi.bill_period, bc.cno, bc.cname, bi.payeraccountid, bc.linkedaccountid, bi.bill_product, bi.bill_product, 
bi.product_location,bi.product_instancetype,bi.os
 
order by bi.bill_period, bc.cno, bc.cname, bi.payeraccountid, bi.linkedaccountid;