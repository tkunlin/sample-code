# main_check_report.sh
## This script is used for exporting RISP customize report and checking billing items.
#Update 2022/05/03 -by Eva.Yang
1. How to use this script?
* bash main_check_report.sh Prod (Yaer/Month) (output)
    1. Prod : Production Enviroment
    2. (Year) : Current year
    3. (Month) : Billing month
    4. (output) : 
        1. costcheck : Exporting costcheck report for checking item.
        2. Joan : Exporting Joan customize report when billing day.
        3. C0000538_Before : Exporting C0000538 customize report when billing day.
        4. C0000538_After : Exporting C0000538 customize report after billing day.
        5. cn07 : Exporting cn07 customize report when billing day.
        6. RISP :  Exporting RISP customize report when billing day.
        7. INVOICE : Exporting bill invoice compare report when 5th.
* Example : bash main_check_report.sh Prod 2022/04 costcheck
2. Report type is csv file.
---
# update_sql_hk33.sh
## This script is used for hide Savings Plans on payer account hk33.
1. How to use this script? 
* bash update_sql_hk33.sh Prod (bill_period)
* ex: bash update_sql_hk33.sh 2022/04