#/bin/bash
#-*- coding: utf-8 -*-
#exit-on-error mode
set -e 

# Load Configuartion
echo "[INFO] Start time : $(date "+%Y-%b-%d %H:%M:%S")"

#CH559-RISP
# mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$CH559_SQL | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$CH559_CSV
# cat $RISP_DIR$CH559_CSV > $RISP_DIR$CH559_CSV".temp"
# printf "\xEF\xBB\xBF" > $RISP_DIR$CH559_CSV
# cat $RISP_DIR$CH559_CSV".temp" >> $RISP_DIR$CH559_CSV
# rm $RISP_DIR$CH559_CSV".temp"
# echo "CH559-RISP report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#C0000666-RI(2023/02 end)
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$C0000666_SQL | sed 's/,/\ /g' | sed 's/\t/,/g'> $RISP_DIR$C0000666_CSV
cat $RISP_DIR$C0000666_CSV > $RISP_DIR$C0000666_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$C0000666_CSV
cat $RISP_DIR$C0000666_CSV".temp" >> $RISP_DIR$C0000666_CSV
rm $RISP_DIR$C0000666_CSV".temp"
echo "C0000666-RI report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#CH424-RI
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$CH424_SQL | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$CH424_A_CSV
cat $RISP_DIR$CH424_A_CSV > $RISP_DIR$CH424_A_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$CH424_A_CSV
cat $RISP_DIR$CH424_A_CSV".temp" >> $RISP_DIR$CH424_A_CSV
rm $RISP_DIR$CH424_A_CSV".temp"
echo "CH424-RI report is alreay export! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#CH424-789943651249-RISP
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8  < $SQL_DIR$CH424_78_SQL | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$CH424_B_CSV
cat $RISP_DIR$CH424_B_CSV > $RISP_DIR$CH424_B_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$CH424_B_CSV
cat $RISP_DIR$CH424_B_CSV".temp" >> $RISP_DIR$CH424_B_CSV
rm $RISP_DIR$CH424_B_CSV".temp"
echo "789943651249-RISP report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#CH596-RI
# mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$CH596_SQL | sed 's/,/\ /g' | sed 's/\t/,/g'> $RISP_DIR$CH596_CSV
# cat $RISP_DIR$CH596_CSV > $RISP_DIR$CH596_CSV".temp"
# printf "\xEF\xBB\xBF" > $RISP_DIR$CH596_CSV
# cat $RISP_DIR$CH596_CSV".temp" >> $RISP_DIR$CH596_CSV
# rm $RISP_DIR$CH596_CSV".temp"
# echo "CH596-RI report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#CH321-VAR-RI
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$CH321_SQL | sed 's/,/\ /g' | sed 's/\t/,/g'> $RISP_DIR$CH321_CSV
cat $RISP_DIR$CH321_CSV > $RISP_DIR$CH321_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$CH321_CSV
cat $RISP_DIR$CH321_CSV".temp" >> $RISP_DIR$CH321_CSV
rm $RISP_DIR$CH321_CSV".temp"
echo "CH321-VAR-RI report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#CH816-AmazingTalker-RI
# mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$CH816_SQL | sed 's/,/\ /g' | sed 's/\t/,/g'> $RISP_DIR$CH816_CSV
# cat $RISP_DIR$CH816_CSV > $RISP_DIR$CH816_CSV".temp"
# printf "\xEF\xBB\xBF" > $RISP_DIR$CH816_CSV
# cat $RISP_DIR$CH816_CSV".temp" >> $RISP_DIR$CH816_CSV
# rm $RISP_DIR$CH816_CSV".temp"
# echo "CH816-AmazingTalker-RI report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#CH187-SP
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$CH187_SQL | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$CH187_CSV
cat $RISP_DIR$CH187_CSV > $RISP_DIR$CH187_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$CH187_CSV
cat $RISP_DIR$CH187_CSV".temp" >> $RISP_DIR$CH187_CSV
rm $RISP_DIR$CH187_CSV".temp"
echo "CH187-SP report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#CH308-SP
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$CH308_SQL | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$CH308_CSV
cat $RISP_DIR$CH308_CSV > $RISP_DIR$CH308_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$CH308_CSV
cat $RISP_DIR$CH308_CSV".temp" >> $RISP_DIR$CH308_CSV
rm $RISP_DIR$CH308_CSV".temp"
echo "CH308-SP report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

#C0000338-SP
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$C0000338_SQL | sed 's/,/\ /g' | sed 's/\t/,/g'> $RISP_DIR$C0000338_CSV
cat $RISP_DIR$C0000338_CSV > $RISP_DIR$C0000338_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$C0000338_CSV
cat $RISP_DIR$C0000338_CSV".temp" >> $RISP_DIR$C0000338_CSV
rm $RISP_DIR$C0000338_CSV".temp"
echo "C0000338-SP report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"


#CH198-SP
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$CH198_SQL | sed 's/,/\ /g' | sed 's/\t/,/g'> $RISP_DIR$CH198_CSV
cat $RISP_DIR$CH198_CSV > $RISP_DIR$CH198_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$CH198_CSV
cat $RISP_DIR$CH198_CSV".temp" >> $RISP_DIR$CH198_CSV
rm $RISP_DIR$CH198_CSV".temp"
echo "CH198-SP report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"

echo "[INFO] End time : $(date "+%Y-%b-%d %H:%M:%S")"

#C0000461-SP
mysql -h $HOST  -P3306 -u$USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 < $SQL_DIR$C0000461_SQL | sed 's/,/\ /g' | sed 's/\t/,/g'> $RISP_DIR$C0000461_CSV
cat $RISP_DIR$C0000461_CSV > $RISP_DIR$C0000461_CSV".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$C0000461_CSV
cat $RISP_DIR$C0000461_CSV".temp" >> $RISP_DIR$C0000461_CSV
rm $RISP_DIR$C0000461_CSV".temp"
echo "C0000461-SP report is alredy exported! Time:$(date "+%Y-%b-%d %H:%M:%S")"
