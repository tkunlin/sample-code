cost="SELECT a.PayerAccountId AS ItemPayer, b.PayerAccountId AS MonthlyPayer, a.TotalCost_Item, b.TotalCost_Monthly, a.TotalCost_Item - b.TotalCost_Monthly AS 'Diff' 
FROM 
(SELECT a.PayerAccountId, round(sum(a.TotalCost), 4) AS TotalCost_Item 
FROM bill_item a 
WHERE a.bill_period = '$bill_period' 
GROUP BY a.PayerAccountId) a 
LEFT OUTER JOIN 
(SELECT a.PayerAccountId, round(sum(a.TotalCost), 4) AS TotalCost_Monthly 
FROM bill_monthly_cost_report a 
WHERE a.bill_period = '$bill_period'  AND a.RecordType = 'LinkedLineItem' 
GROUP BY a.PayerAccountId) b ON a.PayerAccountId = b.PayerAccountId "
mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 << EOF | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$costcheck_CSV
$cost
EOF

file=$costcheck_CSV

cat $RISP_DIR$file > $RISP_DIR$file".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$file
cat $RISP_DIR$file".temp" >> $RISP_DIR$file
rm $RISP_DIR$file".temp"