#/bin/bash

#Logger date&time
LOG_DATE_CMD='date "+%Y-%b-%d %H:%M:%S"'

#File date&time
y=$(date +%Y)
m=$(date +%m -d "$date")
d=$(date +%d -d "$date")
date=$(date -I)

#Parameter Store
# HOST=$(aws ssm get-parameter --name "/"$1"/Billing/DB/mysql-replica-endpoint" --region us-west-2 | jq --raw-output ".Parameter.Value")
HOST=$(aws ssm get-parameter --name "/"$1"/Billing/DB/mysql-endpoint" --region us-west-2 | jq --raw-output ".Parameter.Value")
USER=$(aws ssm get-parameter --name "/"$1"/Billing/DB/mysql-user" --region us-west-2 | jq --raw-output ".Parameter.Value")
PASSWORD=$(aws ssm get-parameter --name "/"$1"/Billing/DB/mysql-pwd" --region us-west-2 | jq --raw-output ".Parameter.Value")
DBNAME=$(aws ssm get-parameter --name "/"$1"/Billing/DB/mysql-db" --region us-west-2 | jq --raw-output ".Parameter.Value")