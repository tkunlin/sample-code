# source ./config.sh
# source ./risp_sql.sh
# bill_period="$2/$3"

Joan="SELECT  SALES.* FROM (
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'EC2(without Spot)' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =3
-- AND usagetype not like '%Datatransfer%' 
-- AND usagetype not like '%EBS:%' 
-- AND usagetype NOT like '%NAT%' 
-- AND usagetype NOT like '%Spot%'
-- AND usagetype NOT like '%ElasticIP:%'
-- group by linkedaccountid
--   union all  
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'ElasticIP' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =3
-- AND usagetype not like '%Datatransfer%' 
-- AND usagetype  like '%ElasticIP:%'
-- group by linkedaccountid
--   union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Load Balacne' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =532
-- AND usagetype not like '%Datatransfer%'
-- group by linkedaccountid
--   union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'NAT Gateway' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =3
-- AND usagetype  like '%Nat%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'EBS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =3
-- and usagetype like '%EBS:%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Data Transfer' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- and hide='n'
-- AND lineitem_type NOT IN ('Tax','Credit')
-- AND usagetype like '%Datatransfer%'
-- and bill_product_name not in ('Amazon CloudFront')
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'EKS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =197
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'ES' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =53
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'ElastiCache' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =11
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'GA' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =256
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'ECR' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =67
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Cloudwatch' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =31
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'S3' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =5
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Kinesis' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product  in (33,68,81,152)
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'RDS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (124,529)
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Route 53' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =7
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Athena' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =92
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Codebuild' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =98
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'DynamoDB' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (25,143)
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Lambda' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (39)
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Quicksight' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (82)
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Registrar' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (61)
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Comprehend' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (139,249)
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- union all 
-- select 'Lightpaw' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Translate' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('692199941127') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (182)
-- and usagetype not like '%Datatransfer%'
-- group by linkedaccountid
-- UNION ALL 
-- select 'Lightpaw' CORP,a.PayerAccountId ,a.linkedaccountid ,LinkedAccountName,'月總計' Serverlist, totalmoney1 from bill_invoice_revenue a
-- where bill_period ='$bill_period' 
-- and linkedaccountid in (select LinkedAccountId from bill_customer where PayerAccountId in ('692199941127') )
-- group by linkedaccountid
-- union ALL
-- select '火溶信息' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'EC2' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('200137121045') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =3
-- AND usagetype not like '%Datatransfer%' 
-- AND usagetype not like '%EBS:%' 
-- AND usagetype NOT like '%NAT%' 
-- AND usagetype NOT like '%Spot%'
-- and  reservation_arn  =''
-- group by linkedaccountid
-- UNION ALL
-- select '火溶信息' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'RDS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('200137121045') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (124,529)
-- and usagetype not like '%Datatransfer%'
-- AND reservation_arn  =''
-- group by linkedaccountid
-- UNION ALL 
-- select '火溶信息' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'预留EC2' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('200137121045') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =3
-- AND usagetype not like '%Datatransfer%' 
-- AND usagetype not like '%EBS:%' 
-- AND usagetype NOT like '%NAT%' 
-- AND usagetype NOT like '%Spot%'
-- and  reservation_arn  <>''
-- group by linkedaccountid
-- UNION ALL 
-- select '火溶信息' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'预留RDS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('200137121045') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product in (124,529)
-- and usagetype not like '%Datatransfer%'
-- AND reservation_arn  <>''   
-- group by linkedaccountid
-- union all
-- select '火溶信息' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Data Trasfer' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and PayerAccountId in ('200137121045') and PayerAccountId<> linkedaccountid
-- and hide='n'
-- AND lineitem_type NOT IN ('Tax','Credit')
-- AND usagetype like '%Datatransfer%'
-- and bill_product_name not in ('Amazon CloudFront')
-- group by linkedaccountid
-- UNION ALL 
-- select '火溶信息' CORP,a.PayerAccountId ,a.linkedaccountid ,LinkedAccountName,'月總計' Serverlist, totalmoney1 from bill_invoice_revenue a
-- where bill_period ='$bill_period' 
-- and linkedaccountid in (select LinkedAccountId from bill_customer where PayerAccountId in ('200137121045') )
-- group by linkedaccountid
-- union all
-- select 'Neocraft' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'EC2' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and linkedaccountid in ('959132435257', '625454956545', '825466537769', '172715622412')
-- AND lineitem_type not in ('Tax','Credit')
-- and hide='n'
-- and bill_product =3
-- AND usagetype not like '%Datatransfer%' 
-- AND usagetype not like '%EBS:%' 
-- AND usagetype NOT like '%NAT%' 
-- AND usagetype NOT like '%Spot%'
-- and usagetype NOT LIKE '%ElasticIP:%'
-- and  reservation_arn  =''
-- group by linkedaccountid
-- UNION ALL 
-- select 'Neocraft' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'预留EC2' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and linkedaccountid in ('959132435257', '625454956545', '825466537769', '172715622412')
-- AND lineitem_type NOT IN ('Tax','Credit')
-- and hide='n'
-- and bill_product =3
-- AND usagetype not like '%Datatransfer%' 
-- AND usagetype not like '%EBS:%' 
-- AND usagetype NOT like '%NAT%' 
-- AND usagetype NOT like '%Spot%'
-- and usagetype NOT LIKE '%ElasticIP:%'
-- and  reservation_arn  <>''
-- group by linkedaccountid
-- UNION ALL 
-- select 'Neocraft' CORP,PayerAccountId ,linkedaccountid  ,b.LinkedAccountName,'EBS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and linkedaccountid in ('959132435257', '625454956545', '825466537769', '172715622412')
-- AND lineitem_type not in ('Tax','Credit')
-- AND hide='n'
-- AND bill_product =3
-- AND usagetype like '%EBS%'
-- group by linkedaccountid
-- UNION ALL 
-- select 'Neocraft' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'RDS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and linkedaccountid in ('959132435257', '625454956545', '825466537769', '172715622412')
-- AND lineitem_type not in ('Tax','Credit')
-- and hide='n'
-- and bill_product in (124,529)
-- and usagetype  like '%RDS:%'
-- AND reservation_arn  =''
-- group by linkedaccountid
-- UNION ALL  
-- select 'Neocraft' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'预留RDS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period' 
-- and linkedaccountid in ('959132435257', '625454956545', '825466537769', '172715622412')
-- AND lineitem_type not in ('Tax','Credit')
-- and hide='n'
-- and bill_product in (124,529)
-- and usagetype  like '%Datatransfer%'
-- AND reservation_arn  <>''   
-- group by linkedaccountid
-- UNION ALL 
-- select 'Neocraft' CORP,a.PayerAccountId ,a.linkedaccountid ,LinkedAccountName,'月總計' Serverlist, totalmoney1 from bill_invoice_revenue a
-- where bill_period ='$bill_period' 
-- and linkedaccountid in ('959132435257', '625454956545', '825466537769', '172715622412')
-- group by linkedaccountid
-- union all
select 'Yostar' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'EC2' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period' 
and linkedaccountid in ('709016922719', '809501327402', '794608515269')
AND lineitem_type not in ('Tax','Credit')
and hide='n'
and bill_product =3
-- AND usagetype not like '%Datatransfer%' 
-- AND usagetype not like '%EBS:%' 
-- AND usagetype NOT like '%NAT%' 
-- AND usagetype NOT like '%Spot%'
and  reservation_arn  =''
group by linkedaccountid
union all 
select 'Yostar' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'预留EC2' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period' 
and linkedaccountid in ('709016922719', '809501327402', '794608515269')
AND lineitem_type not in ('Tax','Credit')
and hide='n'
and bill_product =3
-- AND usagetype not like '%Datatransfer%' 
-- AND usagetype not like '%EBS:%' 
-- AND usagetype NOT like '%NAT%' 
-- AND usagetype NOT like '%Spot%'
and  reservation_arn  <>''
group by linkedaccountid
UNION ALL 
select 'Yostar' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'RDS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period' 
and linkedaccountid in ('709016922719', '809501327402', '794608515269')
AND lineitem_type not in ('Tax','Credit')
and hide='n'
and bill_product in (124,529)
--  and usagetype not like '%RDS:%'
and itemdescription  like '%Aurora%'
AND reservation_arn  =''
group by linkedaccountid
UNION ALL 
select 'Yostar' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'预留RDS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period' 
and linkedaccountid in ('709016922719', '809501327402', '794608515269')
AND lineitem_type not in ('Tax','Credit')
and hide='n'
and bill_product in (124,529)
--  and usagetype not like '%Datatransfer%'
and itemdescription  like '%Aurora%'
AND reservation_arn  <>''   
group by linkedaccountid
UNION ALL 
select 'Yostar' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Aurora RDS' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period' 
and linkedaccountid in ('709016922719', '809501327402', '794608515269')
AND lineitem_type not in ('Tax','Credit')
and hide='n'
and bill_product in (124,529)
--  and usagetype not like '%RDS:%'
and itemdescription  like '%Aurora%'
AND reservation_arn  =''
group by linkedaccountid
UNION ALL 
select 'Yostar' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Aurora 预留RDS ' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a 
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period' 
and linkedaccountid in ('709016922719', '809501327402', '794608515269')
AND lineitem_type not in ('Tax','Credit')
and hide='n'
and bill_product in (124,529)
-- and usagetype not like '%Datatransfer%'
and itemdescription  like '%Aurora%'
AND reservation_arn  <>''   
group by linkedaccountid
UNION ALL 
select 'Yostar' CORP,a.PayerAccountId ,a.linkedaccountid ,LinkedAccountName,'月總計' Serverlist, totalmoney1 from bill_invoice_revenue a
where bill_period ='$bill_period' 
and linkedaccountid in ('709016922719', '809501327402', '794608515269')
group by linkedaccountid
union all
-- select 'RESTAR' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'EC2' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period'
-- and PayerAccountId in ('887417190410') and PayerAccountId<> linkedaccountid
-- AND lineitem_type NOT IN ('Credit')
-- and hide='n'
-- and bill_product =3
-- -- AND usagetype not like '%Datatransfer%' 
-- -- AND usagetype not like '%EBS:%' 
-- -- AND usagetype NOT like '%NAT%' 
-- -- AND usagetype NOT like '%Spot%'
-- group by linkedaccountid
-- UNION ALL 
-- select 'RESTAR' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'Data Transfer' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period'
-- and PayerAccountId in ('887417190410') and PayerAccountId<> linkedaccountid
-- and hide='n'
-- and bill_product =1
-- AND lineitem_type <>'Credit'
-- group by linkedaccountid
-- union all 
-- select 'RESTAR' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'CFRC' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
--  join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
-- where bill_period ='$bill_period'
-- and PayerAccountId in ('887417190410') and PayerAccountId<> linkedaccountid
-- AND lineitem_type not in ('Credit')
-- and hide='n'
-- and bill_product =4
-- group by linkedaccountid
-- UNION ALL 
-- select 'RESTAR' CORP,a.PayerAccountId ,a.linkedaccountid ,LinkedAccountName,'月總計' Serverlist, totalmoney1 from bill_invoice_revenue a
-- where bill_period ='$bill_period'
-- and linkedaccountid in (select LinkedAccountId from bill_customer where PayerAccountId in ('887417190410') )
-- group by linkedaccountid
-- union all
select '心动EDP' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'CFRC' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period'
and PayerAccountId in ('984924226255') and PayerAccountId<> linkedaccountid
AND lineitem_type not in ('Credit')
and hide='n'
and bill_product =4
group by linkedaccountid
UNION ALL 
select '心动EDP' CORP,a.PayerAccountId ,a.linkedaccountid ,LinkedAccountName,'月總計' Serverlist, totalmoney1 from bill_invoice_revenue a
where bill_period ='$bill_period'
and linkedaccountid in (select LinkedAccountId from bill_customer where PayerAccountId in ('984924226255') )
group by linkedaccountid
union all
select '心动網路CN114' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'CFRC' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period'
and PayerAccountId in ('485026233383') and PayerAccountId<> linkedaccountid
AND lineitem_type not in ('Credit')
and hide='n'
and bill_product =4
group by linkedaccountid
UNION ALL 
select '心动網路CN114' CORP,a.PayerAccountId ,a.linkedaccountid ,LinkedAccountName,'月總計' Serverlist, totalmoney1 from bill_invoice_revenue a
where bill_period ='$bill_period'
and linkedaccountid in (select LinkedAccountId from bill_customer where PayerAccountId in ('485026233383') )
group by linkedaccountid
union all
select '易玩CN115' CORP,PayerAccountId ,linkedaccountid ,b.LinkedAccountName,'CFRC' Serverlist,ROUND(sum(CASE WHEN unitprice = '' THEN totalcost ELSE unitprice * usagequantity END),2) Totalcost from bill_item a
 join (select  id,LinkedAccountName from bill_customer )b on a.bill_customer =b.id
where bill_period ='$bill_period'
and PayerAccountId in ('920418672866') and PayerAccountId<> linkedaccountid
AND lineitem_type not in ('Credit')
and hide='n'
and bill_product =4
group by linkedaccountid
UNION ALL 
select '易玩CN115' CORP,a.PayerAccountId ,a.linkedaccountid ,LinkedAccountName,'月總計' Serverlist, totalmoney1 from bill_invoice_revenue a
where bill_period ='$bill_period'
and linkedaccountid in (select LinkedAccountId from bill_customer where PayerAccountId in ('920418672866') )
group by linkedaccountid
)SALES
ORDER BY SALES.CORP,SALES.linkedaccountid,SALES.LinkedAccountName,Serverlist DESC"
mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 << EOF | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$joan_CSV 
$Joan
EOF

file=$joan_CSV

cat $RISP_DIR$file > $RISP_DIR$file".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$file
cat $RISP_DIR$file".temp" >> $RISP_DIR$file
rm $RISP_DIR$file".temp"

