source ./config.sh $1
bill_period="$2"
#執行hk33 Payer中Savings Plans的負數hide起來
update="update bill_item set hide = 'y' 
where bill_period = '$bill_period' 
and dop = 'y' 
and bill_customer in (select id from bill_customer where payeraccountid in (898290320991,229115906137))
and bill_product = 414 and change_master = 0;"

echo "[INFO] Start time : $(date "+%Y-%b-%d %H:%M:%S")"
mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME << EOF 
$update
EOF


#檢核SQL -> 確認hide欄位是否只有值 'Y'& 確認'套用On-Demand費用'欄位是否等於Console 'On-Demand spend equivalent' 的值
checkhide="select PayerAccountId,hide,sum(usagequantity*unitprice) '套用On-Demand費用' from bill_item
where bill_period = '$bill_period' 
and dop = 'y' 
and bill_customer in (select id from bill_customer where payeraccountid in (898290320991,229115906137))
and bill_product = 414 and change_master = 0
group by payeraccountid;"

mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 << EOF | sed 's/,/\ /g' | sed 's/\t/,/g' > ./checkhide.csv
$checkhide 
EOF
echo "Check hide result"
echo "[INFO] End time : $(date "+%Y-%b-%d %H:%M:%S")"