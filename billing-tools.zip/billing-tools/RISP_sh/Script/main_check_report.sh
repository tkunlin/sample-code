#!/bin/bash
#Check the Directory exists or not.
mkdir -p ./Reportcsv
source ./config.sh
source ./risp_sql.sh
bill_period="$2"
echo $bill_period
echo $y$m
output=$3
echo $output
if [ $output == "costcheck" ]
then
    echo "$(date "+%Y-%b-%d %H:%M:%S")  Starting to output CostCheck report."
    source ./costcheck.sh   
    echo "$(date "+%Y-%b-%d %H:%M:%S") Finishing output CostCheck report."
elif [ $output == "Joan" ]
then
    echo "$(date "+%Y-%b-%d %H:%M:%S")  Starting to output Joan report."
    source ./joan2.sh
    echo "$(date "+%Y-%b-%d %H:%M:%S") Finishing output Joan report."
elif [ $output == "C0000538_Before" ]
then
    echo "$(date "+%Y-%b-%d %H:%M:%S")  Starting to output C0000538_Before report."
    source ./C0000538.sh
    echo "$(date "+%Y-%b-%d %H:%M:%S") Finishing output C0000538_Before report."
elif [ $output == "C0000538_After" ]
then
    echo "$(date "+%Y-%b-%d %H:%M:%S")  Starting to output C0000538_After report."
    source ./C0000538.sh
    echo "$(date "+%Y-%b-%d %H:%M:%S") Finishing output C0000538_After report."
elif [ $output == "cn07" ]
then
    echo "$(date "+%Y-%b-%d %H:%M:%S")  Starting to output cn07 report."
    source ./cn07.sh
    echo "$(date "+%Y-%b-%d %H:%M:%S") Finishing output cn07 report."
elif [ $output == "RISP" ]
then
    echo "$(date "+%Y-%b-%d %H:%M:%S")  Starting to output RISP reports."
    source ./risp_report.sh
    echo "$(date "+%Y-%b-%d %H:%M:%S") Finishing output RISP reports."
elif [ $output == "INVOICE" ]
then
    echo "$(date "+%Y-%b-%d %H:%M:%S")  Starting to output bill and invoice compare report."
    source ./bill_invoice_compare_report.sh
    echo "$(date "+%Y-%b-%d %H:%M:%S") Finishing output bill and invoice compare report."
else
    echo "Please enter correct parameters"
fi