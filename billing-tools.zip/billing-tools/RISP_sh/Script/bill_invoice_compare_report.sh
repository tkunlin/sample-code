invoice="SELECT * FROM (
select c.bill_period,a.sap_cno ,a.cno,a.cname,c.cno old_cno, a.LinkedAccountId, a.LinkedAccountName , 
a.invoice_merge_no,b.invoice_no,b.invoice_amount,c.currency,c.totalmoney1*c.bill_rate 帳單未稅金額 ,(c.totalmoney1+c.tax)*c.bill_rate 帳單含稅金額,a.hide from bill_customer a
 LEFT JOIN 
 (Select bill_customer,invoice_no,invoice_amount from migration_bill_invoice_no where bill_period = '$bill_period') b 
on b.bill_customer = a.invoice_merge_no
 LEFT JOIN 
 ( Select bill_period,CNO,linkedaccountid ,currency ,totalmoney1 ,bill_rate ,tax
   from bill_invoice_revenue where bill_period='$bill_period' ) c 
on c.linkedaccountid=a.LinkedAccountId 
 where a.LinkedAccountId in 
 ( SELECT LinkedAccountId FROM bill_invoice_revenue bir  where bill_period ='$bill_period'  and  cno LIKE 'C%'  ) 
order by a.cno desc)DD WHERE cno<>''"
mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME --default-character-set=utf8 << EOF | sed 's/,/\ /g' | sed 's/\t/,/g' > $RISP_DIR$invoice_CSV
$invoice
EOF

file=$invoice_CSV

cat $RISP_DIR$file > $RISP_DIR$file".temp"
printf "\xEF\xBB\xBF" > $RISP_DIR$file
cat $RISP_DIR$file".temp" >> $RISP_DIR$file
rm $RISP_DIR$file".temp"