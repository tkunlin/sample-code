import boto3
import time
from lib import config
from lib.db import DB
from lib import ssm
import getopt
import sys
import json

class CURTask:
    def __init__(self, date, frequency, env):
        # auto scaling
        self.include = ['STATISTICS']
        if "dev" == env:
            if frequency=='Daily':
                self.auto_scaling_group_name = 'cur-daily-dev-group' # cur-stage-daily-asg => daily , cur-stage-asg => hourly
                self.desired_capacity = 10
                # ecs
                self.clusters = ['cur-dev']
                self.task_definition = 'billing-cur-daily-dev' # cur-stage => daily ,ecv-stage-cur-hourly => hourly
                self.launch_type = 'EC2'
                self.count = 10
                # sqs
                self.day = date
                self.frequent = 'd'  # 'd'=> daily ,'h' => hourly
                self.qurl = config.daily_sqs_dev # 'd'=> daily_sqs ,'h' => hourly_sqs
            else:
                self.auto_scaling_group_name = 'cur-hourly-dev-group' # cur-stage-daily-asg => daily , cur-stage-asg => hourly
                self.desired_capacity = 10
                # ecs
                self.clusters = ['cur-dev']
                self.task_definition = 'billing-cur-hourly-dev' # cur-stag => daily ,ecv-stage-cur-hourly => hourly
                self.launch_type = 'EC2'
                self.count = 10
                # sqs
                self.day = date
                self.frequent = 'h'  # 'd'=> daily ,'h' => hourly
                self.qurl = config.hourly_sqs_dev # 'd'=> daily_sqs ,'h' => hourly_sqs
        elif "stage" == env:
            if frequency=='Daily':
                self.auto_scaling_group_name = 'cur-daily-stage-group' # cur-stage-daily-asg => daily , cur-stage-asg => hourly
                self.desired_capacity = 10
                # ecs
                self.clusters = ['cur-stage']
                self.task_definition = 'billing-cur-daily-stage' # cur-stage => daily ,ecv-stage-cur-hourly => hourly
                self.launch_type = 'EC2'
                self.count = 10
                # sqs
                self.day = date
                self.frequent = 'd'  # 'd'=> daily ,'h' => hourly
                self.qurl = config.daily_sqs_stage # 'd'=> daily_sqs ,'h' => hourly_sqs
            else:
                self.auto_scaling_group_name = 'cur-hourly-stage-group' # cur-stage-daily-asg => daily , cur-stage-asg => hourly
                self.desired_capacity = 10
                # ecs
                self.clusters = ['cur-stage']
                self.task_definition = 'billing-cur-hourly-stage' # cur-stag => daily ,ecv-stage-cur-hourly => hourly
                self.launch_type = 'EC2'
                self.count = 10
                # sqs
                self.day = date
                self.frequent = 'h'  # 'd'=> daily ,'h' => hourly
                self.qurl = config.hourly_sqs_stage # 'd'=> daily_sqs ,'h' => hourly_sqs

    def launch_auto_scaling(self):
        client = boto3.client('autoscaling', region_name='us-west-2')
        response = client.set_desired_capacity(
            AutoScalingGroupName=self.auto_scaling_group_name,
            DesiredCapacity=self.desired_capacity
        )
        print("========== Auto Scaling Launched ==========")
        

    def check_ecs_registered_count(self):
        client = boto3.client('ecs', region_name='us-west-2')
        response = client.describe_clusters(
            clusters=self.clusters,
            include=self.include
        )
        print("========== Check ECS Registered => Current Count:{}==========".format(response['clusters'][0]['registeredContainerInstancesCount']))
        return response['clusters'][0]['registeredContainerInstancesCount']


    def generate_sqs(self):
        sqs = boto3.client("sqs", region_name='us-west-2')
        db = DB(endpoint="main", database=config.ecloud_database)
        res = db.execute("select account_no from bill_payer_account where hide = 'n';", have_result=True)['result']
        for item in res:
            account = item['account_no'].strip()
            msg = {
                "payeraccountid": account,
                "billing_date": self.day
            }
            msg = json.dumps(msg)
            res1 = sqs.send_message(
                QueueUrl=self.qurl,
                MessageBody=msg
            )
        print("========== SQS Generated {} ==========".format(len(res)))


    def run_ecs_task(self):
        client = boto3.client('ecs', region_name='us-west-2')
        response = client.run_task(
            cluster=self.clusters[0],
            count=self.count,
            launchType=self.launch_type,
            taskDefinition=self.task_definition
        )
        print(response)
        print("========== ECS Task Runnung  ==========")

    def process(self):
        self.launch_auto_scaling()
        self.generate_sqs()
        while self.check_ecs_registered_count() < self.desired_capacity:
            time.sleep(5)
        self.run_ecs_task()

if __name__ == "__main__":
    def help_text():
        print("auto_run_cur_task.py -d {YYYY/MM/DD} -f {d|h}")
    print(sys.argv)
    billing_date = None
    env="dev"
    argv = sys.argv[1:]
    # 處理參數
    try:
        opts, args = getopt.getopt(argv,"hd:f:e:")
    except getopt.GetoptError as e:
        help_text()
        sys.exit(2)
    print(opts)
    # 處理參數
    for opt, arg in opts:
        print(opt,arg)
        if opt == '-h':
            help_text()
            sys.exit()
        elif opt in ("-d"):
            billing_date = arg
        elif opt in ('-e'):
            env = arg
        elif opt in ('-f'):
            if arg == 'h':
                frequent = "Hourly"
            elif arg == 'd':
                frequent = "Daily"
            else:
                frequent = None
        else:
            help_text()
            sys.exit()
    
    if billing_date is None or frequent is None:
        # 參數有誤
        help_text()
        sys.exit(2)
    else:
        # 開始處理
        task = CURTask(billing_date, frequent, env)
        task.process()
