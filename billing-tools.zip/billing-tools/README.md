1. download cur backup file 
    aws s3 cp s3://ecv-us-west-2-dev/cur_hourly/YYYY-mm-dd/cur_{linkedaccountid}_{payeraccountid}.sql . --profile tw03

2. insert cur.sql into stage database

3. repo: https://git-codecommit.us-west-2.amazonaws.com/v1/repos/ecv-ecs-cur-daily-repo
    1. eidt CFG.py to stage db
    2. python3.6 ri_suggestion_sql_linkedaccountid.py -l {linkedaccountid} -d YYYY/MM/DD

4. run billing tools
    1. edit ri_recommendation_report.py endpoint to https://service-stage.ecloudvalley.com/
    2. run