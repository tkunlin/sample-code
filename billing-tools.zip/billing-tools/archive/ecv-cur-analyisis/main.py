from lib.api_caller import AWSAPICaller
from datetime import datetime
import pandas as pd

def get_s3_cur_size(account_id, s3_bucket_name, s3_prefix) -> int:

    try:
        cur_size = 0
        s3_client = AWSAPICaller(account_id, 's3').get_aws_client()
        bucket = s3_client.resource('s3').Bucket(s3_bucket_name)

        for s3_obj in bucket.objects.filter(Prefix=s3_prefix):
            cur_size = cur_size + s3_obj.size

        # Byte => Megabyte
        cur_size = round((cur_size / 1024 / 1024), 2)

    except Exception as e:
        print(e)
        cur_size = None

    print(account_id, cur_size)
    return cur_size


def parse_cur_log(cur_log_name: str) -> dict:
    # read payer account id csv. TODO: read from db
    csv_file_name = 'payer_account_list.csv'
    payer_df = pd.read_csv(csv_file_name)
    payer_df = payer_df[['account_name', 'account_no', 's3_bucket']]
    payer_df['account_no'] = payer_df['account_no'].astype(str)

    #  cur log data cleansing
    cur_log_df = pd.read_csv(f'./input/{cur_log_name}')
    cur_log_df.rename(columns={'start time':'starttime', 'end time':'endtime'}, inplace=True)
    cur_log_df = cur_log_df[['project', 'starttime', 'endtime']]
    cur_log_df['accountid'] = cur_log_df.apply(lambda row: str(row.project.split('-')[2]), axis=1)
    cur_log_df['exe_time(s)'] = cur_log_df.apply(lambda row: (row.endtime - row.starttime) / 1000, axis=1)
    cur_log_df.drop(['project', 'starttime', 'endtime'], axis=1, inplace=True)
    
    result_df = payer_df.merge(cur_log_df, how='inner', left_on='account_no', right_on='accountid')
    result = result_df.to_dict('records')

    return result

def request_input():
    try:
        cur_log_name = input("Type CUR log file name(e.g. CUR prod daily_20220223.csv): ")
        cur_date_preiod = input("Type CUR date period(e.g. 20220101-20220201): ")
    except Exception as e:
        print(e)
        exit()
    
    return cur_log_name, cur_date_preiod
    
def main():
    cur_log_name, cur_date_preiod = request_input()
    cur_exe_time = parse_cur_log(cur_log_name)
    s3_prefix = f'CostUsageReportHourly/CostUsageReportHourly/{cur_date_preiod}/'

    print('accountid, size(MB)')
    for index, account in enumerate(cur_exe_time):
        cur_size = get_s3_cur_size(
            account['account_no'], account['s3_bucket'], s3_prefix)
        if cur_size is None:
            continue
        cur_exe_time[index]['cur_size(MB)'] = cur_size

    result_df = pd.DataFrame(cur_exe_time)

    yyyymmdd = datetime.today().strftime('%Y%m%d')
    result_df.to_csv(f'./output/cur_size_time_{cur_date_preiod}_{yyyymmdd}.csv')

main()