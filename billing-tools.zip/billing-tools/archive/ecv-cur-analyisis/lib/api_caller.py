from lib.auth import get_auth

class AWSAPICaller: 
    def __init__(self, account_id, service_name):
        self.account_id = account_id
        self.service_name = service_name

    def get_aws_client(self):
        try:
            auth = get_auth(self.account_id)
        except Exception as e:
            print(e)
            return False
        return auth