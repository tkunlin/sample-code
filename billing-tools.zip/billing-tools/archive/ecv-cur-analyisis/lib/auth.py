import boto3
import json

def catch_invalid_account(response):
    aws_access_key_id=response['credential'][0]['AccessKeyId']
    aws_secret_access_key=response['credential'][0]['SecretAccessKey']
    aws_session_token=response['credential'][0]['SessionToken']
    
    if not aws_access_key_id or not aws_secret_access_key or not aws_session_token:
        return False
    return True

def get_auth(account_id_list: list):
    aws_lambda = boto3.client('lambda', region_name='us-west-2')
    
    arg = {
        'aws_payer_account_id': [account_id_list],
        "origin": "ecv-billing-cur"
    }
    re = str.encode(json.dumps(arg))
    try:
        response = aws_lambda.invoke(
            FunctionName = 'ecv-assume-role',
            Payload = re
        )
        response = response['Payload'].read()
        response = json.loads(response)
        
        if not catch_invalid_account(response):
            raise ValueError

        auth = boto3.session.Session(
            aws_access_key_id=response['credential'][0]['AccessKeyId'],
            aws_secret_access_key=response['credential'][0]['SecretAccessKey'],
            aws_session_token=response['credential'][0]['SessionToken'],
        )
        return auth
    except:
        return False