from lib.ssm import get_parameter
import pymysql

class DataBase:
    def __init__(self, database="ecloud", endpoint = "main"):
        self.host = get_parameter('/Stage/DB/mysql-endpoint')
        self.user =get_parameter('/Stage/DB/mysql-user')
        self.password = get_parameter('/Stage/DB/mysql-pwd')
        self.db = database
        self.connect()

    def connect(self):
        self.conn = pymysql.connect(host=self.host, user=self.user, password=self.password, db=self.db, local_infile = True, charset='utf8')
        self.cur = self.conn.cursor( pymysql.cursors.DictCursor )
                
    def reconnect(self):
        try:
            self.conn.close()
            self.connect()
        except Exception as e:
            print(e)

    def execute(self, sql, insert_list = None, have_result = False, get_cursor = False): 
        try:
            if insert_list == None:
                self.cur.execute (sql)
            else:
                self.cur.execute(sql,tuple(insert_list))
            self.conn.commit()
        except (AttributeError, pymysql.OperationalError):
            self.reconnect()
            ## and try again
            try:
                if insert_list == None:
                    self.execute(sql)
                else:
                    self.execute(sql, tuple(insert_list))
            except Exception as e:
                self.conn.rollback()
                return {'success':False, 'err': str(e)}
        except Exception as e:
            if 'Lock wait timeout exceeded' in str(e):
                self.reconnect()
                try:
                    if insert_list == None:
                        self.execute (sql)
                    else:
                        self.execute(sql,tuple(insert_list))
                except:
                    self.conn.rollback()
                    return {'success':False, 'err': str(e)}
            else:
                self.conn.rollback()
                return {'success':False, 'err': str(e)}
        
        if have_result:
            ans = self.cur.fetchall()
            dict_result = []
            for row in ans:
                dict_result.append(dict(row))
            return {'success':True, 'result' : dict_result }
        elif get_cursor:
            return {'success':True, 'cursor':self.cur}
        else:
            return {'success':True}


    def close(self):
        try:
            self.conn.close()
        except Exception as e:
            print(e)
