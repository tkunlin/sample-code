from lib.db import DataBase

def get_column_data_from_linkedaccount(linked_account_id, return_column):
    
    if linked_account_id == ' ':
        return " "
    if linked_account_id[0] == "0":
        linked_account_id = linked_account_id[1:]
        
    db = DataBase(endpoint='main', database='ecloud')
    res = db.execute("SELECT LinkedAccountId, cname, cno FROM bill_customer where LinkedAccountId = '{}'".format(
        linked_account_id), have_result=True)
  
    if res['result']:
        return res['result'][0][return_column]