import boto3

def get_parameter(name):
    try:
        ssm = boto3.client('ssm', region_name = 'us-west-2')
        res = ssm.get_parameter(Name = name)
        return res['Parameter']['Value']
    except:
        return False

# host = get_parameter('/Stage/DB/mysql-endpoint')
# user = get_parameter('/Stage/DB/mysql-user')
# password = get_parameter('/Stage/DB/mysql-pwd')