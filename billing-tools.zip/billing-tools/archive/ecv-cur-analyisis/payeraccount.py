from lib.auth import get_auth

class PayerAccount:
    def __init__(self, account_id):
        self.id = account_id
        self.client = self.get_aws_client()

    def get_aws_client(self):
        try:
            auth = get_auth(self.id)
            client = auth.client('ce')
        except Exception as e:
            print(e)
            return False

        return client