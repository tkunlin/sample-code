import boto3
import logging
import sys
import json
import botocore
from lib import config


# Set up a basic configuration for the logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s]: %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)


REGION = config.AWS_DEFAULT_REGION

class AwsSqsClient():
    def __init__(self, queue_url, region_name=REGION, ) -> None:
        self.sqs = boto3.client('sqs', region_name=region_name)
        self.sqs_url = queue_url

    def receive_message(self, MAX_NUMBER_OF_MESSAGES=1):
        MAX_NUMBER_OF_MESSAGES = 1 if not MAX_NUMBER_OF_MESSAGES else MAX_NUMBER_OF_MESSAGES
        logger.info(f"Retrieve message from {self.sqs_url}")
        try:
            response = self.sqs.receive_message(
                QueueUrl=self.sqs_url,
                AttributeNames=[
                    'SentTimestamp'
                ],
                MaxNumberOfMessages=MAX_NUMBER_OF_MESSAGES,
                MessageAttributeNames=[
                    'All'
                ],
                VisibilityTimeout=20,
                WaitTimeSeconds=20
            )
            if response.get('Messages') is None:
                logger.info(f"Empty Message in Queue. Queue URL: {self.sqs_url}")
                sys.exit(0)
            else:
                logger.info(f"Message received: {response['Messages'][0]['Body']}")
                message = response['Messages'][0]
                receipt_handle = message['ReceiptHandle']
                return response['Messages'][0]['Body'], receipt_handle
        except Exception as e:
            logger.error(f"Failed to receive message")
            logger.error(response)
            raise e

    def delete_message(self, receipt_handle: str) -> None:
        result = self.sqs.delete_message(
            QueueUrl=self.sqs_url,
            ReceiptHandle=receipt_handle
        )
        logger.info(f"Message deleted")
    
    def send_message(self, msg):
        res = self.sqs.send_message(
            QueueUrl=self.sqs_url,
            MessageBody=json.dumps(msg)
        )

class AwsEcsClient():
    def __init__(self, cluster, region_name=REGION, ) -> None:
        self.ecs = boto3.client('ecs', region_name=region_name)
        self.cluster = cluster

    def check_task_status_running(self):
        response = self.ecs.list_tasks(
            cluster= self.cluster,
            desiredStatus='RUNNING'
        )

        task_arns = response['taskArns']

        return task_arns

