import os
import boto3
import logging
import sys
import time
import random
from botocore.exceptions import ClientError
import datetime


logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))

try:
    ENV = os.environ['ENV']
    AWS_DEFAULT_REGION = 'us-west-2'
except KeyError as e:
    logger.error(f"Environment Variable Not Found. Key: ENV")
    sys.exit(-1)

class Toolkit:
    @staticmethod
    def get_parameter(name, max_retry_count=5):
        ssm = boto3.client('ssm',region_name = AWS_DEFAULT_REGION)
        retry_count = 0

        while retry_count <= max_retry_count:
            try:
                res = ssm.get_parameter(Name=name)
                value = res['Parameter']['Value']
                return value
            except ClientError as e:
                logger.error(f"{e}, retry => {retry_count}")
                retry_count += 1
                time.sleep(random.randint(1, 5))
        else:    
            raise Exception(f'Failed to get non-empty parameter {name} after {max_retry_count} attempts')
    
    @staticmethod
    def get_transformed_bill_period():
        # Get the current day of the month
        current_day = datetime.datetime.now().day
        
        # Check if the current day is less than or equal to 6
        if current_day <= 6:
            # Calculate the previous month
            previous_month = datetime.datetime.now() - datetime.timedelta(days=30)
            # Format the period as "Y/m"
            bill_priod = previous_month.strftime("%Y/%m")
        else:
            # Format the period as "Y/m" for the current month
            bill_priod = datetime.datetime.now().strftime("%Y/%m")
        return bill_priod


host = Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-endpoint")
user = Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-user")
password = Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-pwd")

jobhost = Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-endpoint")
jobuser = Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-user")
jobpassword = Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-pwd")

atlas_database = 'atlas'
ecloud_database = Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-db")

assume_endpoint = Toolkit.get_parameter(f"/{ENV}/Billing/Lambda/AssumeRole/Api/Endpoint")
assume_key = Toolkit.get_parameter(f"/{ENV}/Billing/Lambda/AssumeRole/Api/Key")

s3_bill_invoice_bucket = Toolkit.get_parameter(f"/{ENV}/Billing/S3/invoice/bucket-name")

## TABLE
BILL_ITEM = "bill_item"
BILL_INVOICE = "bill_invoice_revenue"
BILL_CUSTOMER = "bill_customer"

DIRNAME=os.getcwd()

PDF_SQS_URL  = Toolkit.get_parameter(f"/{os.environ['ENV']}/Billing/CurJob/sqs-url")
REV_CNO_SQS_URL = Toolkit.get_parameter(f"/{os.environ['ENV']}/Billing/CurJob/Rev-cno-sqs-url")
S3_PDF_OUTPUT = Toolkit.get_parameter(f"/{os.environ['ENV']}/Billing/S3/invoice/bucket-name")
CHECK_PDF_SQS_URL = Toolkit.get_parameter(f"/{os.environ['ENV']}/Billing/CurJob/Rev-check-pdf-sqs-url")


target_db_dict = {
    'user': Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-user"),
    'password': Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-pwd"),
    'host': Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-endpoint"),
    'db': Toolkit.get_parameter(f"/{ENV}/Billing/DB/mysql-db")
}

# prod_db = DB(host=target_db_dict['host'], user=target_db_dict['user'], password=target_db_dict['password'], db=target_db_dict['db'])