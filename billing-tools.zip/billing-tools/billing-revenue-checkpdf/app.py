import logging
import boto3
import sys
from lib import config, timer
from lib.config import Toolkit
import os
import json
from botocore.exceptions import ClientError
import datetime
import pytz
from lib.aws_resource import *

# Set up a basic configuration for the logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s]: %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)


def main():
    try:
        # sqs client
        sqs = AwsSqsClient(config.CHECK_PDF_SQS_URL)

        # record processing cno
        process_cno = []
        while True:
            try:
            
                # Receive msg
                msg, receipt_handle = sqs.receive_message() 
                sqs.delete_message(receipt_handle)

                """
                info = cno|bill_period
                """
                
                cno = msg.split('|')[0]
                bill_period = msg.split('|')[1]

                if cno in process_cno:
                    continue

                logger.info(f"Processing cno => {cno} , bill_period => {bill_period}")
                os.system(f'python3 compare_pdf.py {bill_period} {cno}')
                process_cno.append(cno)


            except Exception as e:  
                logger.info(f"Processing failed cno => {cno} , bill_period => {bill_period}")    
                logger.error(e)

    except Exception as e:
        logger.info(e)
    
 


if __name__ == '__main__':
    main()


