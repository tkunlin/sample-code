"""
用來跑出4號當天特調情況
"""

import boto3
import time
from lib import config
from lib.db import DB
from lib import config
from lib import ssm
import getopt
import sys
import os
import datetime
from dateutil.relativedelta import relativedelta

class DOPSync:
    def __init__(self, bill_period):
        self.bill_period = bill_period

    def process(self):
        self.db = DB(endpoint='main', database=config.ecloud_database)
        self.db.execute("delete FROM bill_item where bill_period = '{}' and dop = 'y' and lineitem_type is NULL".format(self.bill_period))
        y, m = self.bill_period.split("/")
        nextmonth = datetime.datetime(int(y), int(m), 1) + relativedelta(months=1)
        nextmonthstr = nextmonth.strftime("%Y-%m")
        filename = "init_maindb_{}-09_dop.sql".format(nextmonthstr)
        os.system("aws s3 cp s3://ecv-us-west-2-dev/db-backup/{} . --profile tw03".format(filename))
        os.system(f"mysql -h {config.host} -u {config.user} -p{config.password} {config.ecloud_database} < {filename}")
        os.remove(filename)
        



if __name__ == "__main__":
    def help_text():
        print("update_dop.py -p {YYYY/MM}")
    print(sys.argv)
    bill_period = None
    argv = sys.argv[1:]
    # 處理參數
    try:
        opts, args = getopt.getopt(argv,"hp:")
    except getopt.GetoptError as e:
        help_text()
        sys.exit(2)
    print(opts)
    # 處理參數
    for opt, arg in opts:
        print(opt,arg)
        if opt == '-h':
            help_text()
            sys.exit()
        elif opt in ("-p"):
            bill_period = arg
        else:
            help_text()
            sys.exit()
    
    if bill_period is None:
        # 參數有誤
        help_text()
        sys.exit(2)
    else:
        # 開始處理
        task = DOPSync(bill_period)
        task.process()