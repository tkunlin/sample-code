import getopt
import sys
from lib.db import DB
from datetime import datetime,timedelta
from lib import init_db

# proxy_waive_arr = ['Requests-HTTP-Proxy','Requests-HTTPS-Proxy']
http_waive_arr = ['Requests-Tier1']
https_waive_arr = ['Requests-Tier2-HTTPS']
bill_product = 4 # CDN product Code
usage_type_arr= []
now_hour = datetime.now().hour+8
if now_hour < 11:
    init_date = (datetime.today() - timedelta(1)).strftime('%Y-%m-%d')
else:
    init_date = datetime.today().strftime('%Y-%m-%d')
backup_file_name = 'init_maindb_{}_no_bill_item.sql'.format(init_date)
database_name = 'ecloud_tools'
db = DB(database=database_name,endpoint='main')

def check_exist(bill_customer,bill_product,usage_type):
    res = db.execute(f"select id from bill_price1 where UsageType = '{usage_type}' and bill_product = '{bill_product}' and bill_customer = '{bill_customer}'",have_result=True)['result'] 
    return res[0]['id'] if len(res)>0 else False

def generate_insert(bill_customer,unitprice,usage_type):
    sql = 'INSERT INTO bill_price1 (change_time, change_master, bill_customer, bill_product, UsageType, ItemDescription, UnitPrice) VALUES (UNIX_TIMESTAMP(),1,{},4,"{}","","{}");' 
    print(sql.format(customer_id,usage_type,unitprice))

def generate_update(update_id,unitprice):
    sql = 'UPDATE bill_price1 SET UnitPrice="{}" WHERE id={};'
    print(sql.format(unitprice,update_id))

if __name__ == "__main__":
    argv = sys.argv[1:]
    cno_list = None
    linkedaccount_list = None
    bill_customer = []
    unitprice = None
    region_arr = None
    requests_arr = None
    help_text = """＊ All parameters are case-insensitive ＊
===============================================
CLI                          : python cdn_waive.py -c <cno> -u <unitprice> -r <region> -t <http / https / all>
Example(for specific region) : python cdn_waive.py -c CH111,Ch222,ch333 -u 0.12 -r AP,Ca,eu -t http
Example(for all region)      : python cdn_waive.py -c CH111,Ch222,ch333 -u 0.12 -r all -t all
===============================================
CLI                          : python cdn_waive.py -l <linkedaccount_list> -u <unitprice> -r <region> -t <http / https / all>
Example(for specific region) : python cdn_waive.py -l 12345,67890123458 -u 0.12 -r AP,Ca,eu -t https
Example(for all region)      : python cdn_waive.py -l 12345,67890123458 -u 0.12 -r all -t all
===============================================
"""
    print("==========開始初始化資料庫==========")
    init_db.init_data(backup_file_name,database_name)
    print("==========結束初始化資料庫==========")
    try:
      opts, args = getopt.getopt(argv,"hc:l:u:r:t:")
    except getopt.GetoptError as e:
        print(help_text)
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print(help_text)
            sys.exit()
        elif opt in ("-l"):
            linkedaccount_list = arg.split(',')
            for linkedaccountid in linkedaccount_list:
                customer_id = db.execute("""SELECT id From bill_customer where linkedaccountid = '{}' and hide = 'n'""".format(int(linkedaccountid)), have_result=True)
                bill_customer.append(customer_id['result'][0]['id'])
        elif opt in ("-c"):
            cno_list = [x.upper() for x in arg.split(',')]
            for cno in cno_list:
                customer_id = db.execute("""SELECT id From bill_customer where cno = '{}' and hide = 'n'""".format(cno), have_result=True)
                for val in customer_id['result']:
                    bill_customer.append(val['id'])
        elif opt in ("-u"):
            unitprice = arg
        elif opt in ("-r"):
            if arg.lower() == 'all':
                region_arr = ['AP','CA','EU','IN','JP','ME','SA','US','AU','ZA'] #for all region
            else:
                region_arr = [x.upper() for x in arg.split(',')]
        elif opt in ("-t"):
            if arg.lower() == 'all':
                requests_arr = http_waive_arr + https_waive_arr
            elif arg.lower() == 'http':
                requests_arr = http_waive_arr
            elif arg.lower() == 'https':
                requests_arr = https_waive_arr
            else:
                print(help_text)
                sys.exit()
        else:
            print(help_text)
            sys.exit()
    if cno_list is None and linkedaccount_list is None and region_arr is None and requests_arr is None:
        print(help_text)
        exit()
    
    print("==========開始產生SQL==========")
    for region in region_arr:
        for request in requests_arr:
            usage_type_arr.append(region+"-"+request)
    for customer_id in bill_customer:
        for usage_type in usage_type_arr:
            result = check_exist(customer_id,bill_product,usage_type)
            if result:
                generate_update(result,unitprice)
            else:
                generate_insert(customer_id,unitprice,usage_type) 
    print("==========結束產生SQL==========")
    