import glob
import sys
import subprocess
import config.config as config_setting
from lib.logger import LogDecorator
from lib.db import Database

log = LogDecorator('Pack Invoice')

INOVICE_UPLOAD_FOLDER_NAME = 'staging_invoice'

def apply_config():
    
    bill_period = sys.argv[1]
    env = sys.argv[2]
    region = sys.argv[3]
    client = sys.argv[4]
        
    Config = config_setting.set_config(env, client, region, bill_period)
        
    return Config

def create_local_folder(config):
    try:
        folder_name = f"{INOVICE_UPLOAD_FOLDER_NAME}/ALL_invoice_{config._bill_period_raw}"
        subprocess.run(["mkdir","-p", folder_name])
        log.logger.info(f"Create folder successfully, folder name: {folder_name}")
        for country in config.LEDGER_COUNTRY_LIST:
            folder_name = f"{INOVICE_UPLOAD_FOLDER_NAME}/{country}_invoice_{config._bill_period_raw}"
            subprocess.run(["mkdir", "-p", folder_name])
            log.logger.info(f"Create folder successfully, folder name: {folder_name}")
    except Exception as e:
        remove_staging_area()
        log.logger.error(e)
        sys.exit()

def download_invoice(config):
    s3_bucket = config._ssm_param['s3_invoice_bucket_name']
    s3_source_path = f"s3://{s3_bucket}/invoice/hk_invoice_{config._bill_period_raw}/"
    invoice_target_path = f"{INOVICE_UPLOAD_FOLDER_NAME}/ALL_invoice_{config._bill_period_raw}"
    try:
        subprocess.run(["aws","s3","sync",s3_source_path, invoice_target_path], capture_output = True, timeout=60)
    except subprocess.TimeoutExpired as e:
        remove_staging_area()
        log.logger.error(e)
        sys.exit()
    except Exception as e:
        remove_staging_area()
        log.logger.error(e)
        sys.exit()

def get_cno_invocie_no_mapping(config):
    try:
        db = Database(config._ssm_param)
        sql_query = f"SELECT cno, invoice_no FROM bill_invoice_no WHERE bill_period = \"{config._bill_period_slash}\"; "
        query_result = db.execute(sql_query, have_result=True)
        invoice_no_result = query_result.get('result')
        if not invoice_no_result:
            raise Exception("Empty Data")
        
        sql_query = f"SELECT code_id, code_name FROM bill_code WHERE code_upper_id = 101; "
        query_result = db.execute(sql_query, have_result=True)
        cno_prefix_result = query_result.get('result')
        if not cno_prefix_result:
            raise Exception("Empty Data")
        
        log.logger.info(f"Get mapping data successfully")
        return invoice_no_result, cno_prefix_result
    except Exception as e:
        remove_staging_area()
        log.logger.error(e)
        sys.exit()

def distribute_invoice(cno_map, cno_prefix_mapping, config):
    cno_prefix_map = {}
    try:
        for item in cno_prefix_mapping:
            if item['code_id'] in config.LEDGER_COUNTRY_LIST:
                cno_prefix_map[item['code_name']] = item['code_id']
    except Exception as e:
        remove_staging_area()
        log.logger.error(e)
        sys.exit()
        
    for invoice in cno_map:
        try:
            invoice_no = invoice['invoice_no']
            invoice_pdf_name = f"{INOVICE_UPLOAD_FOLDER_NAME}/ALL_invoice_{config._bill_period_raw}/{invoice_no}.pdf"
            cno = invoice['cno']
            cno_prefix = cno[:2]
            ledger_country = cno_prefix_map.get(cno_prefix)
            if ledger_country is None :
                log.logger.info(f"Invoice no need to pack: cno: {cno}, packing ledger country list: {config.LEDGER_COUNTRY_LIST}")
                continue
            target_invoice_folder = f"{INOVICE_UPLOAD_FOLDER_NAME}/{ledger_country}_invoice_{config._bill_period_raw}"
            proc = subprocess.Popen(["mv", invoice_pdf_name, target_invoice_folder], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            proc.wait()
            if proc.returncode == 0:
                log.logger.info(f"Invoice distributed. cno: {cno} source: {invoice_pdf_name}, target: {target_invoice_folder}")
            else:
                log.logger.error(f"Invoice distributed failed. cno: {cno} source: {invoice_pdf_name}, target: {target_invoice_folder}")
        except Exception as e:
            remove_staging_area()
            log.logger.error(e)
            sys.exit()

def pack_invoice(config):
    for country in config.LEDGER_COUNTRY_LIST:
        source_data = f"{INOVICE_UPLOAD_FOLDER_NAME}/{country}_invoice_{config._bill_period_raw}/*"
        target_zip = f"{INOVICE_UPLOAD_FOLDER_NAME}/{country}_invoice_{config._bill_period_raw}.zip"
        try:
            subprocess.run(["/usr/bin/zip", "-j", target_zip ] + glob.glob(source_data), capture_output = True, timeout=60)
        except subprocess.TimeoutExpired as e:            
            remove_staging_area()
            log.logger.error(e)
            sys.exit()
        except Exception as e:
            remove_staging_area()
            log.logger.error(e)
            sys.exit()
            
        try:
            rclone_config_name = config.RCLONE_CONFIG_NAME
            onedrive_path = config.ONEDRIVE_PATH.get(country)
            rclone_dest_path = f"{rclone_config_name}:{onedrive_path}"
            if not onedrive_path:
                raise Exception()
            subprocess.run(["rclone", "copy", target_zip, rclone_dest_path, "--ignore-size", "--ignore-checksum", "--log-file", f"./rclone-invoice-{config._bill_period_raw}.log", "--log-level", "DEBUG"])
        except Exception as e:
            remove_staging_area()
            log.logger.error(e)
            sys.exit()

# Dangerous Zone, be careful
def remove_staging_area():
    try:
        subprocess.run(["rm","-r", INOVICE_UPLOAD_FOLDER_NAME])
        log.logger.info(f"Remove staging invoice {INOVICE_UPLOAD_FOLDER_NAME}")
    except Exception as e:
        log.logger.error(e)
        sys.exit()

if __name__ == '__main__':
    
    if len(sys.argv) != 5:
        sys.exit("[ERROR] Usage: python3 main.py <yyyymm> <env> <region> <client>. For example: python3 main.py 202201 Prod us-west-2 ECV") 
    
    Config = apply_config()
    remove_staging_area()
    create_local_folder(Config)
    download_invoice(Config)
    cno_mapping, cno_prefix_mapping = get_cno_invocie_no_mapping(Config)
    distribute_invoice(cno_mapping, cno_prefix_mapping, Config)
    pack_invoice(Config)