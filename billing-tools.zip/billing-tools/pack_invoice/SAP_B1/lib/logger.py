import logging
import functools

class LogDecorator(object):
    def __init__(self, job_name):
        self.logger = logging.getLogger(job_name)
        self.logger.setLevel(logging.DEBUG)
        
        if not self.logger.handlers:
            self.ch = logging.StreamHandler()
            self.ch.setLevel(logging.DEBUG)
            
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            self.ch.setFormatter(formatter)
            self.logger.addHandler(self.ch)

    def __call__(self, fn):
        @functools.wraps(fn)
        def decorated(*args, **kwargs):
            try:
                self.logger.debug("{0} - {1} - {2}".format(fn.__name__, args, kwargs))
                result = fn(*args, **kwargs)
                self.logger.debug(result)
                return result
            except Exception as ex:
                self.logger.debug("Exception {0}".format(ex))
                raise ex
        return decorated