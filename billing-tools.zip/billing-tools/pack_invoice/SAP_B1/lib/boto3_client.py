import boto3

def get_ssm_parameter(para_list, region_name):
    try:
        session = boto3.Session(region_name=region_name)
        session = session.client('ssm')
        response = session.get_parameters(
            Names=para_list,
            WithDecryption=True
        )
    except Exception as e:
        pass
        # pdf_logger.logger.error(e)

    return response