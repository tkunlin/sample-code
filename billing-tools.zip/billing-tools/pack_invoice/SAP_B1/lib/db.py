import pymysql

class Database:
    def __init__(self, config):
        self.host = config.get('db_host')
        self.user = config.get('db_username')
        self.password = config.get('db_password')
        self.db = config.get('db_name')
        self.connect()

    def connect(self):
        self.conn = pymysql.connect(host=self.host, user=self.user, password=self.password, db=self.db, local_infile = True)
        self.cur = self.conn.cursor( pymysql.cursors.DictCursor )

    def reconnect(self):
        try:
            self.conn.close()
            self.connect()
        except Exception as e:
            print(e)

    def execute(self, sql, insert_list = None, have_result = False, get_cursor = False): 
        try:
            if insert_list == None:
                self.cur.execute (sql)
            else:
                self.cur.execute(sql,tuple(insert_list))
            self.conn.commit()
        except (AttributeError, pymysql.OperationalError):
            self.reconnect()
            ## and try again
            try:
                if insert_list == None:
                    self.execute(sql)
                else:
                    self.execute(sql, tuple(insert_list))
            except Exception as e:
                self.conn.rollback()
                return {'success':False, 'err': str(e)}
        except Exception as e:
            if 'Lock wait timeout exceeded' in str(e):
                self.reconnect()
                try:
                    if insert_list == None:
                        self.execute (sql)
                    else:
                        self.execute(sql,tuple(insert_list))
                except:
                    self.conn.rollback()
                    return {'success':False, 'err': str(e)}
            else:
                self.conn.rollback()
                return {'success':False, 'err': str(e)}
        
        if have_result:
            ans = self.cur.fetchall()
            dict_result = []
            for row in ans:
                dict_result.append(dict(row))
            return {'success':True, 'result' : dict_result }
        elif get_cursor:
            return {'success':True, 'cursor':self.cur}
        else:
            return {'success':True}


    def close(self):
        try:
            self.conn.close()
        except Exception as e:
            print(e)

