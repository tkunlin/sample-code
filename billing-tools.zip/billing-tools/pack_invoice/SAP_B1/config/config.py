from lib.boto3_client import get_ssm_parameter
from lib.logger import LogDecorator

logger = LogDecorator('Pack Invoice')
class BaseConfig():
    def __init__(self, env, client, region, bill_period):
        self._env = env
        self._client = client
        self._region = region
        self._bill_period_slash = bill_period[:4] + '/' + bill_period[4:]
        self._bill_period_raw = bill_period
        self._s3prefix = f"invoice/hk_invoice_{self._bill_period_raw}/"
        self._ssm_param = {
            "db_host": f"/{self._env}/Billing/DB/mysql-host",
            "db_username": f"/{self._env}/Billing/DB/mysql-user",
            "db_password": f"/{self._env}/Billing/DB/mysql-password",
            "db_name": f"/{self._env}/Billing/DB/mysql-db",
            "s3_invoice_bucket_name": f"/{self._env}/Billing/S3/invoice/bucket-name",
        }
        self.set_parameter()
    
    @logger
    def set_parameter(self):
        ssm_result = get_ssm_parameter(list(self._ssm_param.values()), self._region)
        parameter_obj = {}
        for res in ssm_result['Parameters']:
            parameter_obj[res['Name']] = res['Value']
        
        for key in self._ssm_param.keys():
            self._ssm_param[key] = parameter_obj[self._ssm_param[key]]
    
    # TODO: In the future, may get the config from the database
    @logger
    def get_parameter_detail():
        pass

class ECVConfig(BaseConfig):
    def __init__(self, *args):
        super(ECVConfig, self).__init__(*args)
        
    LEDGER_COUNTRY_LIST = ['HK','SG','ID','TH','MY']
    ONEDRIVE_PATH = {
        "HK": "Public/Finance & Accounting Center/BIL/MGT invoice-HK",
        "SG": "Public/Finance & Accounting Center/BIL/MGT invoice-SG",
        "ID": "Public/Finance & Accounting Center/BIL/MGT invoice-ID",
        "TH": "Public/Finance & Accounting Center/BIL/MGT invoice-TH",
        "MY": "Public/Finance & Accounting Center/BIL/MGT invoice-MY"
    }
    RCLONE_CONFIG_NAME = 'EIP'
    
class ECRConfig(BaseConfig):
    def __init__(self, *args):
        super(ECRConfig, self).__init__(*args)
        
    LEDGER_COUNTRY_LIST = ['C3','C8']
    ONEDRIVE_PATH = {
        "C3": "分享檔案/2020_SAP Hana/8_MGT提供給SAP檔案/2_3_MGT Global 帐本国 C3 的 Invoice & PDF帳單/Invoice",
        "C8": "分享檔案/2020_SAP Hana/8_MGT提供給SAP檔案/2_4_MGT Global 帐本国 C8 的 Invoice & PDF帳單/Invoice"
    }
    RCLONE_CONFIG_NAME = 'sharon'
    
def set_config(env: str, client: str, region: str, bill_period: str):
    if client == 'ECV':
        return ECVConfig(env, client, region, bill_period)
    elif client == 'ECR':
        return ECRConfig(env, client, region, bill_period)
    else: 
        return False
