#!/bin/bash
# ================================================================================= #
# Copyright 2023 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #

# Load Configuartion
if  [ "$3" = "ECV" ]
then
  source ./config/config_ECV.sh $1 $2
elif [ "$3" = "ECR" ]
then
  source ./config/config_ECR.sh $1 $2
else
  echo "Unsupported company: $3"
  exit 1
fi

###########################################################################################
# logFunction - Display the log information
###########################################################################################
loginfo() {
  echo "$(eval $LOG_DATE_CMD) [$UUID][INFO]$(printf ' %s' "$@")"
}
logerr() {
  echo "$(eval $LOG_DATE_CMD) [$UUID][ERROR]$(printf ' %s' "$@")"
}

###########################################################################################
# listConfiguration - Dump configuration to log
###########################################################################################
listConfiguration(){
  loginfo "[Configuration]"
  loginfo "Bill Period": $BILL_PERIOD
  loginfo "S3 Invoice Bucket": $S3_BUCKET
  loginfo "S3 Invoice Bucket Prefix": $S3_PREFIX
  loginfo "Ledger Country List": ${LEDGER_COUNTRY_LIST[*]}
  loginfo "ONEDRIVE_PATH": ${ONEDRIVE_PATH[*]}
}

###########################################################################################
# checkDependency - check dependency is installed already
###########################################################################################
checkDependency(){
  loginfo "Checking Dependency..."
  hash aws || exit 1
  hash zip || exit 1
  hash nohup || exit 1
  hash rclone || exit 1
  hash jq || exit 1
  loginfo "Dependency OK!"
}


###########################################################################################
# downloadFile - download File from Amazon S3
###########################################################################################
downloadFile(){
  loginfo "Start downloading invoice from S3"
  mkdir -p $LOCAL_INVOICE_FOLDER
  loginfo "rm -r ./$LOCAL_INVOICE_FOLDER/*"
  rm -r ./$LOCAL_INVOICE_FOLDER/*
  wait
  loginfo "aws s3 cp s3://$S3_BUCKET/$S3_PREFIX/ ./$LOCAL_INVOICE_FOLDER  --recursive"
  aws s3 cp s3://$S3_BUCKET/$S3_PREFIX/ ./$LOCAL_INVOICE_FOLDER --recursive
  loginfo "Download completed"
}


###########################################################################################
# compressFile - compress the files downloaded and upload to onedrive
###########################################################################################
compressFile(){
  loginfo "Start compress invoice"
  for ledgerCountry in "${LEDGER_COUNTRY_LIST[@]}";
  do
    zipFileName="hana_$ledgerCountry"_invoice_"$BILL_PERIOD".zip
    sourceData="$LOCAL_INVOICE_FOLDER/$ledgerCountry/*"
    ledgerCountryUpperCase=`echo $ledgerCountry | tr [:lower:] [:upper:]`

    loginfo "zip -j $zipFileName $sourceData"
    zip -j $zipFileName $sourceData
    wait
    loginfo "rclone copy $zipFileName '${ONEDRIVE_PATH[$ledgerCountryUpperCase]}' --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$BILL_PERIOD.log --log-level NOTICE"
    rclone copy $zipFileName "${ONEDRIVE_PATH[$ledgerCountryUpperCase]}" --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$BILL_PERIOD.log --log-level NOTICE
    wait
    loginfo "rm $zipFileName"
    rm $zipFileName
  done
  loginfo "rm -r ./$LOCAL_INVOICE_FOLDER/*"
  rm -r ./$LOCAL_INVOICE_FOLDER/*
  loginfo "Compress invoice completed"
}

main(){
    loginfo "===Job Start==="
    listConfiguration
    checkDependency
    downloadFile
    wait
    compressFile
    loginfo "===Job End==="
}

if [ "$#" -ne 3 ];
then
    loginfo "Usage: bash hana_pack_invoice.sh [yyyymm] [env] [company]. For example: bash hana_pack_invoice.sh 202201 Prod ECV"
    exit 1
fi

main