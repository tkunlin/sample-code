#!/bin/bash

#Display log datetime
readonly LOG_DATE_CMD='date "+%Y-%m-%d %H:%M:%S.%3N"'
readonly UUID=$(uuidgen)

readonly BILL_PERIOD=$1
readonly ENV=$2

readonly S3_BUCKET=`aws ssm get-parameter --name /$ENV/Billing/S3/invoice/bucket-name --region us-west-2 | jq .Parameter.Value | tr -d '"' ` 
readonly S3_PREFIX="invoice/$BILL_PERIOD"

declare -a LEDGER_COUNTRY_LIST=("c8" "c3")
readonly LOCAL_INVOICE_FOLDER='ecv_invoices'
readonly UPLOAD_FOLDER=`aws ssm get-parameter --name "/$ENV/Billing/sharepoint/folder" --region us-west-2 | jq .Parameter.Value | tr -d '"' ` 
#UPLOAD_FOLDER='sharon:分享檔案/2020_SAP Hana/8_MGT提供給SAP檔案'  #for c8
declare -A ONEDRIVE_PATH
ONEDRIVE_PATH[C8]="$UPLOAD_FOLDER/2_4_MGT Global 帐本国 C8 的 Invoice & PDF帳單/Invoice"
ONEDRIVE_PATH[C3]="$UPLOAD_FOLDER/2_3_MGT Global 帐本国 C3 的 Invoice & PDF帳單/Invoice"
# ONEDRIVE_PATH[C8]="$UPLOAD_FOLDER/invoice/C8" #for dev test
