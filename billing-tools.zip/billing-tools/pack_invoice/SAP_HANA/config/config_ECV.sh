#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

#Display log datetime
readonly LOG_DATE_CMD='date "+%Y-%m-%d %H:%M:%S.%3N"'
readonly UUID=$(uuidgen)

readonly BILL_PERIOD=$1
readonly ENV=$2

readonly S3_BUCKET=`aws ssm get-parameter --name /$ENV/Billing/S3/invoice/bucket-name --region us-west-2 | jq .Parameter.Value | tr -d '"' ` 
readonly S3_PREFIX="invoice/$BILL_PERIOD"

declare -a LEDGER_COUNTRY_LIST=("hk" "sg" "id" "th" "my" "au")
# declare -a LEDGER_COUNTRY_LIST=("sg") #for dev test
readonly LOCAL_INVOICE_FOLDER='ecv_invoices'
# readonly UPLOAD_FOLDER='EIP:Public/Finance & Accounting Center/BIL'
readonly UPLOAD_FOLDER=`aws ssm get-parameter --name "/$ENV/Billing/sharepoint/folder" --region us-west-2 | jq .Parameter.Value | tr -d '"' ` 
declare -A ONEDRIVE_PATH
ONEDRIVE_PATH[HK]="$UPLOAD_FOLDER/MGT invoice-HK"
ONEDRIVE_PATH[SG]="$UPLOAD_FOLDER/MGT invoice-SG"
ONEDRIVE_PATH[ID]="$UPLOAD_FOLDER/MGT invoice-ID"
ONEDRIVE_PATH[TH]="$UPLOAD_FOLDER/MGT invoice-TH"
ONEDRIVE_PATH[MY]="$UPLOAD_FOLDER/MGT invoice-MY"
ONEDRIVE_PATH[AU]="$UPLOAD_FOLDER/MGT invoice-AU"
# ONEDRIVE_PATH[SG]="$UPLOAD_FOLDER/invoice/SG" #for dev test