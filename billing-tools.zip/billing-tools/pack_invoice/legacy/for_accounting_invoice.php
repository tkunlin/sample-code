<?php
$execute_date = date("Ym",strtotime("-1 month"));
$year = date("Y",strtotime("-1 month"));
$month = date("m",strtotime("-1 month"));
$base_dir = '/home/'.trim(shell_exec('/usr/bin/whoami'));

$all_source_dir = 'all_invoice_'.$execute_date;
$hk_source_dir = 'hk_invoice_'.$execute_date;
$sg_source_dir = 'sg_invoice_'.$execute_date;
$id_source_dir = 'id_invoice_'.$execute_date;
$th_source_dir = 'th_invoice_'.$execute_date;
$my_source_dir = 'my_invoice_'.$execute_date;
$c3_source_dir = 'c3_invoice_'.$execute_date;
$c8_source_dir = 'c8_invoice_'.$execute_date;

shell_exec("mkdir $base_dir/$all_source_dir");
shell_exec("mkdir $base_dir/$hk_source_dir");
shell_exec("mkdir $base_dir/$sg_source_dir");
shell_exec("mkdir $base_dir/$id_source_dir");
shell_exec("mkdir $base_dir/$th_source_dir");
shell_exec("mkdir $base_dir/$my_source_dir");
shell_exec("mkdir $base_dir/$c3_source_dir");
shell_exec("mkdir $base_dir/$c8_source_dir");

$onedrive_path_for_hk = 'rachel:MGT invoice-CH (to Fion)';
$onedrive_path_for_sg = 'rachel:MGT invoice-CS (to Gloria)';
$onedrive_path_for_id = 'rachel:MGT invoice-ID';
$onedrive_path_for_th = 'rachel:MGT invoice-TH';
$onedrive_path_for_my = 'rachel:MGT invoice-CY';

$cmdstr = "aws s3 sync s3://ecv-invoice/invoice/$hk_source_dir/ $base_dir/$all_source_dir --profile tw03";

echo $cmdstr."\n";
shell_exec($cmdstr);

$sql_str = "select cno,invoice_no from bill_invoice_no where bill_period = '$year/$month'";

$db = new PDO("mysql:host=atlas-billing-dev.cnw7guvufew0.us-west-2.rds.amazonaws.com;dbname=ecloud","root","!QAZ2wsx3edc");
$sth = $db->prepare($sql_str);
$sth->execute();
$res = $sth->fetchAll();

function is_dir_empty($dir) {
	if (!is_readable($dir)) return NULL; 
	return (count(scandir($dir)) == 2);
}

foreach($res as $value){
	$invoice_no = $value['invoice_no'];
	$cno = $value['cno'];
	if(strpos($cno, 'CS') !== false){
		$cmd = "mv $base_dir/$all_source_dir/$invoice_no.pdf $base_dir/$sg_source_dir";
		shell_exec($cmd);
	}elseif (strpos($cno, 'CH') !== false or strpos($cno, 'CM') !== false) {
		$cmd = "mv $base_dir/$all_source_dir/$invoice_no.pdf $base_dir/$hk_source_dir";
		shell_exec($cmd);
	}elseif (strpos($cno, 'CT') !== false) {
		$cmd = "mv $base_dir/$all_source_dir/$invoice_no.pdf $base_dir/$th_source_dir";
		shell_exec($cmd);
	}elseif (strpos($cno, 'CI') !== false) {
		$cmd = "mv $base_dir/$all_source_dir/$invoice_no.pdf $base_dir/$id_source_dir";
		shell_exec($cmd);
	}elseif (strpos($cno, 'CY') !== false) {
		$cmd = "mv $base_dir/$all_source_dir/$invoice_no.pdf $base_dir/$my_source_dir";
		shell_exec($cmd);
	}elseif (strpos($cno, 'CC') !== false) {
		$cmd = "mv $base_dir/$all_source_dir/$invoice_no.pdf $base_dir/$c3_source_dir";
		shell_exec($cmd);
	}elseif (strpos($cno, 'CR') !== false) {
		$cmd = "mv $base_dir/$all_source_dir/$invoice_no.pdf $base_dir/$c8_source_dir";
		shell_exec($cmd);
	}
}

$all_invoice_count = shell_exec("ls $base_dir/$all_source_dir -1 | wc -l");
$hk_invoice_count = shell_exec("ls $base_dir/$hk_source_dir -1 | wc -l");
$sg_invoice_count = shell_exec("ls $base_dir/$sg_source_dir -1 | wc -l");
$th_invoice_count = shell_exec("ls $base_dir/$th_source_dir -1 | wc -l");
$id_invoice_count = shell_exec("ls $base_dir/$id_source_dir -1 | wc -l");
$my_invoice_count = shell_exec("ls $base_dir/$my_source_dir -1 | wc -l");
$c3_invoice_count = shell_exec("ls $base_dir/$c3_source_dir -1 | wc -l");
$c8_invoice_count = shell_exec("ls $base_dir/$c8_source_dir -1 | wc -l");

echo "remain_invoice_count: $all_invoice_count\n";
echo "hk_invoice_count: $hk_invoice_count\n";
echo "sg_invoice_count: $sg_invoice_count\n";
echo "th_invoice_count: $th_invoice_count\n";
echo "id_invoice_count: $id_invoice_count\n";
echo "my_invoice_count: $my_invoice_count\n";
echo "c3_invoice_count: $c3_invoice_count\n";
echo "c8_invoice_count: $c8_invoice_count\n";

if(!is_dir_empty("$base_dir/$hk_source_dir")){
	echo "Uploading HK invoice \n";
	$zip_file_name = "$hk_source_dir.zip";
	$source_data = "$base_dir/$hk_source_dir/*";
	$zip_cli = "/usr/bin/zip -j $zip_file_name $source_data";
	$upload_cli = "rclone copy $zip_file_name '$onedrive_path_for_hk' --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$execute_date.log --log-level NOTICE ";
	echo $zip_cli."\n".$upload_cli."\n";
	shell_exec("$zip_cli && $upload_cli");
}

if(!is_dir_empty("$base_dir/$sg_source_dir")){
	echo "Uploading SG invoice \n";
	$zip_file_name = "$sg_source_dir.zip";
	$source_data = "$base_dir/$sg_source_dir/*";
	$zip_cli = "/usr/bin/zip -j $zip_file_name $source_data";
	$upload_cli = "rclone copy $zip_file_name '$onedrive_path_for_sg' --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$execute_date.log --log-level NOTICE ";
	echo $zip_cli."\n".$upload_cli."\n";
	shell_exec("$zip_cli && $upload_cli");
}

if(!is_dir_empty("$base_dir/$id_source_dir")){
	echo "Uploading ID invoice \n";
	$zip_file_name = "$id_source_dir.zip";
	$source_data = "$base_dir/$id_source_dir/*";
	$zip_cli = "/usr/bin/zip -j $zip_file_name $source_data";
	$upload_cli = "rclone copy $zip_file_name '$onedrive_path_for_id' --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$execute_date.log --log-level NOTICE ";
	echo $zip_cli."\n".$upload_cli."\n";
	shell_exec("$zip_cli && $upload_cli");
}

if(!is_dir_empty("$base_dir/$th_source_dir")){
	echo "Uploading TH invoice \n";
	$zip_file_name = "$th_source_dir.zip";
	$source_data = "$base_dir/$th_source_dir/*";
	$zip_cli = "/usr/bin/zip -j $zip_file_name $source_data";
	$upload_cli = "rclone copy $zip_file_name '$onedrive_path_for_th' --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$execute_date.log --log-level NOTICE ";
	echo $zip_cli."\n".$upload_cli."\n";
	shell_exec("$zip_cli && $upload_cli");
}

if(!is_dir_empty("$base_dir/$my_source_dir")){
	echo "Uploading MY invoice \n";
	$zip_file_name = "$my_source_dir.zip";
	$source_data = "$base_dir/$my_source_dir/*";
	$zip_cli = "/usr/bin/zip -j $zip_file_name $source_data";
	$upload_cli = "rclone copy $zip_file_name '$onedrive_path_for_my' --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$execute_date.log --log-level NOTICE ";
	echo $zip_cli."\n".$upload_cli."\n";
	shell_exec("$zip_cli && $upload_cli");
}

if(!is_dir_empty("$base_dir/$c3_source_dir")){
	echo "Uploading C3 invoice \n";
	$zip_file_name = "$c3_source_dir.zip";
	$source_data = "$base_dir/$c3_source_dir/*";
	$zip_cli = "/usr/bin/zip -j $zip_file_name $source_data";
	$upload_cli = "rclone copy $zip_file_name '$onedrive_path_for_my' --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$execute_date.log --log-level DEBUG ";
	echo $zip_cli."\n".$upload_cli."\n";
	shell_exec("$zip_cli && $upload_cli");
}

if(!is_dir_empty("$base_dir/$c8_source_dir")){
	echo "Uploading C8 invoice \n";
	$zip_file_name = "$c8_source_dir.zip";
	$source_data = "$base_dir/$c8_source_dir/*";
	$zip_cli = "/usr/bin/zip -j $zip_file_name $source_data";
	$upload_cli = "rclone copy $zip_file_name '$onedrive_path_for_my' --ignore-size --ignore-checksum --log-file ~/rclone-invoice-$execute_date.log --log-level DEBUG ";
	echo $zip_cli."\n".$upload_cli."\n";
	shell_exec("$zip_cli && $upload_cli");
}


?>
