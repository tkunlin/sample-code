#!/bin/bash

#Display log datetime
readonly LOG_DATE_CMD='date "+%Y-%m-%d %H:%M:%S.%3N"'
readonly UUID=$(uuidgen)
readonly S3_BUCKET=`aws ssm get-parameter --name /Dev/Billing/S3/invoice/bucket-name | jq .Parameter.Value | tr -d '"'` 
readonly BILL_PERIOD=$1
readonly S3_PREFIX="invoice/$BILL_PERIOD"
readonly LEDGER_COUNTRY_LIST=('vn')
readonly LOCAL_INVOICE_FOLDER="ecv_invoices_$BILL_PERIOD"
declare -A ONEDRIVE_PATH
ONEDRIVE_PATH[HK]='rachel:MGT invoice-CH (to Fion)'
ONEDRIVE_PATH[SG]='rachel:MGT invoice-CS (to Gloria)'
ONEDRIVE_PATH[ID]='rachel:MGT invoice-ID'
ONEDRIVE_PATH[TH]='rachel:MGT invoice-TH'
ONEDRIVE_PATH[MY]='rachel:MGT invoice-CY'