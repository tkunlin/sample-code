import getopt
import sys
import pandas as pd
from lib.db import DB
from datetime import datetime
from lib import init_db

init_date = datetime.today().strftime('%Y-%m-%d')
backup_file_name = 'init_no_bill_item_{}.sql'.format(init_date)
database_name = 'ecloud_tools'
db = DB(database=database_name,endpoint='main')

def process(bill_period):
    df = pd.read_csv("Rate-CSV/rate.csv")
    df.columns = map(lambda x: str(x).upper(), df.columns)
    if df.columns[0] != 'CNO' or df.columns[1] != 'RATE':
        print("CSV 欄位命名錯誤")
        exit()
    update_sql_template = """UPDATE bill_rate SET rate={} WHERE bill_customer in ({}) and bill_period= '{}';"""
    update_sql = ''
    for index, row in df.iterrows():
        res = db.execute("""SELECT id FROM bill_customer where cno='{}' and hide='n'""".format(row['CNO'].upper()), have_result=True)
        rate = str(row['RATE'])
        if len(res['result'])>0:
            bill_customer = res_to_string(res['result'])
            update_sql += update_sql_template.format(rate,bill_customer,bill_period)+"\n"
        else:
            print("CNO : {} not found in bill_customer , maybe it had been hidden !!!".format(row['CNO'].upper()))
    print(update_sql)
    
def res_to_string(res):
    bill_customer_list = []
    bill_customer_str = ''
    for customer in res:
        bill_customer_list.append(str(customer['id']))
    bill_customer_str = ','.join(bill_customer_list)
    return bill_customer_str

if __name__ == "__main__":
    argv = sys.argv[1:]
    bill_period = None
    help_text = """
===============================================
CLI     : python rate_update.py -p <yyyy/mm>
Example : python rate_update.py -p 2020/08
===============================================
"""
 
    try:
      opts, args = getopt.getopt(argv,"hp:")
    except getopt.GetoptError as e:
        print(help_text)
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print(help_text)
            sys.exit()
        elif opt in ("-p"):
            bill_period = arg
        else:
            print(help_text)
            sys.exit()
    if bill_period is None :
        print(help_text)
        exit()
    print("==========開始初始化資料庫==========")
    init_db.init_data(backup_file_name,database_name)
    print("==========結束初始化資料庫==========")
    print("==========開始產生SQL==========")
    process(bill_period)
    print("==========結束產生SQL==========")