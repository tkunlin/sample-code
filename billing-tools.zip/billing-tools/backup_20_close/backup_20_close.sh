#!/bin/sh

DATE_FOR_FILE=`date +%Y-%m-%d`

DATE_FOR_SQL=$3

DB_USER=$1
DB_PWD=$2

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_customer bill_customer_si bill_cdn bill_price1 bill_product bill_payer_account bill_region ri_instance_base_type bill_price_si bill_rate bill_master bill_admin_name bill_admin_power bill_code bill_close bill_master_customer bill_customer_sap bill_rate_list > /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_invoice_revenue --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_item --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

#mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_close --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_item_settle --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_invoice_settle --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_item_sap --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_item_sap_cost --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_savingplan_list --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_ri_new --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_invoice_no --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

mysqldump -h ecv-prod-billing-replica.cmkvf1hpueee.us-west-2.rds.amazonaws.com -u ${DB_USER} -p${DB_PWD} ecloud bill_rate_list --where="bill_period = '$DATE_FOR_SQL'" >> /tmp/init_maindb.sql

aws s3 cp /tmp/init_maindb.sql s3://ecv-us-west-2-dev/db-backup/init_20_maindb_${DATE_FOR_FILE}.sql
#aws s3 cp /tmp/init_maindb.sql s3://ecv-us-west-2-dev/tmp/

rm /tmp/init_maindb.sql

