aws ecr get-login-password --region us-west-2 | docker login --username AWS --password-stdin 006920391431.dkr.ecr.us-west-2.amazonaws.com
docker build -t jira_conf_backup .
eval $(aws ecr get-login --no-include-email --region us-west-2)
docker tag jira_conf_backup:latest 006920391431.dkr.ecr.us-west-2.amazonaws.com/jira_conf_backup:latest
docker push 006920391431.dkr.ecr.us-west-2.amazonaws.com/jira_conf_backup:latest