#!/bin/sh
# sed '/mysqldump/ i innodb_buffer_pool_size = 1024M' /etc/mysql/my.cnf > /etc/mysql/my.cnf.bak && \
# cp /etc/mysql/my.cnf.bak /etc/mysql/my.cnf && \
# mysqld &
# echo "creating...."
# sleep 5
# mysql -uroot -e "create database atlas;"
# mysql -uroot -e "ALTER DATABASE atlas CHARACTER SET utf8 COLLATE utf8_general_ci;"
# mysqladmin password 123456

echo "Start Jira backup"

python3.6 Jira_backup.py

echo "End Jira backup"

sleep 5

echo "Start confluence backup"
python3.6 confluence_backup.py

echo "End confluence backup"
