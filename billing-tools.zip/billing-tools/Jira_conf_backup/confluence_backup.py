from lib.sqs_lib import *
from lib.verify_lib import *
from lib.ecv_lib import *
import os
from botocore.vendored import requests
import time
import re
import boto3
import json
import datetime

nowdate=datetime.datetime.now().strftime("%Y/%m/%d")
system_name = os.environ['conf_system_name']
function_name = os.environ['conf_function_name']
fail_notification_mail = os.environ['fail_notification_mail']
Subject = os.environ['conf_subject'] + nowdate
Sender = os.environ['sender']
CC = os.environ['cc']
recipient = os.environ['recipient']
mail_content = 'Hi sir,<br> Confluence backup to s3 bucket success.<BR> Detail Info: <BR>'

# def lambda_handler(event, context):
#     global mail_content
#     main()

def conf_backup(account, username, token, attachments, folder):
        
    global mail_content
    # global variables
    global backup_response
    global json
    global file_name

    # Set json data to determine if backup to include attachments.
    if attachments in ('Y', 'y'):
        json = b'{"cbAttachments": "true", "exportToCloud": "true"}'
    elif attachments in ('N', 'n'):
        json = b'{"cbAttachments": "false", "exportToCloud": "true"}'

    # Create the full base url for the JIRA instance using the account name.
    url = 'https://' + account + '.atlassian.net/wiki'

    # Open new session for cookie persistence and auth.
    session = requests.Session()
    session.auth = (username, token)
    session.headers.update({"Accept": "application/json", "Content-Type": "application/json"})

    progress_req = session.get(url + '/rest/obm/1.0/getprogress')

    # Check for filename match in response
    file_name = str(re.search('(?<=fileName\":\")(.*?)(?=\")', progress_req.text))

    # If no file name match in JSON response keep outputting progress every 10 seconds
    while file_name == 'None':

        progress_req = session.get(url + '/rest/obm/1.0/getprogress')
        # Regex to extract elements of JSON progress response.
        file_name = str(re.search('(?<=fileName\":\")(.*?)(?=\")', progress_req.text))
        estimated_percentage = str(re.search('(?<=Estimated progress: )(.*?)(?=\")', progress_req.text))
        error = 'error'
        # While there is an estimated percentage this will be output.
        if estimated_percentage != 'None':
            # Regex for current status.
            current_status = str(
                re.search('(?<=currentStatus\":\")(.*?)(?=\")', progress_req.text).group(1))
            # Regex for percentage progress value
            estimated_percentage_value = str(
                re.search('(?<=Estimated progress: )(.*?)(?=\")', progress_req.text).group(1))
            print('Action: ' + current_status + ' / Overall progress: ' + estimated_percentage_value)
            time.sleep(10)
        # Once no estimated percentage in response the alternative progress is output.
        elif estimated_percentage == 'None':
            # Regex for current status.
            current_status = str(
                re.search('(?<=currentStatus\":\")(.*?)(?=\")', progress_req.text).group(1))
            # Regex for alternative percentage value.
            alt_percentage_value = str(
                re.search('(?<=alternativePercentage\":\")(.*?)(?=\")', progress_req.text).group(1))
            print('Action: '+ current_status + ' / Overall progress: ' + alt_percentage_value)
            time.sleep(10)
        # Catch any instance of the of word 'error' in the response and exit script.
        elif error.casefold() in progress_req.text:
            print(progress_req.text)
            exit(1)

    # Get filename from progress JSON
    file_name = str(re.search('(?<=fileName\":\")(.*?)(?=\")', progress_req.text))

    # Check filename is not None
    if file_name != 'None':
        file_name = str(re.search('(?<=fileName\":\")(.*?)(?=\")', progress_req.text).group(1))
        
        
        msg = '1.Backup complete, downloading file to ' + folder
        mail_content = mail_content + msg + '<br>'
        print(msg)
        
        msg = '2.Backup file can also be downloaded from ' + url + '/download/' + file_name
        mail_content = mail_content + msg + '<br>'
        print(msg)

        date = time.strftime("%Y%m%d_%H%M%S")

        filename = account + '_conf_backup_' + date + '.zip'
        file = session.get(url + '/download/' + file_name, stream=True)

        file.raise_for_status()
        with open(folder + filename, 'wb') as handle:
            for block in file.iter_content(1024):
                #print (handle.write(block))
                handle.write(block)
        
        msg = '3.' + filename + ' downloaded to ' + folder
        mail_content = mail_content + msg + '<br>'
        print(msg)
        
        print(folder  + filename)
        S3Buckets = os.environ['S3Buckets']
        s3 = boto3.client('s3')
        s3.upload_file(folder + filename, S3Buckets, filename)
        os.remove(folder + filename)
        
        msg = '4. ' + filename +' finish to S3 (' + S3Buckets + ')'
        mail_content = mail_content + msg + '<br>'
        print(msg)
        
        message_attributes=[system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
        message_body = mail_content
        sent_result = Send_Queue_Message(message_body,message_attributes,error_message = ' ')
        print ('sent_result:' + str(sent_result))
        
        if sent_result == None:
            print('Message SentEnd !')
        else:
            mail_content = mail_content.replace('success','Error')
            print(str(sent_result))
            message_attributes= [system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
            msg = '<br> Confluence backup send queue message error:\r\n' + str(sent_result)+ '<br>'
            mail_content = mail_content + msg
            print(msg)
            return Send_DLQ_Message(mail_content,message_attributes,mail_content)
            
def main():
    global mail_content
    
    message_attributes= [system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
    system_error_msg = 'Please check Con_backup lamdba configuration Environment variables'
    
    # check message
    # 檢查空值
    if has_string_empty(system_name):
        msg = 'system_name Required.' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes, msg)
        
    if has_string_empty(function_name):
        msg = 'function_name Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_string_empty(fail_notification_mail):
        msg = 'fail_notification_mail Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_string_empty(Sender):
        msg = 'Sender Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_string_empty(Subject):
        msg = 'subject Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    if has_string_empty(CC):
        msg = 'CC Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    if has_string_empty(recipient):
        msg = 'recipient Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    
    # check length
    if has_length(system_name, 32):
        msg = 'system_name max length 32 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        message_attributes= [system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_length(function_name, 32):
        msg = 'function_name max length 32 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_length(fail_notification_mail, 128):
        msg = 'fail_notification_mail max length 128 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_length(Subject, 128):
        msg = 'subject max length 128 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_length(Sender, 64):
        msg = 'sender max length 64 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        message_attributes= [system_name,function_name,fail_notification_mail,Subject,' ',' ',CC,' ']
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    if has_length(CC, 500):
        msg = 'CC max length 500 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    if has_length(recipient, 500):
        msg = 'recipient max length 500 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    site = os.environ['jira_site']
    user_name = os.environ['jira_user']
    api_token = os.environ['jira_token']
    folder = '/tmp/'
    
    print (os.path.dirname(os.path.abspath(__file__)))
    
    try:
        conf_backup(site, user_name, api_token, 'Y', folder)
    except Exception as e:
        mail_content = mail_content.replace('success','Error')
        print(str(e))
        message_attributes= [system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
        msg = '<br> Confluence backup Error Message:\r\n' + str(e)+ '<br>'
        mail_content = mail_content + msg
        print(msg)
        return Send_DLQ_Message(mail_content,message_attributes,mail_content)

if __name__ == '__main__':
    main()