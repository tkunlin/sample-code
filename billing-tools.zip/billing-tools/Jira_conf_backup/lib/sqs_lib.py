from lib.ecv_lib import *
import logging
from botocore.exceptions import ClientError
logger = logging.getLogger(__name__)
import boto3
import os
import uuid
# delete_queue_url = os.environ['delete_queue_url']
# delete_region = os.environ['delete_region']
send_mail_queue = os.environ['send_mail_queue']
send_mail_dlq = os.environ['send_mail_dlq']
content_s3_bucket = os.environ['content_s3_bucket']
environment = os.environ['environment']
# Get the service resource
sqs = boto3.resource('sqs')
# Get the queue
queue = sqs.get_queue_by_name(QueueName=send_mail_queue)
dlq = sqs.get_queue_by_name(QueueName=send_mail_dlq)



def send_message(queue, message_body,attributes_list,error_message = ' '):
    """
    Send a message to an Amazon SQS queue.

    Usage is shown in usage_demo at the end of this module.

    :param queue: The queue that receives the message.
    :param message_body: The body text of the message.
    :param message_attributes: Custom attributes of the message. These are key-value
                               pairs that can be whatever you want.
    :return: The response from SQS that contains the assigned message ID.
    """
    system_name = attributes_list[0]
    function_name = attributes_list[1]
    fail_note = attributes_list[2]
    mail_subject = attributes_list[3]
    mail_sender = attributes_list[4]
    s_email = attributes_list[5]
    cc_reciver = attributes_list[6]
    att_s3_path = attributes_list[7]
    
    message_attributes={
                    'system_name':{
                        'StringValue':system_name,
                        'DataType':'String'
                        },
                    'function_name':{
                        'StringValue':function_name,
                        'DataType':'String' 
                        },
                    'fail_notification_mail':{
                        'StringValue':fail_note,
                        'DataType':'String' 
                        },
                    'subject': {
                        'StringValue': mail_subject,
                        'DataType': 'String'
                        },
                    'sender': {
                        'StringValue': mail_sender,        
                        'DataType': 'String'
                        },
                    'receiver': {
                        'StringValue': s_email,        
                        'DataType': 'String'
                        },
                    'cc':{
                        'StringValue': cc_reciver,
                        'DataType':'String'
                        },
                    'att_s3_path': {
                        'StringValue': att_s3_path,        
                        'DataType': 'String'
                        },
                    'error_message':{
                        'StringValue':error_message,
                        'DataType':'String'
                        },
                    'environment':{
                        'StringValue':environment,
                        'DataType':'String'
                        },    
                }
    
    if not message_attributes:
        message_attributes = {}

    print(message_body)

    try:
        response = queue.send_message(MessageBody=message_body,
        MessageAttributes=message_attributes)
    except ClientError as error:
        logger.exception("Send message failed: %s", message_body)
        raise error
    except Exception as e:
        logger.exception("Send message failed: %s", message_body)
        raise e
    else:
        return response

def get_message_attributes():
    result={
    'Author': {
        'StringValue': 'Daniel',
        'DataType': 'String'
        },
    'Author1': {
        'StringValue': 'Daniel',
        'DataType': 'String'
        },
    }
    return result
    
def receive_messages(queue, max_number, wait_time):
    """
    Receive a batch of messages in a single request from an SQS queue.

    Usage is shown in usage_demo at the end of this module.

    :param queue: The queue from which to receive messages.
    :param max_number: The maximum number of messages to receive. The actual number
                       of messages received might be less.
    :param wait_time: The maximum time to wait (in seconds) before returning. When
                      this number is greater than zero, long polling is used. This
                      can result in reduced costs and fewer false empty responses.
    :return: The list of Message objects received. These each contain the body
             of the message and metadata and custom attributes.
    """
    try:
        messages = queue.receive_messages(
            MessageAttributeNames=['All'],
            MaxNumberOfMessages=max_number,
            WaitTimeSeconds=wait_time,
        )
        for msg in messages:
            logger.info("Received message: %s: %s", msg.message_id, msg.body)
    except ClientError as error:
        logger.exception("Couldn't receive messages from queue: %s", queue)
        raise error
    else:
        return messages

def delete_messages(queue, messages):
    """
    Delete a batch of messages from a queue in a single request.

    Usage is shown in usage_demo at the end of this module.

    :param queue: The queue from which to delete the messages.
    :param messages: The list of messages to delete.
    :return: The response from SQS that contains the list of successful and failed
             message deletions.
    """
    try:
        entries = [{
            'Id': str(ind),
            'ReceiptHandle': msg.receipt_handle
        } for ind, msg in enumerate(messages)]
        response = queue.delete_messages(Entries=entries)
        if 'Successful' in response:
            for msg_meta in response['Successful']:
                msg = "Deleted Successful", messages[int(msg_meta['Id'])].receipt_handle
                logger.info(msg)
                return msg
        if 'Failed' in response:
            for msg_meta in response['Failed']:
                msg =  "Could not delete Failed",messages[int(msg_meta['Id'])].receipt_handle
                logger.warning(msg)
                
                return msg
    except ClientError:
        msg = "Couldn't delete messages from queue Failed", queue
        logger.exception(msg)
        return msg
    else:
        return response

def Send_DLQ_Message (message_body,message_attributes,error_message,has_exit = 'Y'):
    message_body = 'Error Message:'+ error_message +'\r\n' 
    send_message(dlq,message_body,message_attributes,error_message)
    if has_exit == 'Y':
        lambda_return_success(error_message)

def delete_message(receipt_handle):
    sqs_client = boto3.client("sqs", region_name=delete_region)
    response = sqs_client.delete_message(
        QueueUrl=delete_queue_url,
        ReceiptHandle=receipt_handle,
    )
    print(response)

def Send_Queue_Message (message_body,attributes_list,error_message = ' '):
    
    s3bucket = content_s3_bucket
    s3 = boto3.client('s3')
    file_name =uuid.uuid4().hex
    print(file_name)
    text_file = open( f"{'/tmp/'}/{file_name}" + ".txt", "w")
    text_file.write(message_body)
    text_file.close()
    s3_file_path = s3bucket + '/'+ file_name + ".txt" 
    try: 
        s3.upload_file(f"{'/tmp/'}/{file_name}" + ".txt", s3bucket , file_name + ".txt" ) 
    except Exception as e:
        print("An unexpected error occured uploading the Data files to S3") 
        print(str(e))
        return 'upload message_body to s3 error' + str(e)

    print("All Data files uploaded to S3 Ok") 
    
    send_message(queue,s3_file_path,attributes_list)