def has_string_empty(stringValue):
    if stringValue == None or stringValue.isspace() or stringValue == 'Null' or not stringValue:
        return True 
    else:
        return False

def has_length(stringValue,max_length):
    if len(stringValue) > max_length :
        return True 
    else:
        return False
        
def str_YN(x):
    if x == 'Y' or x == 'N':
        return True 
    else:
        return False