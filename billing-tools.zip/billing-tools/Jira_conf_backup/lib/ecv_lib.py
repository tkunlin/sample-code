import boto3
import os
import json

ssm_client = boto3.client('ssm')
# current_env = os.environ['environment']

def get_parameter():
    response = ssm_client.get_parameters(
        Names=[
            '/{}/Billing/Report/DB/mysql-host'.format(current_env),
            '/{}/Billing/Report/DB/mysql-user'.format(current_env),
            '/{}/Billing/Report/DB/mysql-password'.format(current_env),
            '/{}/Billing/Report/DB/mysql-db'.format(current_env),
        ],
        WithDecryption=False
    )
    return response

def parse_sql(filename):
     data = open(filename, 'r').readlines()
     stmts = []
     DELIMITER = ';'
     stmt = ''

     for lineno, line in enumerate(data):
         if not line.strip():
             continue

         if line.startswith('--'):
             continue

         if 'DELIMITER' in line:
             DELIMITER = line.split()[1]
             continue

         if (DELIMITER not in line):
             stmt += line.replace(DELIMITER, ';')
             continue

         if stmt:
             stmt += line
             stmts.append(stmt.strip())
             stmt = ''
         else:
             stmts.append(line.strip())
     return stmts

def lambda_return_success (body_value = ''):
    return {
        'statusCode': 200,
        'body': json.dumps(body_value)
    }