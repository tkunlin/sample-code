from lib.sqs_lib import *
from lib.verify_lib import *
from lib.ecv_lib import *
import os
from botocore.vendored import requests
import time
import re
import boto3
import datetime


nowdate=datetime.datetime.now().strftime("%Y/%m/%d")
system_name = os.environ['jira_system_name']
function_name = os.environ['jira_function_name']
fail_notification_mail = os.environ['fail_notification_mail']
Subject = os.environ['jira_subject'] + nowdate
Sender = os.environ['sender']
CC = os.environ['cc']
recipient = os.environ['recipient']

# Constants (DO NOT CHANGE)
JSON_DATA = b'{"cbAttachments": "true", "exportToCloud": "true"}'

mail_content = 'Hi sir,<br> Jira backup to s3 bucket success.<BR> Detail Info: <BR>'

# def lambda_handler(event, context):
#     global mail_content
#     main()

def jira_backup(account, username, token, json, folder):
    global mail_content
    # Create the full base url for the JIRA instance using the account name.
    url = 'https://' + account + '.atlassian.net'

    # Open new session for cookie persistence and auth.
    session = requests.Session()
    session.auth = (username, token)
    session.headers.update({"Accept": "application/json", "Content-Type": "application/json"})

    # Get task ID of backup.
    task_req = session.get(url + '/rest/backup/1/export/lastTaskId')
    task_id = task_req.text

    # set starting task progress values outside of while loop and if statements.
    task_progress = 0
    last_progress = -1
    global progress_req

    # Get progress and print update until complete
    while task_progress < 100:

        progress_req = session.get(url + '/rest/backup/1/export/getProgress?taskId=' + task_id)

        # Chop just progress update from json response
        try:
            task_progress = int(re.search('(?<=progress":)(.*?)(?=,)', progress_req.text).group(1))
            #print(progress_req.text)
        except AttributeError:
            print(progress_req.text)
            exit(1)

        if (last_progress != task_progress) and 'error' not in progress_req.text:
            print(task_progress)
            last_progress = task_progress
        elif 'error' in progress_req.text:
            print(progress_req.text)
            exit(1)

        if task_progress < 100:
            time.sleep(10)

    if task_progress == 100:

        download = re.search('(?<=result":")(.*?)(?=\",)', progress_req.text).group(1)
        
        msg = '1.Backup complete, downloading files.'
        mail_content = mail_content + msg + '<br>'
        print(msg)
        
        msg = '2.Backup file can also be downloaded from ' + url + '/plugins/servlet/' + download
        mail_content = mail_content + msg + '<br>'
        print(msg)

        date = time.strftime("%Y%m%d_%H%M%S")

        filename = account + '_backup_' + date + '.zip'

        file = session.get(url + '/plugins/servlet/' + download, stream=True)

        file.raise_for_status()

        with open(folder + filename, 'wb') as handle:
            for block in file.iter_content(1024):
                handle.write(block)
        
        msg = '3.' + filename + ' downloaded to ' + folder
        mail_content = mail_content + msg + '<br>'
        print(msg)
        
        S3Buckets = os.environ['S3Buckets']
        s3 = boto3.client('s3')
        s3.upload_file(folder + filename, S3Buckets, filename)
        os.remove(folder + filename)
        
        msg = '4. ' + filename +' finish to S3 (' + S3Buckets + ')'
        mail_content = mail_content + msg + '<br>'
        print(msg)
        
        message_attributes=[system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
        message_body = mail_content
        sent_result = Send_Queue_Message(message_body,message_attributes,error_message = ' ')
        print ('sent_result:' + str(sent_result))
        
        if sent_result == None:
            print('Message SentEnd !')
        else:
            mail_content = mail_content.replace('success','Error')
            print(str(sent_result))
            message_attributes= [system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
            msg = '<br> Jira backup send queue message error:\r\n' + str(sent_result)+ '<br>'
            mail_content = mail_content + msg
            print(msg)
            return Send_DLQ_Message(mail_content,message_attributes,mail_content)
        
def main():
    global mail_content
    message_attributes= [system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
    system_error_msg = 'Please check Jira_backup lamdba configuration Environment variables'
    
    # check message
    # 檢查空值
    if has_string_empty(system_name):
        msg = 'system_name Required.' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes, msg)
        
    if has_string_empty(function_name):
        msg = 'function_name Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_string_empty(fail_notification_mail):
        msg = 'fail_notification_mail Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_string_empty(Sender):
        msg = 'Sender Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_string_empty(Subject):
        msg = 'subject Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    if has_string_empty(CC):
        msg = 'CC Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    if has_string_empty(recipient):
        msg = 'recipient Required' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    
    # check length
    if has_length(system_name, 32):
        msg = 'system_name max length 32 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        message_attributes= [system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_length(function_name, 32):
        msg = 'function_name max length 32 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_length(fail_notification_mail, 128):
        msg = 'fail_notification_mail max length 128 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_length(Subject, 128):
        msg = 'subject max length 128 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    if has_length(Sender, 64):
        msg = 'sender max length 64 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        message_attributes= [system_name,function_name,fail_notification_mail,Subject,' ',' ',CC,' ']
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    if has_length(CC, 500):
        msg = 'CC max length 500 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
    
    if has_length(recipient, 500):
        msg = 'recipient max length 500 Bit' + system_error_msg
        print('Error Message:'+ str(msg))
        return Send_DLQ_Message('Unknown',message_attributes,msg)
        
    site = os.environ['jira_site']
    user_name = os.environ['jira_user']
    api_token = os.environ['jira_token']
    folder = '/tmp/'
    
    try:
        jira_backup(site, user_name, api_token, JSON_DATA, folder )
    except Exception as e:
        mail_content = mail_content.replace('success','Error')
        print(str(e))
        message_attributes= [system_name,function_name,fail_notification_mail,Subject,Sender,recipient,CC,' ']
        msg = '<br> Jira backup Error Message:\r\n' + str(e)+ '<br>'
        mail_content = mail_content + msg
        print(msg)
        return Send_DLQ_Message(mail_content,message_attributes,mail_content)

if __name__ == '__main__':
    main()