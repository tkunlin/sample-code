# ================================================================================= #
# Copyright 2023 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #
strCode = "jm.cBn, uLc.yhLau luxGprcrIpqcIxlxul lxdNmeVqwrxjuCunh mEph n"

from lib.db import DB
from lib import config
import boto3
from lib.get_auth import get_auth
import datetime
from dateutil.relativedelta import relativedelta
import sys
import csv
from pathlib import Path

home = str(Path.home())

def check_cost_explorer(bill_period):
    print("============  check_cost_explorer payer, ce, bill_item ==============")
    print("payeraccountid, cost bill_item, console cost, diff")
    payer_cost_obj={}
    db = DB(endpoint='main', database = config.ecloud_database)
    res = db.execute("SELECT account_no FROM bill_payer_account where hide = 'n'", have_result=True)['result']
    payeraccountlist = [item['account_no'] for item in res]
    res = db.execute(
        f'''
        SELECT payeraccountid, sum(totalcost) totalcost 
        from bill_item 
        where bill_period = '{bill_period}'  
        and billing_entity in ('AWS','AWS Marketplace') 
        group by payeraccountid
        ''',
        have_result=True)['result']
    for item in res:
        payer_cost_obj[item['payeraccountid']] = item['totalcost']
    # print(payer_cost_obj)

    db.close()
    writer = csv.DictWriter(open(f"{home}/result.csv","w"), ["payeraccountid", "cost bill_item", "console cost", "diff"])
    writer.writeheader()
    for payeraccount in payeraccountlist:
        auth = get_auth(payeraccount)
        ce = auth.client('ce')
        try:
            res = ce.get_cost_and_usage(
                TimePeriod={
                    'Start': ce_start_time,
                    'End': ce_end_time
                    },
                Granularity='MONTHLY',
                Metrics=['AmortizedCost','BlendedCost','NetAmortizedCost','NetUnblendedCost','NormalizedUsageAmount','UnblendedCost' , 'UsageQuantity']
            )
            
            ce_cost = res['ResultsByTime'][0]['Total']['UnblendedCost']['Amount']
            diff = float(ce_cost) - float(payer_cost_obj[payeraccount])
            
            if payeraccount not in payer_cost_obj:
                print("Payeraccount Not Found", payeraccount, ce_cost)
                continue
            if abs(diff) > 1:
                print(payeraccount, payer_cost_obj[payeraccount], ce_cost, diff)
            writer.writerow({
                "payeraccountid": payeraccount,
                "cost bill_item": payer_cost_obj[payeraccount], 
                "console cost": ce_cost, 
                "diff": diff
            })
        except Exception as e:
            print(e, f"{payeraccount} ce error" )
            writer.writerow({
                "payeraccountid": payeraccount,
                "cost bill_item": 'Acceess Deny', 
                "console cost": 'Acceess Deny', 
                "diff": 'Acceess Deny'
            })
    print(f"============= Done, output file {home}/result.csv ===================")

if __name__ == "__main__":
    bill_period = sys.argv[1]
    y, m = bill_period.split("/")
    mtime = datetime.datetime(int(y), int(m), 1)
    nmonth = (mtime + relativedelta(months=1)).replace(day=1)
    ce_start_time = f"{y}-{m}-01"
    ce_end_time = nmonth.strftime("%Y-%m-01")

    check_cost_explorer(bill_period)