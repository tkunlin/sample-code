import csv
from db import DB
import os
from get_auth import get_auth
import config
import boto3
import datetime
from dateutil.relativedelta import relativedelta
import gzip
from lib import insert_db


def error_log(db, bill_period, linkedaccountid, payeraccountid):
    res = insert_db(db, 'sumup_error', [{
        'linkedaccount': linkedaccountid, 
        'payeraccount': payeraccountid,
        'type': "sumup_awscur",
        "bill_period": bill_period
    }])

def calc_file(filename, payeraccount):
    cur_mfile = gzip.open(filename,'rt')
    # cur_mfile = open(filename, 'r', )
    cur_reader = csv.DictReader(cur_mfile)
    total_cur = {}
    for ind, row in enumerate(cur_reader):
        key = "{}_{}".format( row['lineItem/UsageAccountId'], payeraccount )
        if row['lineItem/LineItemType'] in ['SavingsPlanNegation', 'Credit', 'Refund']:
            usagequantity = 0.0
            totalcost = float(row['lineItem/UnblendedCost'])
        else:
            try:
                usagequantity = float(row['lineItem/UsageAmount'])
            except:
                usagequantity = 0
            try:
                totalcost = float(row['lineItem/UnblendedCost'])
            except:
                totalcost = 0

        if key not in total_cur:
            total_cur[key] = [usagequantity, totalcost ]
        else:
            total_cur[key][0] += usagequantity
            total_cur[key][1] += totalcost
    return total_cur

    
def download_file(auth, bucket, key, des):
    try:
        s3 = auth.client('s3')
        s3.download_file(bucket, key, des)
    except Exception as e:
        return False
    else:
        return True

def download_cur_file(payeraccount, s3_bucket, key):
    auth = get_auth(payeraccount)
    filename = key.split("/")[-1]
    filedir = f"./cur/{filename}"
    if download_file(auth, s3_bucket, key, filedir):
        return filedir
    else:
        return False

def insert_data(bill_period, res):
    db = DB(endpoint='main', database='ecloud')
    insert_list = []
    for key, val in res.items():
        linkedaccount,payeraccount  = key.split("_")
        usagequantity, totalcost = val
        insert_list.append({
            "bill_period": bill_period,
            "linkedaccount": linkedaccount,
            "payeraccount": payeraccount,
            "usagequantity": usagequantity,
            "cost":totalcost
        })
    insert_db(db, "sumup_awscur", insert_list)


def main(payeraccount, bill_period, s3_bucket, key):
    filedir = download_cur_file(payeraccount, s3_bucket, key)
    if filedir:
        res = calc_file(filedir, payeraccount)
        insert_data(bill_period, res)
        os.remove(filedir)
        print(res) 
    else:
        error_log(db, bill_period, "None", payeraccount)




if __name__ == '__main__':
    main("515175144484", '2020/10', "ecloudvalley-app-consolidated-billing", "CostUsageReportDaily/CostUsageReportDaily/20201101-20201201/CostUsageReportDaily-00001.csv.gz")
    