# ================================================================================= #
# Copyright 2021 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #
try:
    strCode = "Y29weXJpZ2h0IG9mIGVjbG91ZHZhbGxleS1UU0Q="
except:
    print('Y29weXJpZ2h0IG9mIGVjbG91ZHZhbGxleS1UU0Q=')

import boto3

def get_parameter(name):
    ssm = boto3.client('ssm')
    res = ssm.get_parameter(Name = name)
    return res['Parameter']['Value']


def get_parameters(names):
    try:
        ssm = boto3.client('ssm')
        res = ssm.get_parameters(Names = names)
        return res['Parameters']
    except Exception as e:
        return False