import boto3
import time

from sumup_tagreport_insert_db import main as tagreport_main
from sumup_awscur_insert_db import main as awscur_main
from tag_report_rerun import main as tagreport_run_main
from lib import insert_db
from db import DB

def error_log(bill_period, linkedaccountid, payeraccount, type_s):
    db = DB(endpoint='main', database='ecloud')
    res = insert_db(db, 'sumup_error', [{
        'linkedaccount': linkedaccountid, 
        'payeraccount': payeraccount,
        'type': type_s,
        "bill_period": bill_period
    }])
    db.close()

def main():
    client = boto3.client("sqs", region_name='us-west-2')
    while True:
        response = client.receive_message(
            QueueUrl='https://sqs.us-west-2.amazonaws.com/006920391431/accounting_test',
            MaxNumberOfMessages=1
        )
        try:
            print(response)
        except:
            client.delete_message(
                QueueUrl='https://sqs.us-west-2.amazonaws.com/006920391431/accounting_test',
                ReceiptHandle=response['Messages'][0]['ReceiptHandle']
            )
        if 'Messages' in response:
            client.delete_message(
                QueueUrl='https://sqs.us-west-2.amazonaws.com/006920391431/accounting_test',
                ReceiptHandle=response['Messages'][0]['ReceiptHandle']
            )
            message = response['Messages'][0]['Body']
            mlist = message.split("|")
            if mlist[0]=='tag':
                # bill_period, linkedaccountid
                try:
                    tagreport_main(mlist[1], mlist[2])
                except Exception as e:
                    error_log(mlist[1], mlist[2], "None", "tagreport_error")
                    
            elif mlist[0]=="cur":
                try:
                    # payeraccount, bill_period, s3_bucket, key
                    awscur_main(mlist[1], mlist[2], mlist[3], mlist[4])
                except Exception as e:
                    index = mlist[4].split("/")[-1][21:26]
                    error_log(mlist[2], index, mlist[1], "awscur_error")
            elif mlist[0]=="runtag":
                try:
                    # bill_period, linkedaccount, payeraccount, customer_type
                    tagreport_run_main(mlist[1], mlist[2], mlist[3], mlist[4])
                except Exception as e:
                    error_log(mlist[1], mlist[2], mlist[3], mlist[4], "rerun_tag_report_error")
                    
        else:
            break
        time.sleep(3)


if __name__ == '__main__':
    main()
    