import pdfplumber
from db import DB
import config
from queue import Queue
import threading
import time
import os

start_t = time.time()

jobq = Queue()

process_num = 2

bill_period = '2020/09'
ym = bill_period.replace("/","")

def job():
    while jobq.qsize() > 0:
        obj = jobq.get()
        if compare(obj):
            # print("Success", obj['file'])
            pass
        else:
            print("error", obj['file'])


def compare(obj):
    if not os.path.isfile(obj['file']):
        return False
    pdf = pdfplumber.open(obj['file'])
    page = pdf.pages[0]
    text = page.extract_text()
    text_line = text.split("\n")
    flag = True
    p_ind = -1
    for ind, text in enumerate(text_line):
        # print(text[-5:], "繳款截止日" == text[-5:])
        if "缴款截止日" == text[-5:]:
            p_ind = ind + 2
            flag=False
            break
        elif "Payment Due Date" == text[-16:]:
            p_ind = ind + 2
            flag=False
            break
        elif "繳款截止日" == text[-5:]:
            p_ind = ind + 2
            flag=False
            break
    if flag:
        return False

    sumrate_pdf = float(text_line[p_ind].split()[-2].replace(",",""))
    if sumrate_pdf != obj['sumrate']:
        return False
    return True


db = DB(database=config.ecloud_database, endpoint="main")
sql = "select bill_customer, cno, sumrate, linkedaccountid from bill_invoice_revenue where bill_period = '{}' and cno like 'C%';".format(bill_period)
res = db.execute(sql, have_result = True)['result']


for item in res:
    filename = "{}-{}-{}-{}.pdf".format(ym, item['cno'],item['bill_customer'],item['linkedaccountid'])
    jobq.put({"file":"./invoice/{}".format(filename), "sumrate": float(item['sumrate'])})

thread_list = []

for i in range(process_num):
    t = threading.Thread(target=job)
    t.start()
    thread_list.append(t)

for i in thread_list:
    i.join()



print("Done", time.time()-start_t)
    


