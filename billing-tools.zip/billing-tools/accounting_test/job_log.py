import pymysql
import pytz
import datetime
import time
from enum import Enum
import config
from db import DB

class Status(Enum):
    RUNNING = 1
    SUCESS = 2
    FAILED = 3


# class Database:
#     host = config.jobhost
#     user = config.jobuser
#     password = config.jobpassword
#     db = 'atlas'


#     def __init__(self):
#         self.connection = pymysql.connect( host = self.host, user = self.user, 
#         password = self.password, database = self.db, charset='utf8')
#         self.cursor = self.connection.cursor()


#     def execute(self, query, values = None):
#         try:
#             if values == None:
#                 self.cursor.execute(query)
#             else:
#                 self.cursor.execute(query, values)
#             self.connection.commit()
#         except Exception as e:
#             print(e)
#             self.connection.rollback()

        
class JobLog:
    def __init__(self):
        self.table_name = "at_job_log"
        self.job_name = None
        self.start_time = datetime.datetime.now(pytz.timezone('Asia/Taipei'))
        self.status = Status.RUNNING.value
        self.title = ""
        self.result = ""
    
    def set_job_name(self,job_name):
        self.job_name = job_name

    def set_job_title(self,title):
        self.title = title

    def log(self, *logstr):
        self.result += str(datetime.datetime.now()) + ": " 
        for s in logstr:
            self.result += str(s) + "  "
            print(str(datetime.datetime.now()) + ":" + str(s))
            # self.result = self.result + str(datetime.datetime.now()) + ":" + str(logstr) + " \n"
        self.result += "\n"


    def start(self):
        if self.job_name is None:
            raise Exception("No job name")
        else:
            self.__insert()

    
    def __insert(self):
        db = DB(config.atlas_database,endpoint='job')
        job = {
            "job_name":         self.job_name,
            "job_start_time":   self.start_time.strftime("%Y-%m-%d-%H:%M:%S"),
            "job_status":       self.status,
            "job_title":        self.title,
            "job_result":       self.result
        }
        placeholders = ', '.join(['%s'] * len(job))
        columns = ', '.join(job.keys())

        sql = "INSERT INTO %s ( %s ) VALUES ( %s )" % ( self.table_name, columns, placeholders)
        db.execute(sql, tuple(job.values()))
        db.close()

    def add_message(self, message):
        self.result += str(message) + "\n"
        print(message)


    def ending(self):
        """
        Setting the end time
        """
        db = DB(config.atlas_database,endpoint='job')
        job = {
            "job_stop_time":     datetime.datetime.now(pytz.timezone('Asia/Taipei')).strftime("%Y-%m-%d-%H:%M:%S"),
            "job_status":       Status.SUCESS.value,
            "job_result":       self.result
        }
        job_start_time = self.start_time.strftime("%Y-%m-%d-%H:%M:%S")
        columns = [ key + "=%s" for key in job]

        # print(", ".join([1,2,3]))
        sql = "UPDATE %s SET %s WHERE job_start_time = '%s' AND job_name = '%s' AND job_title = '%s'" % ( self.table_name, ", ".join(columns), job_start_time, self.job_name, self.title)
        print(sql)
        db.execute(sql, tuple(job.values()))
        db.close()
        
    def error(self, *error_str):
        for s in error_str:
            self.result += str(s) + "\n"
        # self.result += str(error_str)
        db = DB(config.atlas_database,endpoint='job')
        job = {
            "job_stop_time":     datetime.datetime.now(pytz.timezone('Asia/Taipei')).strftime("%Y-%m-%d-%H:%M:%S"),
            "job_status":       Status.FAILED.value,
            "job_result":       self.result
        }
        job_start_time = self.start_time.strftime("%Y-%m-%d-%H:%M:%S")
        columns = [ key + "=%s" for key in job]

        sql = "UPDATE %s SET %s WHERE job_start_time = '%s' AND job_name = '%s' AND job_title = '%s'" % ( self.table_name, ", ".join(columns), job_start_time, self.job_name, self.title)
        print(sql)
        db.execute(sql, tuple(job.values()))
        db.close()