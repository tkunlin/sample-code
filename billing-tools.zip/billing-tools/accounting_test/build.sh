

docker build -t accounting_test .
eval $(aws ecr get-login --no-include-email --region us-west-2)
docker tag accounting_test:latest 006920391431.dkr.ecr.us-west-2.amazonaws.com/accounting_test:latest
docker push 006920391431.dkr.ecr.us-west-2.amazonaws.com/accounting_test:latest