import pymysql
import config

class DB:
    def __init__(self,database="atlas", endpoint = "main"):
        if endpoint == "main":
            self.host = config.host
            self.user = config.user
            self.password = config.password
            self.db = database
        elif endpoint == "local":
            self.host = config.localhost
            self.user = config.localuser
            self.password = config.localpassword
            self.db = config.localdatabase
        elif endpoint == "job":
            self.host = config.jobhost
            self.user = config.jobuser
            self.password = config.jobpassword
            self.db = database
        self.connect()

    def connect(self):
        self.conn = pymysql.connect(host=self.host, user=self.user, password=self.password, db=self.db, local_infile = True, charset='utf8')
        self.cur = self.conn.cursor( pymysql.cursors.DictCursor )

        # if islocal:
        #     self.database=database
        #     self.conn = pymysql.connect(host='localhost', user='root', db=database, local_infile = True)
        # else:
        #     if database == "ecloud": 
        #         self.database = "ecloud"
        #         self.conn = pymysql.connect(config.host, config.user, config.password, 'ecloud', local_infile = True)
        #     else:
        #         self.database = "atlas"
        #         self.conn = pymysql.connect(config.host, config.user, config.password, 'atlas', local_infile = True)
                
    def reconnect(self):
        try:
            self.conn.close()
            self.connect()
        except Exception as e:
            print(e)

    def execute(self, sql, insert_list = None, have_result = False, get_cursor = False): 
        try:
            if insert_list == None:
                self.cur.execute (sql)
            else:
                self.cur.execute(sql,tuple(insert_list))
            self.conn.commit()
        except (AttributeError, pymysql.OperationalError) as e:
            self.reconnect()
            ## and try again
            self.conn.rollback()
            print("ERROR", sql)
            print(e)
            return {'success':False, 'err': str(e)}
        except Exception as e:
            if 'Lock wait timeout exceeded' in str(e):
                self.reconnect()
                self.conn.rollback()
                return {'success':False, 'err': str(e)}
            else:
                self.conn.rollback()
                return {'success':False, 'err': str(e)}
        
        if have_result:
            ans = self.cur.fetchall()
            dict_result = []
            for row in ans:
                dict_result.append(dict(row))
            return {'success':True, 'result' : dict_result }
        elif get_cursor:
            return {'success':True, 'cursor':self.cur}
        else:
            return {'success':True}


    def close(self):
        try:
            self.conn.close()
        except Exception as e:
            print(e)


class LocalMySQL:
    def __init__(self):
        self.conn = pymysql.connect(
            host='localhost',
            user='root',
            db= 'atlas',
            local_infile = True
        )
        self.cur = self.conn.cursor( pymysql.cursors.DictCursor )

    def reconnect(self):
        try:
            self.conn.close()
            self.conn = pymysql.connect(
                host='localhost',
                user='root',
                db= 'atlas',
                local_infile = True
            )
            self.cur = self.conn.cursor( pymysql.cursors.DictCursor )
        except Exception as e:
            print(e)

    def execute(self, sql, have_result = False):
        try:
            self.cur.execute(sql)
            self.conn.commit()
        except Exception as e:
            print(e)
            self.conn.rollback()
            return False
        
        if have_result == False:
            return
        else:
            ans = self.cur.fetchall()
            dict_result = []
            for row in ans:
                dict_result.append(dict(row))
            return dict_result



class Aurora:
    def __init__(self,database="atlas"):
        if database == "ecloud": 
            self.database = "ecloud"
            self.conn = pymysql.connect(config.host, config.user, config.password, 'ecloud', local_infile = True)
        else:
            self.database = "atlas"
            self.conn = pymysql.connect(config.host, config.user, config.password, 'atlas', local_infile = True)
            
        self.cur = self.conn.cursor( pymysql.cursors.DictCursor )


    def reconnect(self):
        try:
            self.conn.close()
            self.conn = pymysql.connect(config.host, config.user, config.password, self.database, local_infile = True)
            self.cur = self.conn.cursor( pymysql.cursors.DictCursor )
        except Exception as e:
            print(e)

    def execute(self, sql, insert_list = None, have_result = False): 
        try:
            if insert_list == None:
                self.cur.execute (sql)
            else:
                self.cur.execute(sql,tuple(insert_list))
            self.conn.commit()
        except Exception as e:
            print(e)
            self.conn.rollback()
            raise Exception('SQL ERROR:' + sql.replace("\n"," "))
            return False
        
        if have_result == False:
            return
        else:
            ans = self.cur.fetchall()
            dict_result = []
            for row in ans:
                dict_result.append(dict(row))
            return dict_result
