import boto3
import os
import config
import datetime
from dateutil.relativedelta import relativedelta
from get_auth import get_auth
from db import DB
import json
import csv
from lib import generate_insert_list_sql
import sys

db = DB(endpoint="main",database=config.ecloud_database)
localdb = DB(endpoint="local",database=config.localdatabase)
errf = open("/tmp/error.log",'a')

def get_format_period(y, m):
    bdatetime = datetime.datetime(int(y), int(m), int(1))
    next_month = (bdatetime.replace(day = 1) + datetime.timedelta(days = 32))
    return bdatetime.strftime("%Y%m01") + "-" + next_month.strftime("%Y%m01")


def get_s3_config(s3_bucket):
    """
    s3_bucket
    setting self.s3_config
        {
            bucket_name,
            folder_name,
            file_name
        }
    """
    s3_config={}
    s3_config['bucket_name'] = s3_bucket
    s3_config['folder_name'] = "CostUsageReport{0}/CostUsageReport{0}".format(
        "Hourly" )
    s3_config["file_name"] = "CostUsageReport{}-Manifest.json".format(
       "Hourly" )
    return s3_config

def get_tagmapping_sql(payeraccountid, y, m):
    
    sql = "SELECT account_no, s3_bucket FROM bill_payer_account WHERE account_no = '{}';".format(payeraccountid)
    result = db.execute(sql,have_result = True)
    print(result)
    if result['success']:
        s3_bucket = s3_bucket = "".join(result['result'][0]['s3_bucket'].split()).lower()
        s3_config = get_s3_config(s3_bucket)
        
    else:
        raise Exception('')
    auth = get_auth(payeraccountid)
    s3 = auth.resource('s3')
    ## get schema
    format_period = get_format_period(y,m )
    manifest_json = s3.Object("{}".format(s3_config['bucket_name']), "{}/{}/{}".format(
            s3_config['folder_name'], 
            format_period, 
            s3_config['file_name']
        )).get()['Body'].read().decode()
    manifest_json = json.loads(manifest_json)
    for obj in manifest_json['additionalArtifactKeys']:
        if obj['artifactType'] == "RedshiftCommands":
            command = s3.Object("{}".format(s3_config['bucket_name']), "{}".format(obj["name"])).get()['Body'].read().decode()
            break

    return command



def exec_command(commands, ym,payeraccount):
    sql = "drop if exists table {}".format("AWSBilling{}_{}_Hourly_tagMapping".format(ym, payeraccount))
    res = localdb.execute(sql)
    for command in commands.split(";")[2:]:
        command = command.replace("\n","")
        command = command.replace("AWSBilling{}".format(ym), "AWSBilling{}_{}_Hourly".format(ym, payeraccount))
        res = localdb.execute(command)

def update_shield_advance(table):
    print("update_shield_advance")
    sql = """
    update {} set unit_price = case 
    when lineitem_lineitemdescription like '%CloudFront%' and lineitem_lineitemdescription like '%First%' then 0.025
    when lineitem_lineitemdescription like '%CloudFront%' and lineitem_lineitemdescription like '%Next 400 TB%' then 0.02
    when lineitem_lineitemdescription like '%CloudFront%' and lineitem_lineitemdescription like '%Next 500 TB%' then 0.015
    when ( lineitem_lineitemdescription like '%EIP%' or lineitem_lineitemdescription like '%ELB%' or lineitem_lineitemdescription like '%GlobalAccelerator%' ) and lineitem_lineitemdescription like '%First%' then 0.05
    when ( lineitem_lineitemdescription like '%EIP%' or lineitem_lineitemdescription like '%ELB%' or lineitem_lineitemdescription like '%GlobalAccelerator%' ) and lineitem_lineitemdescription like '%Next 400 TB%' then 0.04
    when ( lineitem_lineitemdescription like '%EIP%' or lineitem_lineitemdescription like '%ELB%' or lineitem_lineitemdescription like '%GlobalAccelerator%' ) and lineitem_lineitemdescription like '%Next 500 TB%' then 0.03
    else '' end
    where product_ProductName = 'AWS Shield' and lineItem_UsageType like '%DataTransfer%'
    """.format(table)
    res = localdb.execute(sql)
    if not res['success']:
        print("Error update_shield_advance table", res['err'])
    
    
def shield_monthly_fee_hide(table):
    print("shield_monthly_fee_hide")
    sql = """DELETE FROM {} 
    where product_ProductName = 'AWS Shield' 
    and lineItem_UsageType = 'Shield-Monthly-Fee'
    and lineItem_lineitemtype = 'Usage'
    """.format(table)
    res = localdb.execute(sql)
    if not res['success']:
        print("Error Shield_Monthly_Fee_hide table")

def shield_ocb_hide(table):
    print("shield_ocb_hide")
    sql = """DELETE FROM {} 
    where product_ProductName = 'OCBAWS Shield' 
    and lineItem_UsageType = 'UE-OCB'
    and lineItem_lineitemtype = 'Fee'
    """.format(table)
    res = localdb.execute(sql)
    if not res['success']:
        print("Error shield_ocb_hide table")
        
        
def dev_support_hide(table):
    print("dev_support_hide")
    sql = """DELETE FROM {} 
    where product_ProductName = 'AWS Support (Developer)' 
    """.format(table)
    res = localdb.execute(sql)
    if not res['success']:
        print("Error dev_support_hide table")
        
        
def business_support_hide(table):
    print("business support hide")
    sql = """DELETE FROM {} 
    where product_ProductName = 'AWS Support (Business)' 
    """.format(table)
    res = localdb.execute(sql)
    if not res['success']:
        print("Error business_support_hide table")


def hide_tax(table):
    print("hide tax")
    sql = """DELETE FROM {}
    WHERE lineItem_LineItemType = 'Tax'
    """.format(table)
    res = localdb.execute(sql)
    if not res['success']:
        print("Error hide_tax")


def insert_dop(bill_period, linkedaccountid, tablename):
    proddb = DB(database=config.ecloud_database, endpoint="main")
    sql = """SELECT usagetype as lineitem_usagetype, 
            itemdescription as lineitem_lineitemdescription, 
            usagequantity as lineitem_usageamount, 
            unitprice as unit_price, 
            bp.productname as product_productname
    from {0} left join bill_product bp ON bp.id = bill_product
    WHERE bill_period = '{1}'
    AND linkedaccountid = '{2}'
    AND dop = 'y'
    AND bill_product = 32
    AND {0}.hide = 'n';
    """.format("bill_item",bill_period, linkedaccountid)
    try:
        res = proddb.execute(sql, have_result=True)['result']
        if len(res) > 0:
            sql, mlist = generate_insert_list_sql(tablename, res)
            localdb.execute(sql, insert_list=mlist)
    except Exception as e:
        raise Exception(e)
    else:
        proddb.close()

def download_file_from_tw03(s3_bucket, key, filename):
    auth = get_auth("515175144484")
    s3 = auth.client('s3')
    s3.download_file(s3_bucket, key, filename)
    
def download_file(s3_bucket, key, filename):
    s3 = boto3.client("s3")
    print("======== download ===========")
    print(s3_bucket, key, filename)
    s3.download_file(s3_bucket, key, filename)

def process(bill_period, ymd, y_m, ym, y,m, linkedaccount, payeraccount, function_list, customer_type_list):
    command = get_tagmapping_sql(payeraccount, y, m )
    exec_command(command,ym, payeraccount)
    localdb.execute("Truncate cur_{}".format(linkedaccount))
    filename = "file.sql"
    try:
        # download_file_from_0069("atlas-billing-dev", "cur_hourly/dev/{}/cur_{}_{}.sql".format(ymd.replace("-", "/"), linkedaccount, payeraccount), filename)
        print("cur_hourly/Prod/{}/cur_{}_{}.sql".format(ymd, linkedaccount, payeraccount))
        download_file(config.prod_cur_backup_bucket, "cur_hourly/Prod/{}/cur_{}_{}.sql".format(ymd, linkedaccount, payeraccount), filename)
        # os.system("aws s3 cp s3://atlas-billing-dev/cur_hourly/atlas-dev/{}/cur_{}_{}.sql {}".format(ymd, linkedaccount, payeraccount, filename))
        os.system("mysql -h {} -u {} -p{} {} < {}".format(config.localhost, config.localuser, config.localpassword, config.localdatabase, filename))
        print(customer_type_list)
        for customer_type in customer_type_list:
            table = "cur_{}".format(linkedaccount)
            # insert_dop(bill_period, linkedaccount, table)
            for function in function_list:
                print(f"execute {function.__name__}")
                function(table)            
            os.system("python3 tag_report.py -l {} -d {} -t {}".format(linkedaccount, ymd.replace("-","/"),customer_type))
        os.remove(filename)
    except Exception as e:
        errf.write("{} {} {}\n".format(e, bill_period, linkedaccount))



def scan_eshield_ocb(bill_period):
    sql = f"""SELECT distinct linkedaccountid, payeraccountid 
    from bill_item where bill_period = '{bill_period}' and hide = 'y'
    and bill_product = 460
    """
    res = db.execute(sql, have_result=True)['result']
    return [shield_ocb_hide, [i["linkedaccountid"] +":"+ i["payeraccountid"] for i in res]]

def scan_eshild_unitprice(bill_period):
    sql = f"""SELECT distinct linkedaccountid, payeraccountid 
    from bill_item where bill_period = '{bill_period}' and unitprice <> ''
    and bill_product = 125  and dop = ''
    """
    res = db.execute(sql, have_result=True)['result']
    return [update_shield_advance, [i["linkedaccountid"] +":"+ i["payeraccountid"] for i in res]]

def scan_support(bill_period):
    sql = f"""
    select linkedaccountid, payeraccountid , bill_product FROM bill_item bi where bill_period = '{bill_period}' and bill_customer in (
    select bill_customer FROM (
    select a.bill_customer,b.cno,a.linkedaccountid ,group_concat(distinct billing_entity) as group_entity, sum(TotalCost), sum(UnitPrice) 
    FROM bill_item a left join bill_customer b on a.bill_customer =b.id where bill_period = '{bill_period}' and bill_product in (18, 19,270) and bill_customer in (  
    select bill_customer from (  
    select billing_entity, bill_customer   
    FROM bill_item   
    where bill_period = '{bill_period}' and bill_product in (18, 19, 270)  
    group by billing_entity , bill_customer ) a group by bill_customer having count(*) > 1  
    ) 
    group by bill_customer having group_entity like '%AWS-Ecloud-SPL%' 
    ) a ) and hide = 'y' and bill_product in (18, 19, 270) and billing_entity = 'AWS' group by bill_customer , bill_product
    """
    res = db.execute(sql, have_result=True)['result']
    dev_support = [dev_support_hide, []]
    bs_support = [business_support_hide, []]
    for i in res:
        key = i["linkedaccountid"] +":"+ i["payeraccountid"]
        if i['bill_product'] == 18:
            dev_support[1].append(key)
        elif i['bill_product'] == 19:
            bs_support[1].append(key)
    return dev_support, bs_support

def scan_hide_tax(bill_period):
    sql = f"""select distinct linkedaccountid , payeraccountid FROM bill_item bi where bill_period = '{bill_period}'
    and lineitem_type = 'Tax' and hide = 'y'"""
    res = db.execute(sql, have_result=True)['result']
    return [hide_tax, [i["linkedaccountid"] +":"+ i["payeraccountid"] for i in res]]

def is_si(linkedaccountid):
    sql = f"""select bill_customer from bill_customer_si bcs
    left join bill_customer bc on bc.id = bcs.bill_customer
    where bc.linkedaccountid = '{linkedaccountid}' and bc.hide = 'n'
    """
    res = db.execute(sql, have_result=True)['result']
    return len(res) > 0

def combine(res_list):
    all_res = {}
    for item in res_list:
        for linkpayer in item[1]:
            if linkpayer not in all_res:
                all_res[linkpayer] = [item[0]]
            else:
                all_res[linkpayer].append(item[0])
    return all_res
        
def print_execute(all_res, bill_period):
    # main("2021/09","242287800230","127965512393",[dev_support_hide], ["cb"])
    for key,values in all_res.items():
        linked,payer = key.split(":")
        type_list = ["cb"]
        if is_si(linked):
            type_list.append("si")
        type_str = '", "'.join(type_list)
        linked = linked.rjust(12,"0")
        print(f""" "{bill_period}", "{linked}", "{payer}",  ["{type_str}"]) """)


def main(bill_period, linkedaccount, payeraccount, function_list, customer_type_list):
    y, m = bill_period.split("/")
    ym = bill_period.replace("/","")
    y_m = bill_period.replace("/","-")

    date = datetime.datetime(int(y), int(m), 1) + relativedelta(months=1) - relativedelta(days=1)
    ymd=date.strftime("%Y/%m/%d")
    linkedaccount = "{:0>12}".format(linkedaccount)
    print(bill_period, ymd, y_m, ym,y,m,linkedaccount, payeraccount, function_list, customer_type_list)
    process(bill_period, ymd, y_m, ym,y,m,linkedaccount, payeraccount, function_list, customer_type_list)


def __get_all_linkedaccount_raw_table() -> list:
    sql = """SELECT table_name FROM information_schema.tables
            WHERE table_schema = '{}'
            and table_name like 'cur_%';
    """.format(localdb.db)
    res = localdb.execute(sql, have_result=True)
    if not res["success"]:
        raise Exception(res['err'])
    return [row["table_name"] for row in res['result']]

def clean_all_linkedaccount_raw_table():
    all_tables = __get_all_linkedaccount_raw_table()
    clean(localdb, all_tables)

def clean(db, tables):
    """clean db tables

    Args:
        db (DB): access database
        tables (List[str]): tables
    """
    for table in tables:
        sql = f"DROP TABLE IF EXISTS {table};"
        res = db.execute(sql)
        if not res['success']:
            raise Exception(f"Error SQL:{sql} \n{res['err']}")

    
if __name__ == "__main__":
    # update_shield_advance
    # update_shield_advance_next
    # shield_monthly_fee_hide
    # shield_ocb_hide
    # hide_tax
    print("""========== Rerun Tag report ===============""")
    
    bill_period = sys.argv[1]
    db = DB(database='ecloud', endpoint='main')

    print("This tool should run in `STAGE` Enviromnent, and please make sure stage db already restore the latest data.")
    print("DB host Check:", db.host)
    print("DB had restored? : (Y/n)?")
    check = input()
    if check not in ("Y", "y"):
        exit()
    res_list = []

    res_list.append(scan_eshield_ocb(bill_period))
    res_list.append(scan_eshild_unitprice(bill_period))
    ds, bs = scan_support(bill_period)
    res_list.append(ds)
    res_list.append(bs)
    res_list.append(scan_hide_tax(bill_period))
    all_res = combine(res_list)
    print("================================================")
    print_execute(all_res, bill_period)
    print("================================================")
    print("Start Running...")
    for key,values in all_res.items():
        linked,payer = key.split(":")
        type_list = ["cb"]
        if is_si(linked):
            type_list.append("si")
        type_str = '", "'.join(type_list)
        linked = linked.rjust(12,"0")
        print(bill_period, linked, payer, values, type_list)
        main(bill_period, linked, payer, values, type_list)
    clean_all_linkedaccount_raw_table()
    print(f"""Done. Please check s3://{config.tag_report_bucket}/{config.tag_report_prefix}/{bill_period.replace('/', '')}/

And cp tag-report to production bucket
ex: aws s3 cp s3://{config.tag_report_bucket}/{config.tag_report_prefix}/{bill_period.replace('/', '')}/ s3://ecloud-tag-report/cur/{bill_period.replace('/', '')}/ --recursive
""")
    
