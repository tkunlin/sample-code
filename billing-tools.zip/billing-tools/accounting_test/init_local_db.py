from db import DB
import os
import config


localdb = DB(config.localdatabase,endpoint="local")
proddb = DB(config.ecloud_database,endpoint="main")
# aurora_db = DB('atlas')

def generate_insert_list_sql(table,mlist):
    # get format
    if len(mlist) == 0:
        raise Exception("generate insert list error")
    obj = mlist[0]
    temp_column_list = list(obj.keys())
    column_list = []
    for item in temp_column_list:
        column_list.append("`{}`".format(item))
    #columns = key, key ,...
    columns = ', '.join(column_list)
    #values_holder = (%s , %s, %s, ...) 
    values_holder = "(" + ", ".join(['%s'] * len(obj)) + ")"
    #placeholders = values_holder, values_holder, values_holder ...
    placeholders = ", ".join([values_holder] * len(mlist))
    values = tuple()
    for obj in mlist:
        values = values + tuple(obj.values())
    sql = "INSERT INTO %s ( %s ) VALUES  %s " % (table, columns, placeholders)
    # print(values)
    return sql, values


def init_local_db(localdb=localdb, aurora = proddb):
    def setting_primary_key(db,table,key):
        sql = """
        ALTER TABLE {}
        ADD PRIMARY KEY ({}); 
        """.format(table,key)
        db.execute(sql)
    # aurora = Aurora(database="ecloud")
    
    update_table(aurora, localdb, 'bill_product')
    setting_primary_key(localdb,'bill_product','id')
    update_table(aurora, localdb, 'bill_customer')
    setting_primary_key(localdb,'bill_customer','id')

    update_table(aurora, localdb, 'bill_price1')
    setting_primary_key(localdb,'bill_price1','id')

    update_table(aurora, localdb, 'bill_cdn')
    setting_primary_key(localdb,'bill_cdn','id')

    update_table(aurora, localdb, 'bill_payer_account')
    setting_primary_key(localdb,'bill_payer_account','id')

    # update_table(aurora, localdb, 'region_code_mapping', False)
    update_table(aurora, localdb, 'bill_region')
    setting_primary_key(localdb,'bill_region','id')

    update_table(aurora, localdb, 'ri_instance_base_type')

    update_table(aurora, localdb, 'bill_price_si')
    setting_primary_key(localdb,'bill_price_si','id')

    update_table(aurora, localdb, 'bill_customer_si', is_alter_id=False)

    update_table(aurora, localdb, 'bill_savingplan_pricinglist')
    setting_primary_key(localdb,'bill_savingplan_pricinglist','id')


def load_table_to_local(sqlfile):
    print("load table", sqlfile)
    os.system("mysql -h {} -u {} -p{} {} < {}".format(
        config.localhost, config.localuser, config.localpassword, config.localdatabase, sqlfile
    ))
    print("done load", sqlfile)
    os.remove(sqlfile)


def update_table(fromdb, todb, tablename, is_alter_id = True):
    print("UPDATING " + tablename)
    
    sql = "DROP TABLE IF EXISTS {};".format(tablename)
    todb.execute(sql)
    sql = "SHOW CREATE TABLE {}".format(tablename)
    res = fromdb.execute(sql, have_result=True)['result']
    sql = res[0]['Create Table']
    # print(sql)
    todb.execute(sql)
    
    if is_alter_id:
        sql = "ALTER TABLE {} CHANGE id id INT(11) NOT NULL;".format(tablename)
        todb.execute(sql)
    # sql = "ALTER TABLE {} DROP PRIMARY KEY;".format(tablename)
    # db_execute(todb,sql)
    
    sql = "SELECT * FROM {};".format(tablename)
    res = fromdb.execute(sql, have_result = True)['result']
    
    if res is False:
        raise Exception("fromdb failed")
    
    sql, insert_list = generate_insert_list_sql(tablename, res)
    # db_execute(todb,sql,insert_list=insert_list)
    todb.execute(sql, insert_list = insert_list)


def dump_table(table):
    print("start dump", table)
    os.system("mysqldump -h {} -u {} -p{} {} {} > {}.sql".format(
        config.host, config.user, config.password, config.ecloud_database,
        table, table
    ))
    print("done dump", table)
    return "{}.sql".format(table)


# init_local_db()
table_list = [
    "bill_cdn",
    "bill_customer",
    "bill_payer_account",
    "bill_price1",
    "bill_price_si",
    "bill_product",
    "bill_region",
    "ri_instance_base_type",
    "bill_customer_si"
]
for table in table_list:
    sqlfile = dump_table(table)
    load_table_to_local(sqlfile)