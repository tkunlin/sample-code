import boto3
from db import DB
import sys
from get_auth import get_auth
import datetime
from dateutil.relativedelta import relativedelta

def get_cur_file_list(payeraccount, s3_bucket, format_period):
    auth = get_auth(payeraccount)
    s3 = auth.client("s3")
    paginator = s3.get_paginator('list_objects_v2')

    response_iterator = paginator.paginate(
        Bucket = s3_bucket,
        Prefix = 'CostUsageReport{0}/CostUsageReport{0}/{1}'.format("Daily", format_period),
    )
    file_list = []
    for page in response_iterator:
        if 'Contents' not in page:
            return []
            
        for item in page['Contents']:
            if item['Key'][-6:] == 'csv.gz':
                file_list.append(item['Key'])
    return file_list


if __name__ == '__main__':

    mtype = sys.argv[1]

    db = DB(endpoint='main', database='ecloud')
    sqs = boto3.client("sqs", region_name='us-west-2')
    if mtype == "tag":
        res = db.execute("""SELECT cno, linkedaccountid, bill_period 
                            FROM bill_invoice_revenue 
                            WHERE bill_period = '2021/04'
                            AND cno like 'C%' 
                            -- AND bill_customer in (select bill_customer from bill_customer_si)
                            AND totalmoney > 0""", have_result=True)

        for item in res['result']:
            bill_period= item['bill_period']
            linkedaccountid = item['linkedaccountid']
            message = f"tag|{bill_period}|{linkedaccountid}|cb"
            sqs.send_message(
                QueueUrl='https://sqs.us-west-2.amazonaws.com/006920391431/accounting_test',
                MessageBody=message,
            )

    elif mtype == "cur":
        base_month = datetime.datetime(2020,11,1)
        res = db.execute("""SELECT account_no, s3_bucket
                            FROM bill_payer_account """, have_result=True)
        
        for i in range(1):
            now_month = (base_month + relativedelta(months=i)).strftime("%Y%m%d")
            next_month = (base_month + relativedelta(months=i+1)).strftime("%Y%m%d")
            format_period = now_month + "-" + next_month
            for item in res['result']:
                payeraccount = item['account_no']
                s3_bucket = item['s3_bucket']
                curfile_list = get_cur_file_list(item['account_no'], item['s3_bucket'], format_period)
                bill_period= (base_month + relativedelta(months=i)).strftime("%Y/%m")
                    # payeraccount, bill_period, s3_bucket, key
                for curfile in curfile_list:
                    message = f"cur|{payeraccount}|{bill_period}|{s3_bucket}|{curfile}"
                    # print(message)
                    sqs.send_message(
                        QueueUrl='https://sqs.us-west-2.amazonaws.com/006920391431/accounting_test',
                        MessageBody=message,
                    )
            print(now_month)
    elif mtype == "runtag":
        bill_period = '2020/12'
        res = db.execute("""SELECT distinct linkedaccountid , payeraccountid from bill_item bi where bill_period = '2020/12' and linkedaccountid in (
            '287434239594','964788871010','425705749395','693380017557','390989682568','689782480856'
            ) and PayerAccountId <> '' and linkedaccountid <> ''""", have_result=True)
        
        for item in res['result']:
            linkedaccountid = item['linkedaccountid']
            payeraccountid = item['payeraccountid']
            
            # bill_period, linkedaccount, payeraccount, customer_type
            message = f"runtag|{bill_period}|{linkedaccountid}|{payeraccountid}|si"
            sqs.send_message(
                QueueUrl='https://sqs.us-west-2.amazonaws.com/006920391431/accounting_test',
                MessageBody=message,
            )
            # message = f"runtag|{bill_period}|{linkedaccountid}|{payeraccountid}|si"
            # sqs.send_message(
            #     QueueUrl='https://sqs.us-west-2.amazonaws.com/006920391431/accounting_test',
            #     MessageBody=message,
            # )

    # curfile_list = get_cur_file_list("692199941127", "ecloudvalley-692199941127-consolidated-billing", "20191001-20191101")