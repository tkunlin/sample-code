import datetime
import getopt
import gzip
import json
import os
import sys
import traceback
from dateutil.relativedelta import relativedelta
import shutil
import codecs

import pymysql
import boto3
import pytz

import config
from db import DB
from lib import generate_insert_list_sql

from job_log import JobLog

DIRNAME = config.DIRNAME
BILL_ITEM_TABLE = config.BILL_ITEM
TABLE_TEMPLATE = "AWSBilling"

job_log = JobLog()

tag_report_bucket = config.tag_report_bucket
si_tag_report_bucket = config.si_tag_report_bucket

localdb = DB(endpoint='local', database=config.localdatabase)

def get_tag_colums(db, period, payeraccountid):
    period = period.replace("/","")
    sql = "SELECT * FROM {}{}_{}_Hourly_tagMapping".format(TABLE_TEMPLATE, period, payeraccountid)
    try:
        result = db.execute(sql, have_result = True)['result']
    except:
        return []
    """
    [
        {
            "remappedUserTag":"usertag0",
            "userTag":"user:Company"
        },
        {
            "remappedUserTag":"usertag1",
            "userTag":"user:EBS"
        }
        ....
    ]
    """
    return result


def gen_merge_tag_column(column1, column2):
    col1 = [item["userTag"] for item in column1]
    col2 = [item["userTag"] for item in column2]

    total_col = col2[:]
    
    for item in col1:
        if item not in total_col:
            total_col.append(item)
    
    ncol1 = []
    ncol2 = []
    
    for index, value in enumerate(total_col):
        if value in col1:
            i = col1.index(value)
            ncol1.append("{} AS {}".format(column1[i]["remappedUserTag"] ,col1[i].replace(":","_")))
        else:
            i = col2.index(value)
            ncol1.append("'' AS {}".format(col2[i].replace(":","_")))

        if value in col2:
            i = col2.index(value)
            ncol2.append("{} AS {}".format(column2[i]["remappedUserTag"] ,col2[i].replace(":","_")))
        else:
            i = col1.index(value)
            ncol2.append("'' AS {}".format(col1[i].replace(":","_")))

    return ncol1, ncol2


def export_colums(mtype='cb'):
    col = []
    col.append("bill_InvoiceId AS InvoiceID")
    col.append("bill_PayerAccountId AS PayerAccountId")
    col.append("lineItem_UsageAccountId AS LinkedAccountId")
    col.append("'LineItem' AS RecordId")
    col.append("product_ProductName AS ProductName")
    col.append("lineItem_UsageType AS UsageType")
    col.append("lineItem_Operation AS Operation")
    col.append("lineItem_AvailabilityZone AS AvailabilityZone")
    col.append("CASE WHEN reservation_ReservationARN <> '' AND reservation_ReservationARN LIKE concat('%',lineItem_UsageAccountId,'%') THEN 'Y' ELSE 'N' end ReservedInstance")
    if mtype=="cb":
        col.append("lineItem_LineItemDescription AS ItemDescription")
    elif mtype=="si":
        col.append("""CASE WHEN unit_price_si = '' 
                        THEN 
                            lineitem_lineitemdescription else replace( lineitem_lineitemdescription,
                            replace(substring_index(lineitem_lineitemdescription,'per',1),substring_index(lineitem_lineitemdescription,'$',1), ''),
                            concat('$',unit_price_si,' ')) 
                    END ItemDescription""")

    col.append("lineItem_UsageStartDate AS UsageStartDate")
    col.append("lineItem_UsageEndDate AS UsageEndDate")
    col.append("lineItem_UsageAmount AS UsageQuantity")
    if mtype=="cb":
        col.append("CASE WHEN unit_price = '' THEN lineItem_UnblendedRate ELSE unit_price END UnblendedRate")
        col.append("CASE WHEN unit_price = '' THEN lineItem_UnblendedCost ELSE unit_price * lineItem_UsageAmount END UnBlendedCost")
    elif mtype=="si":
        col.append("""CASE WHEN unit_price_si <> '' THEN unit_price_si 
                        WHEN unit_price <> '' THEN unit_price
                        ELSE lineItem_UnblendedRate END UnblendedRate""")
        col.append("""CASE WHEN unit_price_si <> '' THEN unit_price_si * lineItem_UsageAmount
                        WHEN unit_price <> '' THEN unit_price * lineItem_UsageAmount
                        ELSE lineItem_UnblendedCost END UnBlendedCost""")
    col.append("lineItem_ResourceId AS ResourceId")
    return col

def export_sql(db, sql, linkedaccountid, bill_period, index=""):
    if index != "":
        filename = "{}-cur-with-tags-{}_{}.csv".format(linkedaccountid, bill_period.replace("/","-"), index)
    else:
        filename = "{}-cur-with-tags-{}.csv".format(linkedaccountid, bill_period.replace("/","-"))
    
    ## headless command
    if index == "2":
        mcommand = "--skip-column-names"
    else:
        mcommand = ""

    export_filename = "{}/tag_report/{}".format(DIRNAME, filename)
    tempfile = "{}/tag_report/temp.csv".format(DIRNAME)
    with open(export_filename, 'wb') as f:
        f.write(codecs.BOM_UTF8)
    limit = 1000000
    page = 0
    while True:
        # print("""./mysql_export_batchv2.sh {0} {1} {2} {3} "{4}" {5} {6} {7} {8} {9}""".format(
        #     "localhost",  config.localhost, config.localuser, config.localpassword
        #     ,sql ,tempfile, mcommand, config.localdatabase,
        #     page, limit))
        # print("========================================================================================")
        # print("""./mysql_export_batchv2.sh {0} {1} {2} {3} "{4}" {5} {6} {7} {8} {9}""".format(
        #     "localhost",  config.localhost, config.localuser, config.localpassword
        #     ,sql ,tempfile, mcommand, config.localdatabase,
        #     page, limit))
        # print("========================================================================================")
        exec_res = os.system("""./mysql_export_batchv2.sh {0} {1} {2} {3} "{4}" {5} {6} {7} {8} {9}""".format(
            "localhost",  config.localhost, config.localuser, config.localpassword
            ,sql ,tempfile, mcommand, config.localdatabase,
            page, limit))
        if os.path.getsize(tempfile) < 10:
            break
        else:
            os.system(f"cat {tempfile} >> {export_filename}")
        print(page, limit)
        page += limit
    
    # print(command)
    # exec_res = os.system(command)
    if exec_res > 0:
        error_exit("export error")
    print("export to csv")
    return filename


def export_sqlori(db, sql, linkedaccountid, bill_period, index=""):
    if index != "":
        filename = "{}-cur-with-tags-{}_{}.csv".format(linkedaccountid, bill_period.replace("/","-"), index)
    else:
        filename = "{}-cur-with-tags-{}.csv".format(linkedaccountid, bill_period.replace("/","-"))
    
    ## headless command
    if index == "2":
        mcommand = "--skip-column-names"
    else:
        mcommand = ""

    export_filename = "{}/tag_report/{}".format(DIRNAME, filename)
    with open(export_filename, 'wb') as f:
        f.write(codecs.BOM_UTF8)
    if db.db == config.jobhost:
        # mysql  -h $2 -u $3 -p$4 --database=atlas --default_character-set=big5 --batch -e "$5" $7 | sed 's/\t/","/g;s/^/"/;s/$/"/;s/\n//g' > $6
        print("""./mysql_export_batch.sh {0} {1} {2} {3} "{4}" {5} {6} {7}""".format("prod" , config.host, config.user, config.password, sql, export_filename, mcommand, config.ecloud_database))
        exec_res = os.system("""./mysql_export_batch.sh {0} {1} {2} {3} "{4}" {5} {6} {7}""".format("prod" , config.host, config.user, config.password, sql, export_filename, mcommand, config.ecloud_database))
        # command = """mysql -h {} -P 3306 -u{} -p{} --default_character-set=big5 --database={} --batch -e "{}" {} | sed 's/\t/","/g;s/^/"/;s/$/"/;s/\n//g' > {}/tag_report/{}""".format(config.ahost, config.auser, config.apassword, config.adatabase, sql, mcommand, DIRNAME, filename)
    elif db.db == config.localdatabase:
        # mysql --database=atlas --default_character-set=big5 --batch -e "$2" $4 | sed 's/\t/","/g;s/^/"/;s/$/"/;s/\n//g' > $3
        print("""./mysql_export_batch.sh {0} {1} {2} {3} "{4}" {5} {6} {7}""".format("localhost",  config.localhost, config.localuser, config.localpassword , sql, export_filename, mcommand, config.localdatabase))
        exec_res = os.system("""./mysql_export_batch.sh {0} {1} {2} {3} "{4}" {5} {6} {7}""".format("localhost",  config.localhost, config.localuser, config.localpassword , sql, export_filename, mcommand, config.localdatabase))        
        # command = """mysql -h localhost -P 3306 --default_character-set=big5 --database={} --batch -e "{}" {} | sed 's/\t/","/g;s/^/"/;s/$/"/;s/\n//g' > {}/tag_report/{}""".format(config.adatabase, sql, mcommand, DIRNAME, filename)
        
    # print(command)
    # exec_res = os.system(command)
    if exec_res > 0:
        error_exit("export error")
    print("export to csv")
    return filename


def zip_file(filename):
    zipfile = filename.replace(".csv",".zip")
    command = "zip -j {}/tag_report/{} {}/tag_report/{}".format(DIRNAME,zipfile,DIRNAME,filename)
    exec_res = os.system(command)
    if exec_res > 0:
        error_exit("zipfile error")
    return "{}/tag_report/{}".format(DIRNAME,zipfile)

def upload2s3(zipfile,bill_period, linkedaccountid, mtype='cb'):
    if mtype=="cb":
        command = "aws s3 cp {} s3://{}/{}/{}/{}".format(zipfile, tag_report_bucket, config.tag_report_prefix, bill_period.replace("/",""),zipfile.split('/')[-1])
    elif mtype=="si":
        command = "aws s3 cp {} s3://{}/{}/{}/{}".format(zipfile, si_tag_report_bucket, config.si_tag_report_prefix, bill_period.replace("/",""),zipfile.split('/')[-1])
    exec_res = os.system(command)
    if exec_res > 0:
        error_exit("upload to s3")


def get_distinct_linedaccountid(db,bill_period):
    sql = "SELECT DISTINCT(linkedaccountid) FROM {} WHERE bill_period = '{}';".format( BILL_ITEM_TABLE, bill_period)
    result = db.execute(sql, have_result = True)['result']
    linkedaccount_list = [item["linkedaccountid"] for item in result]
    return linkedaccount_list


# def get_have_2payer_linkedlist(bill_period):
#     sql = """SELECT linkedaccountid, count(linkedaccountid)
#             FROM (  SELECT linkedaccountid,payeraccountid 
#                     FROM {} 
#                     WHERE bill_period = '{}'
#                     GROUP BY linkedaccountid,payeraccountid
#                   ) a 
#             GROUP BY linkedaccountid
#             HAVING count(linkedaccountid) > 1;""".format(BILL_ITEM_TABLE, bill_period)
#     result = db_execute(DBtype.AURORA, have_result = True)
#     mlist = [item["linkedaccountid"] for item in result]
#     return mlist


def get_payactlist_by_linkact(db,bill_period, linkedaccountid):
    sql ="""SELECT payeraccountid 
            FROM {} 
            WHERE bill_period = '{}'
            AND linkedaccountid = '{}'
            AND payeraccountid <> ''
            GROUP BY linkedaccountid,payeraccountid;
        """.format(BILL_ITEM_TABLE, bill_period, str(int(linkedaccountid)))
    result = db.execute( sql, have_result = True)['result']
    payeraccount_list = [item["payeraccountid"] for item in result]
    return payeraccount_list


def get_merge_sql(proddb, localdb,bill_period,payeraccount_list,linkedaccountid):
    tag_column1 = get_tag_colums(localdb, bill_period, payeraccount_list[0])
    tag_column2 = get_tag_colums(proddb, bill_period, payeraccount_list[1])
    ym = bill_period.replace("/","")
    tag_column1,tag_column2 = gen_merge_tag_column(tag_column1,tag_column2)

    column1 = export_colums() + tag_column1
    column2 = export_colums() + tag_column2

    sql1 = "SELECT {} FROM cur_{} AND lineitem_unblendedcost >= 0 or unit_price <> ''".format(", ".join(column1) ,linkedaccountid)  
    sql2 = "SELECT {} FROM {}{}_{}_Hourly WHERE lineitem_usageaccountid = '{}' AND lineitem_unblendedcost >= 0;".format(", ".join(column2), TABLE_TEMPLATE,ym,payeraccount_list[1],linkedaccountid)
    
    return sql1, sql2


def merge_file(filename1, filename2, linkedaccountid, bill_period):
    filename = "{}-cur-with-tags-{}.csv".format(linkedaccountid, bill_period.replace("/","-"))
    with open(filename,'wb') as wfd:
        for f in [filename1, filename2]:
            with open(f,'rb') as fd:
                shutil.copyfileobj(fd,wfd, 1024*1024*10)
    return filename



def cur_tag_report(bill_period, linkedaccountid, mtype="cb"):
    ## get 
    proddb = DB(endpoint='main', database=config.ecloud_database)
    payeraccount_list = get_payactlist_by_linkact(proddb, bill_period, linkedaccountid)
    proddb.close()

    # have_2payer_linkedlist = get_have_2payer_linkedlist(bill_period)
    if mtype == 'si':
        is_hide_credit = get_si_is_hide_credit(linkedaccountid)
        where_condition = " ( lineitem_unblendedcost >= 0 or unit_price <> '' or unit_price_si <> '' ) "
        if is_hide_credit:
            where_condition += " and product_productname <> 'Credit' "
    else:
        where_condition = " ( lineitem_unblendedcost >= 0 or unit_price <> '' ) "


    if len(payeraccount_list) == 1 :
        job_log.log("normal situation")
        ## this linkedaccount didn't shift payeraccount during this month
        column = get_tag_colums(localdb, bill_period, payeraccount_list[0])
        col = export_colums(mtype)
        for row in column:
            col.append("{} AS \`{}\`".format(row['remappedUserTag'], row['userTag'].replace(":","_")))
        sql =  "SELECT {} FROM cur_{} WHERE {} ".format(" ,".join(col), linkedaccountid, where_condition)
        ## Export file            
        filename = export_sql(localdb, sql, linkedaccountid, bill_period)
        
    elif len(payeraccount_list) > 1:
        job_log.log("muti payeraccount") 
        print(payeraccount_list)
        job_log.log('payeraccount shift {}'.format(str(len(payeraccount_list))))
        sql = "SELECT bill_payeraccountid from cur_{} limit 1".format(linkedaccountid)
        res = localdb.execute( sql, have_result=True)['result']
        payeraccountid= res[0]['bill_payeraccountid']
        column = get_tag_colums(localdb, bill_period, payeraccountid)
        col = export_colums(mtype)
        for row in column:
            col.append("{} AS \`{}\`".format(row['remappedUserTag'], row['userTag'].replace(":","_")))
        sql =  "SELECT {} FROM cur_{} WHERE {} ".format(" ,".join(col), linkedaccountid, where_condition)
        ## Export file            
        filename = export_sql(localdb , sql, linkedaccountid, bill_period)
        export_filenameuri = "{}/tag_report/{}".format(DIRNAME, filename)

        ## upload raw to s3
        if mtype == 'cb':
            command = "aws s3 cp {} s3://{}/{}/{}/raw/{}-{}".format(export_filenameuri, tag_report_bucket, config.tag_report_prefix, bill_period.replace("/",""), payeraccountid,export_filenameuri.split('/')[-1])
        elif mtype == 'si':
            command = "aws s3 cp {} s3://{}/{}/{}/raw/{}-{}".format(export_filenameuri, si_tag_report_bucket, config.si_tag_report_prefix, bill_period.replace("/",""), payeraccountid,export_filenameuri.split('/')[-1])
            
        exec_res = os.system(command)
        if exec_res > 0:
            error_exit("upload to s3")
    else:
        # error_exit('payeraccount not found')
        job_log.log("using own payeraccount situation")
        ## this linkedaccount didn't shift payeraccount during this month
        sql = "SELECT bill_PayerAccountId from cur_{} limit 1;".format(linkedaccountid)
        result = localdb.execute( sql, have_result = True)['result']
        payeraccountid = result[0]['bill_PayerAccountId']
        column = get_tag_colums(localdb, bill_period, payeraccountid)
        col = export_colums(mtype)
        for row in column:
            col.append("{} AS \`{}\`".format(row['remappedUserTag'], row['userTag'].replace(":","_")))
        sql =  "SELECT {} FROM cur_{} WHERE {} ".format(" ,".join(col), linkedaccountid, where_condition)
        ## Export file            
        filename = export_sql(localdb, sql, linkedaccountid, bill_period)

    job_log.log("zipping")
    zipfile = zip_file(filename)
    job_log.log("uploading")
    upload2s3(zipfile, bill_period, linkedaccountid,mtype)
    job_log.log("clearing")
    clearing(filename)

def clearing(filename):
    os.system("rm {}/tag_report/{}".format(DIRNAME,filename.replace(".csv","*")))



def error_exit(err):
    try:
        job_log.error(err)
    except:
        pass
    exit()

def get_bill_customer(linkedaccountid):
    pdb = DB(endpoint='main', database=config.ecloud_database)
    sql = "SELECT id,payeraccountid from bill_customer where linkedaccountid = '{}' and hide = 'n'".format(int(linkedaccountid))
    res = pdb.execute( sql, have_result=True)['result']
    if len(res) == 0:
        error_exit('Linkedaccountid {} not found bill_customer'.format(linkedaccountid))
    pdb.close()
    return res[0]['id']

def get_si_is_hide_credit(linkedaccountid):
    pdb = DB(endpoint='main', database=config.ecloud_database)
    bill_customer = get_bill_customer(linkedaccountid)
    sql = "SELECT is_hide_credit from bill_customer_si where bill_customer = '{}'; ".format(bill_customer)
    res = pdb.execute(sql, have_result=True)['result']
    pdb.close()
    if len(res) == 0:
        error_exit('bill_customer {} not found in bill_customer_si'.format(linkedaccountid))
    return res[0]['is_hide_credit'] == 1

def get_cur_payeraccountid(linkedaccountid):
    sql = "SELECT bill_PayerAccountId FROM cur_{} limit 1".format(linkedaccountid)
    res = localdb.execute(sql, have_result=True)['result']
    if len(res) == 0:
        error_exit("SQL ERROR: " + sql)
    return res[0]['bill_PayerAccountId']


def is_partnerled(bill_customer):
    proddb = DB(endpoint='main', database=config.ecloud_database)
    sql = "SELECT id from bill_customer WHERE business_support_pl in ('y', 'f', 'e') AND id = {};".format(bill_customer)
    res = proddb.execute(sql, have_result=True)['result']
    proddb.close()
    return True if len(res) > 0 else False


def insert_dop(bill_period, linkedaccountid, bill_customer):
    sql = """SELECT usagetype as lineitem_usagetype, 
            itemdescription as lineitem_lineitemdescription, 
            usagequantity as lineitem_usageamount, 
            unitprice as unit_price, 
            bp.productname as product_productname
    from {0} left join bill_product bp ON bp.id = bill_product
    WHERE bill_period = '{1}'
    AND bill_customer = {2}
    AND dop = 'y'
    AND (lineitem_type not in ('PrivateRateDiscount', 'RiVolumeDiscount') or lineitem_type is NULL )
    AND {0}.hide = 'n';
    """.format(BILL_ITEM_TABLE, bill_period, bill_customer)
    proddb = DB(endpoint='main', database=config.ecloud_database)
    res = proddb.execute(sql, have_result=True)['result']
    proddb.close()
    if len(res) > 0:
        sql, mlist = generate_insert_list_sql("cur_{}".format(linkedaccountid), res)
        localdb.execute( sql, insert_list=mlist)


def insert_support_fee(bill_period, linkedaccountid, bill_customer):
    sql = """SELECT usagetype as lineitem_usagetype, 
            itemdescription as lineitem_lineitemdescription, 
            usagequantity as lineitem_usageamount, 
            unitprice as unit_price, 
            bp.productname as product_productname
    from {0} left join bill_product bp ON bp.id = bill_product
    WHERE bill_period = '{1}'
    AND bill_customer = {2}
    AND bill_product in (19,270)
    AND billing_entity = 'AWS-Ecloud-SPL'
    AND {0}.hide = 'n';
    """.format(BILL_ITEM_TABLE, bill_period, bill_customer)
    proddb = DB(endpoint='main', database=config.ecloud_database)
    res = proddb.execute( sql, have_result=True)['result']
    proddb.close()
    if len(res) > 0:
        sql, mlist = generate_insert_list_sql("cur_{}".format(linkedaccountid), res)
        localdb.execute(sql, insert_list=mlist)


def update_reprice_support_fee(bill_period, linkedaccountid, bill_customer):
    sql = """SELECT usagetype as lineitem_usagetype, 
                itemdescription as lineitem_lineitemdescription, 
                usagequantity as lineitem_usageamount, 
                unitprice as unit_price, 
                bp.productname as product_productname
            from {0} left join bill_product bp ON bp.id = bill_product
            WHERE bill_period = '{1}'
                AND bill_customer = {2}
                AND bill_product in (19,270)
                AND billing_entity = 'AWS-Ecloud-Support'
                AND {0}.hide = 'n';
    """.format(BILL_ITEM_TABLE, bill_period, bill_customer)
    proddb = DB(endpoint='main', database=config.ecloud_database)
    res = proddb.execute(sql, have_result=True)['result']
    proddb.close()
    if len(res) > 0:
        # delete origin support
        productname = res[0]['product_productname']
        dsql = "DELETE FROM cur_{} where product_productname = '{}' and lineitem_lineitemtype = 'Usage'".format(linkedaccountid, productname)
        localdb.execute(dsql)
        
        sql, mlist = generate_insert_list_sql("cur_{}".format(linkedaccountid), res)
        localdb.execute(sql, insert_list=mlist)


def merge_tag_report(bill_period, linkedaccountid, mtype='cb'):
    ym = bill_period.replace("/","")
    template_zip = "{}-cur-with-tags-{}.zip"
    template_dir = "{}-cur-with-tags-{}"
    tmp_dir = template_dir.format(linkedaccountid, bill_period.replace("/","-"))
    tmp_zip = template_zip.format(linkedaccountid, bill_period.replace("/","-"))
    
    proddb = DB(endpoint='main', database=config.ecloud_database)
    payeraccount_list = get_payactlist_by_linkact(proddb, bill_period, linkedaccountid)
    proddb.close()

    if len(payeraccount_list) == 1:
        return
    
    os.system("mkdir {}".format(tmp_dir))
    # download
    for payeraccount in payeraccount_list:
        file = "{}-{}-cur-with-tags-{}.csv".format(payeraccount,linkedaccountid, bill_period.replace("/","-"))
        if mtype == 'cb':
            os.system("aws s3 cp s3://{}/cur-rerun/{}/raw/{} ./{} ".format(tag_report_bucket, ym, file, tmp_dir))
        elif mtype == 'si':
            os.system("aws s3 cp s3://{}/cur-rerun/si/{}/raw/{} ./{} ".format(si_tag_report_bucket, ym, file, tmp_dir))

    os.system("zip -r {} {}".format(tmp_zip, tmp_dir))
    if mtype == 'cb':
        os.system("aws s3 cp {} s3://{}/{}/{}/ ".format(tmp_zip, tag_report_bucket, config.tag_report_prefix, ym))
    elif mtype == 'si':
        os.system("aws s3 cp {} s3://{}/{}/{}/ ".format(tmp_zip, si_tag_report_bucket, config.si_tag_report_prefix, ym))

    os.system("rm {}".format(tmp_zip))
    os.system("rm {} -r".format(tmp_dir))


def do_process(linkedaccountid, billing_date, mtype="cb"):
    print("start tag report")
    bill_period = billing_date[:7]
    job_log.set_job_name('cur tag report {}'.format(mtype))
    job_log.set_job_title("CUR-tag-report-{}-{}-{}".format(bill_period, linkedaccountid, mtype))
    job_log.start()
    

    #  產生 cur_tag_report
    cur_tag_report(bill_period, linkedaccountid, mtype)
    #  合併 cur_tag_report 
    merge_tag_report(bill_period, linkedaccountid, mtype)
    job_log.log("Done")
    job_log.ending()


if __name__ == '__main__':
    def print_help():
        print("tag_report.py -l <linkedaccountid> -d <YYYY/MM/DD> -t <cb/si>")

    start_time = datetime.datetime.now(pytz.timezone('Asia/Taipei'))
    print(sys.argv)
    argv = sys.argv[1:]
    billing_date = None
    linkedaccountid = None
    mtype = "cb"

    try:
      opts, args = getopt.getopt(argv,"hl:d:t:")
    except getopt.GetoptError as e:
        print_help()
        sys.exit(2)
    print(opts)
    for opt, arg in opts:
        print(opt,arg)
        if opt == '-h':
            print_help()
            sys.exit()
        elif opt in ("-l"):
            linkedaccountid = arg
        elif opt in ("-d"):
            billing_date = arg
        elif opt in ("-t"):
            mtype = arg
        else:
            print_help()
            sys.exit()
    if linkedaccountid is None or billing_date is None:
        print_help()
        sys.exit(2)
    else:
        ## Process
        print("mtype", mtype)
        do_process(linkedaccountid, billing_date, mtype=mtype)
        
        # pass

    end_time = datetime.datetime.now(pytz.timezone('Asia/Taipei'))
    print(start_time)
    print(end_time)
    
    
