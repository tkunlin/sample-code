#!/bin/bash

if [ $8 == "0" ]
then
    parameter=" "
    echo $parameter
    # mysql -h $2 -u $3 -p$4 --database=$8 --batch -e "$5" $7 limit $9,${10} | sed 's/\t/","/g;s/^/"/;s/$/"/;s/\n//g' > $6
else
    parameter="--skip-column-names"
    echo $parameter
    # mysql -h $2 -u $3 -p$4 --database=$8 --batch --skip-column-names -e "$5" $7 limit $9,${10} | sed 's/\t/","/g;s/^/"/;s/$/"/;s/\n//g' > $6
fi

mysql -h $2 -u $3 -p$4 --database=$7  --default-character-set=utf8 --batch $parameter -e "$5 limit $8,${9};" | sed 's/\t/","/g;s/^/"/;s/$/"/;s/\n//g' > $6

# echo "limit $9,${10}; $8 | $7 | $6 |"
# echo "$0 $1 $2"