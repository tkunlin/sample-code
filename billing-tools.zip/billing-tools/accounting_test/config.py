# ================================================================================= #
# Copyright 2022 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #
try:
    strCode = "Y29weXJpZ2h0IG9mIGVjbG91ZHZhbGxleS1UU0Q="
except:
    print('Y29weXJpZ2h0IG9mIGVjbG91ZHZhbGxleS1UU0Q=')

import ssm
import os

env = os.environ["ENV"] if "ENV" in os.environ else "stage"
frequency = os.environ["FREQUENCY"] if "FREQUENCY" in os.environ else "Daily"
source_file = os.environ["SOURCE_FILE"] if "SOURCE_FILE" in os.environ else "csv"

values = {}
if env == "dev-container-off":
    key_prefix = "Dev"
else:
    key_prefix = env.title()

print(key_prefix)
keys = {
    "host": f'/{key_prefix}/Billing/DB/mysql-endpoint',
    "user": f'/{key_prefix}/Billing/DB/mysql-user',
    "password": f'/{key_prefix}/Billing/DB/mysql-pwd',
    "db": f'/{key_prefix}/Billing/DB/mysql-db',
    "tag_report_bucket": f"/{key_prefix}/Billing/S3/tag-report/bucket-name",
    "cur_backup_bucket": f"/{key_prefix}/Billing/S3/cur-backup/bucket-name",
}    

keys["jobhost"]= f'/{key_prefix}/Billing/DB/mysql-endpoint'
keys["jobuser"]= f'/{key_prefix}/Billing/DB/mysql-user'
keys["jobpassword"]= f'/{key_prefix}/Billing/DB/mysql-pwd'
keys["jobdb"]= f'/{key_prefix}/Billing/DB/mysql-db'

__page_limit = 10
__index = 0
__keys = list(keys.values())
while True:
    __key_page = __keys[ __page_limit * __index : __page_limit * ( __index + 1 )]
    if len(__key_page) == 0:
        break
    parameters = ssm.get_parameters(__key_page)
    for parameter in parameters:
        for k, v in keys.items():
            if v == parameter["Name"]:
                values[k] = parameter["Value"]
    __index += 1

jobhost = values["jobhost"]
jobuser = values["jobuser"]
jobpassword = values["jobpassword"]
host = values["host"]
user = values["user"]
password = values["password"]
cur_backup_bucket = values["cur_backup_bucket"]
tag_report_bucket = values["tag_report_bucket"]
si_tag_report_bucket = values["tag_report_bucket"]
ecv_cur_bucket = values["tag_report_bucket"]
si_ecv_cur_bucket = values["tag_report_bucket"]

ecloud_database = os.environ["DBNAME"] if "DBNAME" in os.environ else values["db"]
atlas_database = values["jobdb"]

localhost = values["host"]
localuser = values["user"]
localpassword = values["password"]
localdatabase = "atlas"
tag_report_prefix = "cur-rerun"
si_tag_report_prefix = "cur-rerun/si"
ecv_cur_prefix = "ecv-cur-rerun"
si_ecv_cur_prefix = "ecv-cur-rerun/si"
parquet_cur_prefix = "parquet-cur-rerun"
DIRNAME=os.getcwd()

## TABLE
BILL_ITEM = "bill_item"
BILL_INVOICE = "bill_invoice_revenue"
BILL_CDN = "bill_cdn"
BILL_CODE = "bill_code"
LOCAL_BILLING_CODE = "LocalBilling"
CDN_REGION_CODE = "CDN_REGION"

## bucket
prod_cur_backup_bucket="billing-prod-cur-backup"