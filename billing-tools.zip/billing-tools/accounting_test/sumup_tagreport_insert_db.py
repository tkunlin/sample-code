import csv
from db import DB
import os
import config
from get_auth import get_auth
import boto3
import botocore
import sys
from lib import insert_db



# bill_period = '2020/09'

def download_file(auth, bucket, key, des):
    try:
        s3 = auth.client('s3')
        s3.download_file(bucket, key, des)
    except botocore.exceptions.ClientError as err:
        if err.response['ResponseMetadata']['HTTPStatusCode']==404:
            return False
        else:
            auth = get_auth("515175144484")
            return download_file(auth, bucket, key, des)
    else:
        return True



def calc_file(filename):
    cur_mfile = open(filename, 'r', encoding='UTF-8')
    cur_reader = csv.DictReader(cur_mfile)
    usagequantity = 0.0
    cost = 0.0
    flag = True
    for ind, row in enumerate(cur_reader):
        if flag:
            payeraccountid = row['PayerAccountId']
            linkedaccountid = row['LinkedAccountId']
            flag = False
        if row['UsageType'] in ("Technical Support", "eCloudvalley Techincal Support","CN MSP Fee" ) \
                or row['ProductName'] == "eCloudvalley Techincal Support":
            continue
        usagequantity += float(row['UsageQuantity'])
        cost += float(row['UnBlendedCost'])
    return linkedaccountid, payeraccountid, usagequantity, cost

def error_log(db, bill_period, linkedaccountid, payeraccountid):
    res = insert_db(db, 'sumup_error', [{
        'linkedaccount': linkedaccountid, 
        'payeraccount': payeraccountid,
        'type': "sumup_ecvcur",
        "bill_period": bill_period
    }])



def main(bill_period, linkedaccountid, customer_type="cb"):
    if customer_type == "cb":
        tablename = "sumup_ecvcur"
    else:
        tablename = "sumup_ecvcur_si"
    print(bill_period, linkedaccountid)
    ym = bill_period.replace("/","")
    y_dash_m = bill_period.replace("/","-")

    linkedaccountid = "{:0>12}".format(linkedaccountid)
    tagreport_file_zip = "{}-cur-with-tags-{}.zip".format(linkedaccountid, y_dash_m)
    tagreport_file = tagreport_file_zip.replace("zip","csv")
    auth = get_auth("515175144484")
    if customer_type=="cb":
        dres = download_file(auth, "ecloud-tag-report", "cur/{}/{}-cur-with-tags-{}.zip".format(ym, linkedaccountid, y_dash_m), "./tag_report/{}".format(tagreport_file_zip))
    else:
        dres = download_file(auth, "ecloud-tag-report", "cur/si/{}/{}-cur-with-tags-{}.zip".format(ym, linkedaccountid, y_dash_m), "./tag_report/{}".format(tagreport_file_zip))
        
    if dres:
        os.system("unzip ./tag_report/{}".format(
            tagreport_file_zip))
        db = DB(endpoint='main', database='ecloud')
        if os.path.isfile(tagreport_file):
            linkedaccountid1, payeraccountid, usagequantity, cost = calc_file(tagreport_file)
            db.execute(f"delete from {tablename} where linkedaccount='{linkedaccountid1}' and payeraccount = '{payeraccountid}'")
            res = insert_db(db, tablename, [{
                'linkedaccount': linkedaccountid1, 
                'payeraccount': payeraccountid,
                'usagequantity': usagequantity,
                'cost': cost,
                "bill_period": bill_period
            }])
            print(res)
            os.system("rm ./{}".format(tagreport_file))
            
        else:
            if os.path.isdir(tagreport_file.replace(".csv","")):
                files = os.listdir(tagreport_file.replace(".csv",""))
                files = [ "{}/{}".format(tagreport_file.replace(".csv",""), file) for file in files]
            else:
                files = []
                for file in os.listdir("./"):
                    if linkedaccountid in file and file[-4:] == ".csv":
                        files.append(file)
            for file in files:
                linkedaccountid1, payeraccountid, usagequantity, cost = calc_file(file)
                db.execute(f"delete from {tablename} where linkedaccount='{linkedaccountid1}' and payeraccount = '{payeraccountid}'")
                res = insert_db(db, tablename, [{
                    'linkedaccount': linkedaccountid1, 
                    'payeraccount': payeraccountid,
                    'usagequantity': usagequantity,
                    'cost': cost,
                    "bill_period": bill_period
                }])
                print(res)
            
            for file in files:
                os.system("rm ./{} ".format(file))

        os.system("rm ./tag_report/*")
    else:
        db = DB(endpoint='main', database='ecloud')
        error_log(db, bill_period, linkedaccountid, "None")
    db.close()


if __name__ == '__main__':
    main('2020/12', '644228475238', 'cb')
    