def generate_insert_list_sql(table,mlist):
    # get format
    if len(mlist) == 0:
        raise Exception("generate insert list error")
    obj = mlist[0]
    temp_column_list = list(obj.keys())
    column_list = []
    for item in temp_column_list:
        column_list.append("`{}`".format(item))
    #columns = key, key ,...
    columns = ', '.join(column_list)
    #values_holder = (%s , %s, %s, ...) 
    values_holder = "(" + ", ".join(['%s'] * len(obj)) + ")"
    #placeholders = values_holder, values_holder, values_holder ...
    placeholders = ", ".join([values_holder] * len(mlist))
    values = tuple()
    for obj in mlist:
        values = values + tuple(obj.values())
    sql = "INSERT INTO %s ( %s ) VALUES  %s " % (table, columns, placeholders)
    # print(values)
    return sql, values


def insert_db(db, table, insert_list):
    sql, vals = generate_insert_list_sql(table, insert_list)
    res = db.execute(sql, insert_list=vals)
    return res['success']


