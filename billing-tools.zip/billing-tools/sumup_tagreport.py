import csv
from lib.db import DB
import os
from lib import config
from lib.get_auth import get_auth
import boto3
import botocore
import sys

# bill_period = '2020/09'
fieldnames = ['linkedaccount', 'payeraccount', 'usagequantity','cost']


errfile = open("err.log",'w')

def download_file(auth, bucket, key, des):
    try:
        s3 = auth.client('s3')
        s3.download_file(bucket, key, des)
    except botocore.exceptions.ClientError as err:
        if err.response['ResponseMetadata']['HTTPStatusCode']==404:
            errfile.write("not found {} {}\n".format(bucket, key))
            return False
        else:
            auth = get_auth("515175144484")
            return download_file(auth, bucket, key, des)
    else:
        return True



def calc_file(filename):
    cur_mfile = open(filename, 'r')
    cur_reader = csv.DictReader(cur_mfile)
    usagequantity = 0.0
    cost = 0.0
    flag = True
    for ind, row in enumerate(cur_reader):
        if flag:
            payeraccountid = row['PayerAccountId']
            linkedaccountid = row['LinkedAccountId']
            flag = False

        if row['UsageType'] in ("Technical Support", "eCloudvalley Techincal Support","CN MSP Fee" ) \
                or row['ProductName'] == "eCloudvalley Techincal Support":
            continue
            
        usagequantity += float(row['UsageQuantity'])
        cost += float(row['UnBlendedCost'])
    return linkedaccountid, payeraccountid, usagequantity, cost




if __name__ == "__main__":
    bill_period = sys.argv[1]
    ym = bill_period.replace("/","")
    y_dash_m = bill_period.replace("/","-")

    total_cur={}
    csv_result = open('ECV_CUR{}.csv'.format(ym), 'w', newline='\n')

    compare_result = open(f'compare_{ym}.csv', 'w', newline='\n')
    compare_writer = csv.DictWriter(compare_result, fieldnames=['linkedaccount', 'tag_cost', 'db_cost'])
    compare_writer.writeheader()
    writer = csv.DictWriter(csv_result, fieldnames=fieldnames)
    writer.writeheader()
    db = DB(endpoint='main',database=config.ecloud_database)
    res = db.execute("""SELECT bill_customer, cno, linkedaccountid, totalmoney 
    from bill_invoice_revenue 
    where bill_period = '{}' 
    );""".format(bill_period), 
                        have_result=True)['result']

    auth = get_auth("515175144484")
    for ind, item in enumerate(res):
        try:
            linkedaccountid = "{:0>12}".format(item['linkedaccountid'])
            tagreport_file_zip = "{}-cur-with-tags-{}.zip".format(linkedaccountid, y_dash_m)
            tagreport_file = tagreport_file_zip.replace("zip","csv")
            totalmoney = item['totalmoney']
            dres = download_file(auth, "ecloud-tag-report", "cur/{}/{}-cur-with-tags-{}.zip".format(ym, linkedaccountid, y_dash_m), "./tag_report/{}".format(tagreport_file_zip))
            if dres:
                os.system("unzip ./tag_report/{}".format(
                    tagreport_file_zip))

                if os.path.isfile(tagreport_file):
                    linkedaccountid1, payeraccountid, usagequantity, cost = calc_file(tagreport_file)
                    writer.writerow({
                        'linkedaccount': linkedaccountid1, 
                        'payeraccount': payeraccountid,
                        'usagequantity': usagequantity,
                        'cost': cost
                    })
                    os.system("rm ./{}".format(tagreport_file))
                    compare_writer.writerow({
                        'linkedaccount': linkedaccountid,
                        'tag_cost': cost,
                        'db_cost': totalmoney
                    })
                else:
                    temp_cost = 0
                    for file in os.listdir(tagreport_file.replace(".csv","")):
                        linkedaccountid1, payeraccountid, usagequantity, cost = calc_file("{}/{}".format(tagreport_file.replace(".csv",""), file))
                        writer.writerow({
                            'linkedaccount': linkedaccountid1, 
                            'payeraccount': payeraccountid,
                            'usagequantity': usagequantity,
                            'cost': cost
                        })
                        temp_cost += cost

                    compare_writer.writerow({
                        'linkedaccount': linkedaccountid,
                        'tag_cost': temp_cost,
                        'db_cost': totalmoney
                    })
                    os.system("rm ./{} -r".format(tagreport_file.replace(".csv","")))

                os.system("rm ./tag_report/*")
            print("progress:", ind,"/",len(res))
        except Exception as e:
            print(e)
            errfile.write("{}\n".format(linkedaccountid))
    