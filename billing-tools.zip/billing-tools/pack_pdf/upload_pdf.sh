#!/bin/bash
# ================================================================================= #
# Copyright 2023 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #
echo "===Job Start $(date "+%Y-%b-%d %H:%M:%S")==="
env_type=$1
echo $env_type
if [ $env_type == "Prod" ];
then
    source ./config_prod.sh 
elif [ $env_type == "Stage" ] || [ $env_type == "Uat" ] || [ $env_type == "Dev" ];
then
    source ./config.sh
else
    echo "Pleas enter the right env type."
    echo "Valid env type:[Prod], [Stage], [Uat] or [Dev]"
    exit
fi
#Download file from S3 and upload to SharePoint folder
get_upload_File(){
    LOCAL_PDF_PATH=$1
    S3_FILE_PATH=$2
    ONEDRIVE_FOLDER_PATH=$3
    env=$4
    for CNO_PREFIX in ${CNO_PREFIX_ARR[@]}
    do  
        echo "Start downloading billing $CNO_PREFIX PDF from S3"
        mkdir -p $LOCAL_PDF_PATH
        echo "aws s3 cp s3://$S3_PDF_BUCKET/$S3_FILE_PATH/ $LOCAL_PDF_PATH/$CNO_PREFIX"
        nohup aws s3 cp s3://$S3_PDF_BUCKET/$S3_FILE_PATH/ $LOCAL_PDF_PATH/$CNO_PREFIX --recursive --exclude "*" --include "$BILL_PERIOD-$CNO_PREFIX*"  >/dev/null  2>&1 
        CNO_PREFIX_FILE=$(ls $LOCAL_PDF_PATH/$CNO_PREFIX | wc -l)
        echo "Download $CNO_PREFIX PDF completed and there are $CNO_PREFIX_FILE files in the folder."
        TOTAL_FILE_ARR+=($CNO_PREFIX_FILE)
        echo "zip -j $LOCAL_PDF_PATH/"$CNO_PREFIX"_"$BILL_PERIOD"_PDF.zip $LOCAL_PDF_PATH/$CNO_PREFIX/*"
        nohup zip -j $LOCAL_PDF_PATH/"$CNO_PREFIX"_"$BILL_PERIOD"_PDF.zip $LOCAL_PDF_PATH/$CNO_PREFIX/* >/dev/null  2>&1
        if [ $env == "ECV" ]
        then
            if [ -f "$LOCAL_PDF_PATH/"$CNO_PREFIX"_"$BILL_PERIOD"_PDF.zip" ]
            then
                echo "rclone copy $LOCAL_PDF_PATH/"$CNO_PREFIX"_"$BILL_PERIOD"_PDF.zip "\"$ONEDRIVE_FOLDER_PATH/${Country_CNO[$CNO_PREFIX]}/${Country_CNO[$CNO_PREFIX]}$BILL_PERIOD"\" -P --ignore-size --ignore-checksum --log-file ./rclone-pdf.log --log-level NOTICE"
                rclone copy $LOCAL_PDF_PATH/"$CNO_PREFIX"_"$BILL_PERIOD"_PDF.zip "$ONEDRIVE_FOLDER_PATH/${Country_CNO[$CNO_PREFIX]}/${Country_CNO[$CNO_PREFIX]}$BILL_PERIOD" -P --ignore-size --ignore-checksum --log-file ./rclone-pdf.log --log-level NOTICE
                rclone size "$ONEDRIVE_FOLDER_PATH/${Country_CNO[$CNO_PREFIX]}/${Country_CNO[$CNO_PREFIX]}$BILL_PERIOD"
            else
                echo "$LOCAL_PDF_PATH/"$CNO_PREFIX"_"$BILL_PERIOD"_PDF.zip does not exist."
            fi
        elif [ $env == "ECR" ]
        then
            ONEDRIVE_PATH_ECR=${UPLOAD_PATH_ECR[$CNO_PREFIX]}
            echo $ONEDRIVE_PATH_ECR
            echo "rclone copy $LOCAL_PDF_PATH/"$CNO_PREFIX"_"$BILL_PERIOD"_PDF.zip "\"$ONEDRIVE_PATH_ECR"\" -P --ignore-size --ignore-checksum --log-file ./rclone-pdf.log --log-level NOTICE"
            rclone copy $LOCAL_PDF_PATH/"$CNO_PREFIX"_"$BILL_PERIOD"_PDF.zip "$ONEDRIVE_PATH_ECR"  -P --ignore-size --ignore-checksum --log-file ./rclone-pdf.log --log-level NOTICE
            rclone size "$ONEDRIVE_PATH_ECR"
        else
            echo "[ERROR]Check the company type!"
        fi
    done
    echo "Upload all PDF files completed." 
    tot=0
    for i in ${TOTAL_FILE_ARR[@]}
    do
        let tot+=$i
    done
    echo "Total PDF Files number: $tot"
    rm -r $LOCAL_PDF_PATH
}
#main execute function
main(){
    if [ $company_type == "ECV" ]
    then
        get_upload_File $LOCAL_PDF_FOLDER $S3_PREFIX "$UPLOAD_PATH" $company_type
        get_upload_File $LOCAL_PDF_FOLDER_D $S3_PREFIX_desc "$UPLOAD_PATH_SIMPLE" $company_type
    elif [ $company_type == "ECR" ]
    then
        get_upload_File $LOCAL_PDF_FOLDER $S3_PREFIX "$UPLOAD_PATH" $company_type
    else
        echo "Check bash upload_pdf.sh [ECV or ECR] [yyyymm or null]. For example:bash upload_pdf.sh Prod ECV or bash upload_pdf.sh Prod ECV 202203 "
    fi
}
main

echo "===Job End $(date "+%Y-%b-%d %H:%M:%S")==="