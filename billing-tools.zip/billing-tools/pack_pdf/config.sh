#/bin/bash

#Logger date&time
LOG_DATE_CMD='date "+%Y-%b-%d %H:%M:%S"'

#File date&time
last_m=$(date -d last-month +%Y%m)
if [ "$#" -ne 3 ]
then
    BILL_PERIOD=$last_m
else
    BILL_PERIOD=$3
fi
echo $BILL_PERIOD
company_type=$2
if [ $company_type == "ECV" ]
then
    declare -a CNO_PREFIX_ARR=('CS' 'CA') #CNO PREFIX
elif [ $company_type == "ECR" ]
then
    declare -a CNO_PREFIX_ARR=('CR' 'CC') #CNO PREFIX
else
    echo "Pleas enter the right env type."
fi
LOCAL_PDF_FOLDER="./pdf_file_$BILL_PERIOD"
LOCAL_PDF_FOLDER_D="./desc_pdf_file_$BILL_PERIOD"
S3_PDF_BUCKET=$(aws ssm get-parameter --name "/$env_type/Billing/S3/invoice/bucket-name" --region us-west-2 | jq --raw-output ".Parameter.Value")
# S3_PDF_BUCKET="ecv-invoice-stage"
echo $S3_PDF_BUCKET
S3_PREFIX="bill_invoice_raw/bill_invoice_output_$BILL_PERIOD"
S3_PREFIX_desc="bill_invoice_raw/bill_invoice_output_desc_$BILL_PERIOD"
#pdf file type
type_complete="繁版"
type_simple="簡版"
#Country CNO mapping
declare -A Country_CNO
Country_CNO[CR]="C8"
Country_CNO[CC]="C3"
Country_CNO[C0]="TW"
Country_CNO[CH]="HK"
Country_CNO[CM]="HK"
Country_CNO[CN]="CN"
Country_CNO[CI]="ID"
Country_CNO[CY]="MY"
Country_CNO[CS]="SG"
Country_CNO[CT]="TH"
Country_CNO[CV]="VN"
Country_CNO[CA]="AU"
# OneDrive PATH for dev
# UPLOAD_FOLDER=$(aws ssm get-parameter --name "/$env_type/Billing/sharepoint/folfer" --region us-west-2 | jq --raw-output ".Parameter.Value")
readonly UPLOAD_FOLDER=`aws ssm get-parameter --name "/$env_type/Billing/sharepoint/folder" --region us-west-2 | jq .Parameter.Value | tr -d '"' `
UPLOAD_PATH="$UPLOAD_FOLDER/$type_complete"
UPLOAD_PATH_SIMPLE="$UPLOAD_FOLDER/$type_simple"
# UPLOAD_PATH="ecv-dev:test_pack_pdf/$type_complete"
# UPLOAD_PATH_SIMPLE="ecv-dev:test_pack_pdf/$type_simple"
UPLOAD_FOLDER_ECR=$(aws ssm get-parameter --name "/$env_type/Billing/sharepoint/folfer-c8" --region us-west-2 | jq --raw-output ".Parameter.Value")
declare -A UPLOAD_PATH_ECR
UPLOAD_PATH_ECR[CR]="$UPLOAD_FOLDER_ECR/$BILL_PERIOD/C8"
UPLOAD_PATH_ECR[CC]="$UPLOAD_FOLDER_ECR/$BILL_PERIOD/C3"
