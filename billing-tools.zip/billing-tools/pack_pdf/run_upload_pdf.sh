#!/bin/bash
trap "exit" INT TERM ERR
trap "kill 0" EXIT

# starttime=$(date +%s)
execute_date=$(date -d "$(date +%Y-%m-01) -1 day" +%Y%m)
file_type_str="bill_invoice_output_$execute_date,bill_invoice_output_desc_$execute_date"
country_str="ID,MY"

country_arr=(${country_str//','/ }); 
country_arr_length=${#country_arr[@]}

file_type_arr=(${file_type_str//','/ }); 
file_type_arr_length=${#file_type_arr[@]}

for(( i=0; i<$file_type_arr_length; i++ ));do
{
    file_type=${file_type_arr[$i]}
    php get_pdf.php $file_type $execute_date
}
done

for(( i=0; i<$file_type_arr_length; i++ ));do
{
    file_type=${file_type_arr[$i]}
    # php get_pdf.php $file_type
    for(( j=0; j<$country_arr_length; j++ ));do
    {
        country=${country_arr[$j]}
        php for_accounting_pdf.php $country $file_type $execute_date
    }&
    done
}
done
wait

for(( i=0; i<$file_type_arr_length; i++ ));do
{
    file_type=${file_type_arr[$i]}
    rm -rf $file_type*
}
done

