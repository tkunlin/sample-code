<?php
$execute_date = $argv[3];
$base_source_dir = $argv[2];
$pdf_type = "";
$log_file = "rclone-pdf-$execute_date.log";
$remote_folder_arr = [$argv[1]=>strtolower($argv[1]).$execute_date];

$onedrive_path_origin = 'EIP:Public/Finance & Accounting Center/BIL/';

function create_remote_folder($country,$folder_name,$log_file){
    echo "[".date("Y-m-d H:i:s")."] Start create $country (".$GLOBALS['pdf_type'].") folder on onedrive.\n";
    shell_exec("rclone mkdir '".$GLOBALS['onedrive_path']."/$country/$folder_name' --log-file $log_file --log-level DEBUG");
    echo "[".date("Y-m-d H:i:s")."] Start copy $country (".$GLOBALS['pdf_type'].") file to onedrive.\n";
}

function copy_file($pdf_file_path,$country,$folder_name,$log_file){
    shell_exec('rclone copy "'.$pdf_file_path.'" "'.$GLOBALS['onedrive_path'].'/'.$country.'/'.$folder_name.'" --ignore-size --ignore-checksum --log-file '.$log_file.' --log-level NOTICE');
}

function checkdata($ALL_pdf_arr,$country,$folder_name){
    echo "[".date("Y-m-d H:i:s")."] Start check $country (".$GLOBALS['pdf_type'].") file.\n";
    shell_exec("rclone lsf '".$GLOBALS['onedrive_path']."/$country/$folder_name' > $country.txt");
    $onedrive_file = file("$country.txt", FILE_IGNORE_NEW_LINES);
    $result = array_diff($ALL_pdf_arr[$country], $onedrive_file);
    return $result;
}


if(strpos($base_source_dir, "desc") === false){
    $pdf_type = '繁版';
    $onedrive_path = $onedrive_path_origin.$pdf_type;
}else{
    $pdf_type = '簡版';
    $onedrive_path = $onedrive_path_origin.$pdf_type;
}

$contents = file_get_contents("$base_source_dir.json");
$ALL_pdf_arr = json_decode($contents, true);

foreach($remote_folder_arr as $country=>$folder_name){
    $try_reupload_times = 0;
    create_remote_folder($country,$folder_name,$log_file);
    foreach($ALL_pdf_arr[$country] as $pdf_name){
        $pdf_file_path = "./$base_source_dir/$pdf_name";
        copy_file($pdf_file_path,$country,$folder_name,$log_file);
    }
    while(count($check_result = checkdata($ALL_pdf_arr,$country,$folder_name))!=0){
        $try_reupload_times++;
        echo "Reupload ".count($check_result)." file, try($try_reupload_times)\n";
        print_r($check_result);
        foreach($check_result as $pdf_name){
            $pdf_file_path = "./$base_source_dir/$pdf_name";
            copy_file($pdf_file_path,$country,$folder_name,$log_file);
        }
        if($try_reupload_times==3){
            break;
        }
    }   
}