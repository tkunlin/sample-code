<?php
$execute_date = $argv[2];
$base_source_dir = $argv[1];
$pdf_type = "";

function sync_pdf_from_s3($base_source_dir){
    echo "[".date("Y-m-d H:i:s")."] Start sync ".$GLOBALS['pdf_type']." pdf from S3.\n";
    shell_exec("aws s3 sync s3://ecv-invoice/bill_invoice_raw/$base_source_dir/ ./$base_source_dir");
}

function sort_data($base_source_dir){
    $ALL_pdf_arr = [];
    $SG_pdf_arr = [];
    $HK_pdf_arr = [];
    $TW_pdf_arr = [];
    $ID_pdf_arr = [];
    $TH_pdf_arr = [];
    $MY_pdf_arr = [];
    $CN_pdf_arr = [];
    $VN_pdf_arr = [];
    $pdf_file_name = scandir("./$base_source_dir", 1);
    foreach($pdf_file_name as $key=>$pdf_name){
        $pdf_file_path = "./$base_source_dir/$pdf_name";
        if(substr($pdf_name,7,2) == "CS"){
            array_push($SG_pdf_arr,$pdf_name);
        }elseif (substr($pdf_name,7,2) == "C0") {
            array_push($TW_pdf_arr,$pdf_name);
        }elseif (substr($pdf_name,7,2) == "CM" || substr($pdf_name,7,2) == "CH") {
            array_push($HK_pdf_arr,$pdf_name);
        }elseif (substr($pdf_name,7,2) == "CI") {
            array_push($ID_pdf_arr,$pdf_name);
        }elseif (substr($pdf_name,7,2) == "CT") {
            array_push($TH_pdf_arr,$pdf_name);
        }elseif (substr($pdf_name,7,2) == "CY") {
            array_push($MY_pdf_arr,$pdf_name);
        }elseif (substr($pdf_name,7,2) == "CN") {
            array_push($CN_pdf_arr,$pdf_name);
        }elseif (substr($pdf_name,7,2) == "VN") {
            array_push($CN_pdf_arr,$pdf_name);
        }
    }
    $ALL_pdf_arr = [
        'SG'=>$SG_pdf_arr,
        'HK'=>$HK_pdf_arr,
        'TW'=>$TW_pdf_arr,
        'TH'=>$TH_pdf_arr,
        'ID'=>$ID_pdf_arr,
        'MY'=>$MY_pdf_arr,
        'CN'=>$CN_pdf_arr,
        'VN'=>$VN_pdf_arr
    ];
    echo "(".$GLOBALS['pdf_type'].")檔案數量\nSG:".count($SG_pdf_arr)."\nTW:".count($TW_pdf_arr)."\nHK:".count($HK_pdf_arr)."\nID:".count($ID_pdf_arr)."\nTH:".count($TH_pdf_arr)."\nMY:".count($MY_pdf_arr)."\nCN:".count($CN_pdf_arr)."\nVN:".count($VN_pdf_arr);
    $fp = fopen("$base_source_dir.json", 'w');
    fwrite($fp, json_encode($ALL_pdf_arr));
    fclose($fp);
}

if(strpos($base_source_dir, "desc") === false){
    $pdf_type = '繁版';
}else{
    $pdf_type = '簡版';
}
sync_pdf_from_s3($base_source_dir);
sort_data($base_source_dir);

