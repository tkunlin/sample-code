import os
import time
import sys
import boto3
arr = [sys.argv[1]]
env = sys.argv[2]
region = sys.argv[3]
ssm = boto3.client('ssm',region_name = region)
def get_parameter():
    response = ssm.get_parameters(
        Names=[
            f'/{env}/Billing/DB/mysql-endpoint',
            f'/{env}/Billing/DB/mysql-user',
            f'/{env}/Billing/DB/mysql-pwd',
            f'/{env}/Billing/DB/mysql-db',
        ],
        WithDecryption=False
    )
    return response


ssm_response = get_parameter()

# get parameter from parameter store
parameters = ssm_response['Parameters']
for parameter in parameters:
    if parameter['Name'] == f'/{env}/Billing/DB/mysql-endpoint': db_host = parameter['Value']
    if parameter['Name'] == f'/{env}/Billing/DB/mysql-user': db_user = parameter['Value']
    if parameter['Name'] == f'/{env}/Billing/DB/mysql-pwd': db_pass = parameter['Value']
    if parameter['Name'] == f'/{env}/Billing/DB/mysql-db': db = parameter['Value']  


for i in arr:
    year = i.split('/')[0]
    day = i.split('/')[1]
    cli = """sed 's/bill_period_value/{}\/{}/g'  gmo.sql.tmp> gmo.sql""".format(year,day)
    os.system(cli)
    os.system("mysql -h %s -u %s -p%s %s < gmo.sql | sed 's/\t/!$/g' > %s%s.txt" % (db_host,db_user,db_pass,db,year,day))



os.system("zip gmo_data.zip ./*.txt")
# os.system("aws s3 cp gmo_data.zip s3://ecv-us-west-2-dev/tmp/ --acl bucket-owner-full-control")
# os.system("aws s3 cp gmo_data.zip s3://billing-dev-report/ --acl bucket-owner-full-control")
# os.system("rm ./*.txt")
# os.system("rm ./*.zip")
