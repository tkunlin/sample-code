select 
a.id                                                                        as e_id
,FROM_UNIXTIME(a.change_time)                                                as e_change_time
,a.change_master                                                             as e_change_master
,a.bill_period                                                               as e_bill_period
,a.bill_customer                                                             as e_bill_customer
,b.linkedaccountid                                                           as ae_linkedaccountid
,a.bill_product                                                              as e_bill_product
,case when b.PayerAccountId <> '' then b.PayerAccountId else a.PayerAccountId end  a_PayerAccountId
,a.RateId                                                                    as x_RateId
,a.SubscriptionId                                                            as a_SubscriptionId
,a.SubscriptionId_origin                                                     as x_SubscriptionId_origin
,a.UsageType                                                                 as a_UsageType
,a.Operation                                                                 as x_Operation
,a.AvailabilityZone                                                          as a_AvailabilityZone
,a.ReservedInstance                                                          as e_ReservedInstance
,a.ItemDescription                                                           as ae_ItemDescription
,a.UsageStartDate                                                            as ae_UsageStartDate
,a.UsageEndDate                                                              as ae_UsageEndDate
,a.UsageQuantity                                                             as ae_UsageQuantity
,a.BlendedRate                                                               as e_BlendedRate
,a.UnBlendedRate                                                             as a_UnBlendedRate
,a.Credits                                                                   as x_Credits
,a.TotalCost                                                                 as ae_TotalCost
,a.UnitPrice                                                                 as e_UnitPrice
,a.DOP                                                                       as e_DOP
,a.d01                                                                       as e_d01
,a.d02                                                                       as e_d02
,a.d03                                                                       as e_d03
,a.d04                                                                       as e_d04
,a.d05                                                                       as e_d05
,a.d06                                                                       as e_d06
,a.d07                                                                       as e_d07
,a.d08                                                                       as e_d08
,a.d09                                                                       as e_d09
,a.d10                                                                       as e_d10
,a.d11                                                                       as e_d11
,a.d12                                                                       as e_d12
,a.d13                                                                       as e_d13
,a.d14                                                                       as e_d14
,a.d15                                                                       as e_d15
,a.d16                                                                       as e_d16
,a.d17                                                                       as e_d17
,a.d18                                                                       as e_d18
,a.d19                                                                       as e_d19
,a.d20                                                                       as e_d20
,a.d21                                                                       as e_d21
,a.d22                                                                       as e_d22
,a.d23                                                                       as e_d23
,a.d24                                                                       as e_d24
,a.d25                                                                       as e_d25
,a.d26                                                                       as e_d26
,a.d27                                                                       as e_d27
,a.d28                                                                       as e_d28
,a.d29                                                                       as e_d29
,a.d30                                                                       as e_d30
,a.d31                                                                       as e_d31
,a.hide                                                                      as e_hide
,a.invoiceid                                                                 as a_invoiceid
,a.billing_entity                                                            as ae_billing_entity
,a.bill_product_name                                                         as a_bill_product_name
,a.billtype                                                                  as a_billtype
,a.lineitem_type                                                             as a_lineitem_type
,a.pricing_term                                                              as a_pricing_term
,a.os                                                                        as a_os
,a.product_location                                                          as a_product_location
,a.pricing_LeaseContractLength                                               as a_pricing_LeaseContractLength
,a.pricing_OfferingClass                                                     as a_pricing_OfferingClass
,a.reservation_arn                                                           as a_reservation_arn
,a.reservation_StartTime                                                     as a_reservation_StartTime
,a.reservation_EndTime                                                       as a_reservation_EndTime
,a.reservation_ModificationStatus                                            as a_reservation_ModificationStatus
,a.reservation_AmortizedUpfrontCostForUsage                                  as a_reservation_AmortizedUpfrontCostForUsage
,a.reservation_AmortizedUpfrontFeeForBillingPeriod                           as a_reservation_AmortizedUpfrontFeeForBillingPeriod
,a.reservation_EffectiveCost                                                 as a_reservation_EffectiveCost
,a.reservation_NumberOfReservations                                          as a_reservation_NumberOfReservations
,a.reservation_RecurringFeeForUsage                                          as a_reservation_RecurringFeeForUsage
,a.reservation_TotalReservedUnits                                            as a_reservation_TotalReservedUnits
,a.reservation_UnusedAmortizedUpfrontFeeForBillingPeriod                     as a_reservation_UnusedAmortizedUpfrontFeeForBillingPeriod
,a.reservation_UnusedNormalizedUnitQuantity                                  as a_reservation_UnusedNormalizedUnitQuantity
,a.reservation_UnusedRecurringFee                                            as a_reservation_UnusedRecurringFee
,a.reservation_UpfrontValue                                                  as a_reservation_UpfrontValue
,a.normalizationsizefactor                                                   as a_normalizationsizefactor
,a.product_instancetypefamily                                                as a_product_instancetypefamily
,a.pricing_publicOnDemandRate                                                as a_pricing_publicOnDemandRate
,a.purchaseoption                                                            as a_purchaseoption
,a.unitprice_si                                                              as e_unitprice_si
,a.product_instanceType                                                      as a_product_instanceType
,a.sum_normalizedUsageAmount                                                 as ae_sum_normalizedUsageAmount
,a.sum_reservation_UnusedQuantity                                            as ae_sum_reservation_UnusedQuantity
,a.OriginalCost                                                              as e_OriginalCost
,a.RealCostExcludeUpfront                                                    as e_RealCostExcludeUpfront
,a.RealCostIncludeUpfront                                                    as e_RealCostIncludeUpfront
,a.CostSavings                                                               as e_CostSavings
,a.Revenue                                                                   as e_Revenue
,a.Profit                                                                    as e_Profit
,a.RIUsageDescription                                                        as e_RIUsageDescription
,a.savingsplan_arn                                                           as a_savingsplan_arn
,a.itemdescription_ori                                                       as e_itemdescription_ori
,a.savingsPlan_UsedCommitment                                                as a_savingsPlan_UsedCommitment
,a.savingsPlanEffectiveCost                                                  as a_savingsPlanEffectiveCost
,a.savingsPlan_TotalCommitmentToDate                                         as a_savingsPlan_TotalCommitmentToDate
,a.savingsPlan_SavingsPlanRate                                               as a_savingsPlan_SavingsPlanRate
,c.name                                                                      as change_master_name
,b.cno                                                                       as bill_customer_no
,b.cname                                                                     as bill_customer_name
,case when unitprice <> '' then unitprice * usagequantity else totalcost end bill_revenue
from bill_item a
left join bill_customer b on b.id=a.bill_customer
left join bill_master c on  c.id=a.change_master
where a.bill_period ='2022/01'
AND a.hide = 'n'
AND dop <> 't'
AND ((unitprice = ''
AND totalcost > 0.005)
OR unitprice * usagequantity > 0.005
OR dop = 'y'
OR (ReservedInstance = 'y'
AND totalcost >= 0))