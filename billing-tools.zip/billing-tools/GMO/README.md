# gmo.py
## Get bill_item data and transfer to a txt file
* How to use gmo.py
***
1. python3 gmo.py {bill_period} {env} {region}
* EX: python3 gmo.py 2022/04 Prod us-west-2


