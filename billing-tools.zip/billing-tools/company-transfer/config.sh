#/bin/bash

# Logger date&time
LOG_DATE_CMD=$(date "+%Y-%b-%d %H:%M:%S")

# File date&time
# y=$(date +%Y)
# m=$(date +%m -d "$date")
# d=$(date +%d -d "$date")
# date=$(date -I)
billing_month=$(date +%Y%m --date=" -1 month")
cur_date=$(date +%m%d)
table=$2
company_type=$3
# Parameter Store
# HOST=$(aws ssm get-parameter --name "/"$1"/Billing/DB/mysql-replica-endpoint" --region us-west-2 | jq --raw-output ".Parameter.Value")
HOST=$(aws ssm get-parameter --name "/"${1^}"/Billing/DB/mysql-endpoint" --region us-west-2 | jq --raw-output ".Parameter.Value")
USER=$(aws ssm get-parameter --name "/"${1^}"/Billing/DB/mysql-user" --region us-west-2 | jq --raw-output ".Parameter.Value")
PASSWORD=$(aws ssm get-parameter --name "/"${1^}"/Billing/DB/mysql-pwd" --region us-west-2 | jq --raw-output ".Parameter.Value")
if [ $1 == "prod" ] || [ $1 == "uat" ] || [ $1 == "stage" ]
then 
    DBNAME=$(aws ssm get-parameter --name "/"${1^}"/Billing/DB/mysql-db" --region us-west-2 | jq --raw-output ".Parameter.Value")
    S3="s3://billing-$1-bucket-c8/dump_files/$billing_month/$cur_date/"
elif [ $1 == "dev" ]
then
    S3="s3://billing-$1-bucket/dump_files/$billing_month/$cur_date/"
    if [ $company_type == "ecv" ]
    then
        DBNAME=$(aws ssm get-parameter --name "/"${1^}"/Billing/DB/mysql-db" --region us-west-2 | jq --raw-output ".Parameter.Value")
    elif [ $company_type == "ecr" ]
    then
        DBNAME=$(aws ssm get-parameter --name "/"${1^}"/Billing/DB/mysql-db-c8" --region us-west-2 | jq --raw-output ".Parameter.Value")
    else
        echo "Please check company type"
    fi
else
    echo "Please check environment parameter"
fi
# table=$2

# LIST="'127965512393','569158695565','561087793992','962544878618','977542297788','115721035814','351098411340','058939530235','454679868147','144352674924','784250267761','582102752735','609062161413','351128509497','142533113548'"
# BILL_PERIOD="$3"
tb_name_1="bill_customer_transfer"
# tb_name_2="bill_invoice_revenue_transfer"
tb_name_3="bill_item_transfer"
tb_name_4="bill_ri_new_transfer"
# tb_name_5="bill_savingplan_list_transfer"
tb_name_6="bill_payer_account_transfer"


copy_cust="./tmp_sql/copy_cust.sql"
copy_all="./tmp_sql/copy_all.sql"
drop_tables="./tmp_sql/drop.sql"
update_cust="./tmp_sql/update_cust.sql"
update_all="./tmp_sql/update_all.sql"
delete_item_ri="./tmp_sql/delete_item_ri.sql"
