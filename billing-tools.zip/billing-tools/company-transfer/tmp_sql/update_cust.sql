-- update customer information
update bill_customer_transfer bct
left join customer_map_transfer cmt on bct.cno = cmt.cno
set bct.change_time             =unix_timestamp()
, bct.contact               = cmt.contact
, bct.contact_email         = cmt.contact_email
, bct.overdue_email         = cmt.overdue_email
, bct.tel                   = cmt.tel
, bct.mobile                = cmt.mobile
, bct.email                 = cmt.email
, bct.gui_contact           = cmt.gui_contact
, bct.gui_tel               = cmt.gui_tel
, bct.gui_email_invoice1    = cmt.gui_email_invoice1
, bct.gui_email_invoice2    = cmt.gui_email_invoice2
, bct.gui_email_invoice3    = cmt.gui_email_invoice3
, bct.gui_address           = cmt.gui_address
, bct.gui_pending           = cmt.gui_pending
, bct.TaxationAddress       = cmt.TaxationAddress
, bct.cno                   = cmt.cno
, bct.cname                 = cmt.cname
, bct.sap_cno               = cmt.sap_cno
, bct.SIAccount             = cmt.SIAccount
, bct.deadline              = cmt.deadline
, bct.country               = cmt.country
, bct.leadger_country       = cmt.leadger_country
, bct.invoice_merge_no      = cmt.invoice_merge_no
, bct.invoice_month         = cmt.invoice_month
, bct.auto_invoice          = cmt.auto_invoice
where job_status = ''
and left(bct.cno,1) = 'C'
;
DO sleep(1);

-- update internal account leadger_country and country
update bill_customer_transfer bct
left join (select * from customer_map_transfer where cno = 'A') cmt on left(bct.cno,1) = cmt.cno
set bct.change_time         =unix_timestamp()
, bct.country               = cmt.country
, bct.leadger_country       = cmt.leadger_country
, bct.settle_date           = cmt.settle_date
where bct.job_status = ''
and left(bct.cno,1) = 'A'
;
DO sleep(1);

-- update sales information
update bill_customer_transfer bct
left join sales_map_transfer smt on bct.ecloud_sales = smt.r_name_id
set bct.ecloud_sales = smt.v_name_id
where job_status = ''
and left(bct.cno,1) = 'C'
;
DO sleep(1);

-- update settle dept information
update bill_customer_transfer bct
left join sales_map_transfer smt on bct.settle_dept = smt.r_dept_id COLLATE utf8_unicode_ci
set bct.settle_dept = smt.v_dept_id  
where job_status = ''
and smt.r_dept_id is not null
;
DO sleep(1);


update bill_customer bc
inner join (select * from bill_customer_transfer where job_status = '') bct on bc.linkedaccountid = bct.linkedaccountid
set
bc.change_time	=	bct.change_time
,bc.change_customer	=	bct.change_customer
,bc.change_master	=	bct.change_master
,bc.add_time	=	bct.add_time
,bc.add_master	=	bct.add_master
,bc.ecloud_sales	=	bct.ecloud_sales
,bc.keyname	=	bct.keyname
,bc.keypassword	=	bct.keypassword
,bc.keypassword_time	=	bct.keypassword_time
,bc.family	=	bct.family
,bc.family_admin	=	bct.family_admin
,bc.title	=	bct.title
,bc.contact	=	bct.contact
,bc.contact_email	=	bct.contact_email
,bc.overdue_email	=	bct.overdue_email
,bc.name	=	bct.name
,bc.tel	=	bct.tel
,bc.mobile	=	bct.mobile
,bc.email	=	bct.email
,bc.gui_contact	=	bct.gui_contact
,bc.gui_tel	=	bct.gui_tel
,bc.gui_email_invoice1	=	bct.gui_email_invoice1
,bc.gui_email_invoice2	=	bct.gui_email_invoice2
,bc.gui_email_invoice3	=	bct.gui_email_invoice3
,bc.gui_email_einv	=	bct.gui_email_einv
,bc.gui_address	=	bct.gui_address
,bc.gui_memo	=	bct.gui_memo
,bc.gui_pending	=	bct.gui_pending
,bc.LinkedAccountId	=	bct.LinkedAccountId
,bc.LinkedAccountName	=	bct.LinkedAccountName
,bc.TaxationAddress	=	bct.TaxationAddress
,bc.cno	=	bct.cno
,bc.cname	=	bct.cname
,bc.ubn	=	bct.ubn
,bc.sap_cno	=	bct.sap_cno
,bc.business_support_pl	=	bct.business_support_pl
,bc.business_support	=	bct.business_support
,bc.business_support_rate	=	bct.business_support_rate
,bc.business_support_mincharge	=	bct.business_support_mincharge
,bc.discount_period	=	bct.discount_period
,bc.discount	=	bct.discount
,bc.SIAccount	=	bct.SIAccount
,bc.msp	=	bct.msp
,bc.msp_backup	=	bct.msp_backup
,bc.min_charge	=	bct.min_charge
,bc.deadline	=	bct.deadline
,bc.account	=	bct.account
,bc.description	=	bct.description
,bc.secret	=	bct.secret
,bc.accesskey	=	bct.accesskey
,bc.partnerLead	=	bct.partnerLead
,bc.alert_avg_high	=	bct.alert_avg_high
,bc.alert_avg_low	=	bct.alert_avg_low
,bc.alert_max_multiplier	=	bct.alert_max_multiplier
,bc.alert_min_multiplier	=	bct.alert_min_multiplier
,bc.alert_absolute_high	=	bct.alert_absolute_high
,bc.alert_absolute_low	=	bct.alert_absolute_low
,bc.alert_activity	=	bct.alert_activity
,bc.alert_budget	=	bct.alert_budget
,bc.hide	=	bct.hide
,bc.PayerAccountId	=	bct.PayerAccountId
,bc.exchange_type	=	bct.exchange_type
,bc.tax_rate	=	bct.tax_rate
,bc.currency	=	bct.currency
,bc.currency_pay	=	bct.currency_pay
,bc.bill_format	=	bct.bill_format
,bc.bill_detail	=	bct.bill_detail
,bc.country	=	bct.country
,bc.leadger_country	=	bct.leadger_country
,bc.service_level	=	bct.service_level
,bc.customer_type	=	bct.customer_type
,bc.invoice_month	=	bct.invoice_month
,bc.invoice_merge_no	=	bct.invoice_merge_no
,bc.reserve_amount	=	bct.reserve_amount
,bc.settle_date	=	bct.settle_date
,bc.settle_dept	=	bct.settle_dept
,bc.ava_rpt	=	bct.ava_rpt
,bc.inv_rpt	=	bct.inv_rpt
,bc.per_rpt	=	bct.per_rpt
,bc.sec_rpt	=	bct.sec_rpt
,bc.rs_rpt	=	bct.rs_rpt
,bc.cn_tax	=	bct.cn_tax
,bc.cpu_rpt	=	bct.cpu_rpt
,bc.auto_invoice	=	bct.auto_invoice
,bc.auto_billing_rpt	=	bct.auto_billing_rpt
,bc.bank_name	=	bct.bank_name
,bc.bank_swift_code	=	bct.bank_swift_code
,bc.bank_account_no	=	bct.bank_account_no
,bc.bank_account_name	=	bct.bank_account_name
,bc.domain_name	=	bct.domain_name
,bc.zip_code	=	bct.zip_code
,bc.industry_catalog	=	bct.industry_catalog
where bc.hide = 'n'
;
DO sleep(1);

-- insert into Prod bill_customer
insert into bill_customer 
(change_time,change_customer,change_master,add_time,add_master,ecloud_sales,keyname,keypassword,keypassword_time,family,family_admin
,title,contact,contact_email,overdue_email,name,tel,mobile,email,gui_contact,gui_tel
,gui_email_invoice1,gui_email_invoice2,gui_email_invoice3,gui_email_einv,gui_address,gui_memo,gui_pending,LinkedAccountId,LinkedAccountName,TaxationAddress
,cno,cname,ubn,sap_cno,business_support_pl,business_support,business_support_rate,business_support_mincharge,discount_period,discount
,SIAccount,msp,msp_backup,min_charge,deadline,account,description,secret,accesskey,partnerLead
,alert_avg_high,alert_avg_low,alert_max_multiplier,alert_min_multiplier,alert_absolute_high,alert_absolute_low,alert_activity,alert_budget,hide,PayerAccountId
,exchange_type,tax_rate,currency,currency_pay,bill_format,bill_detail,country,leadger_country,service_level,customer_type
,invoice_month,invoice_merge_no,reserve_amount,settle_date,settle_dept,ava_rpt,inv_rpt,per_rpt,sec_rpt,rs_rpt
,cn_tax,cpu_rpt,auto_invoice,auto_billing_rpt,bank_name,bank_swift_code,bank_account_no,bank_account_name,domain_name,zip_code
,industry_catalog
)
select 
a.change_time,a.change_customer,a.change_master,a.add_time,a.add_master,a.ecloud_sales,a.keyname,a.keypassword,a.keypassword_time,a.family
,a.family_admin,a.title,a.contact,a.contact_email,a.overdue_email,a.name,a.tel,a.mobile,a.email,a.gui_contact
,a.gui_tel,a.gui_email_invoice1,a.gui_email_invoice2,a.gui_email_invoice3,a.gui_email_einv,a.gui_address,a.gui_memo,a.gui_pending,a.LinkedAccountId,a.LinkedAccountName
,a.TaxationAddress,a.cno,a.cname,a.ubn,a.sap_cno,a.business_support_pl,a.business_support,a.business_support_rate,a.business_support_mincharge,a.discount_period,a.discount
,a.SIAccount,a.msp,a.msp_backup,a.min_charge,a.deadline,a.account,a.description,a.secret,a.accesskey,a.partnerLead
,a.alert_avg_high,a.alert_avg_low,a.alert_max_multiplier,a.alert_min_multiplier,a.alert_absolute_high,a.alert_absolute_low,a.alert_activity,a.alert_budget,a.hide,a.PayerAccountId
,a.exchange_type,a.tax_rate,a.currency,a.currency_pay,a.bill_format,a.bill_detail,a.country,a.leadger_country,a.service_level,a.customer_type,a.invoice_month
,a.invoice_merge_no,a.reserve_amount,a.settle_date,a.settle_dept,a.ava_rpt,a.inv_rpt,a.per_rpt,a.sec_rpt,a.rs_rpt,a.cn_tax
,a.cpu_rpt,a.auto_invoice,a.auto_billing_rpt,a.bank_name,a.bank_swift_code,a.bank_account_no,a.bank_account_name,a.domain_name,a.zip_code,a.industry_catalog
from bill_customer_transfer a
left join (select * from bill_customer where hide = 'n') b on a.linkedaccountid = b.linkedaccountid
where a.job_status = ''
and b.linkedaccountid is null
;
DO sleep(1);


update bill_customer_transfer
set job_time=unix_timestamp()
, job_status=1
where job_status = ''
;
Do sleep(1);

-- update invoice merge no for CH939
update customer_map_transfer
set invoice_merge_no = (select min(id) from bill_customer where cno = 'CH939' and hide = 'n')
where cno = 'CH939'
;
Do sleep(0.5);
update bill_customer
set invoice_merge_no = (select invoice_merge_no from customer_map_transfer where cno = 'CH939')
, change_time=unix_timestamp()
where cno = 'CH939' 
and hide = 'n'
;

-- update invoice merge no for internal accounts
update bill_customer
set invoice_merge_no = id
where hide = 'n'
and left(cno,1) = 'A'
and PayerAccountId in (select account_no from bill_payer_account where right(account_name,8) = 'transfer')
;