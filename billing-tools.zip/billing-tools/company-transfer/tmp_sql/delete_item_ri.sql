-- delet before insert and update bill_item --
DELETE FROM bill_item
WHERE bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
AND bill_customer in (
SELECT id FROM bill_customer WHERE PayerAccountId in (SELECT account_no FROM bill_payer_account WHERE RIGHT(account_name,8) = 'transfer'))
;
Do sleep(0.5);

-- delete before insert and update bill_ri_new -- 
DELETE FROM bill_ri_new
WHERE bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
AND Payer_Account_Id in (SELECT account_no FROM bill_payer_account WHERE RIGHT(account_name,8) = 'transfer')
;
Do sleep(0.5);