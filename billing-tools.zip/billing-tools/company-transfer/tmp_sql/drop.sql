DROP TABLE if exists bill_customer_transfer;
DROP TABLE if exists bill_item_transfer;
-- , bill_invoice_revenue_transfer
DROP TABLE if exists bill_ri_new_transfer;
-- DROP TABLE if exists bill_savingplan_list_transfer;
DROP TABLE if exists bill_payer_account_transfer;