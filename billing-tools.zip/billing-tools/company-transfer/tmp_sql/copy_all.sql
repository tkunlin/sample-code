-- copy bill_item
Create Table if not exists bill_item_transfer like bill_item
;
insert into bill_item_transfer select * from bill_item 
where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and bill_customer in (
select id from bill_customer where payeraccountid in (
select account_no from bill_payer_account where right(account_name,8)='transfer'
))
;
Do sleep(0.5);

update bill_item_transfer a
left join (select id , linkedaccountid , payeraccountid from bill_customer where payeraccountid in (
select account_no from bill_payer_account where right(account_name,8)='transfer'
)) b on a.bill_customer = b.id
set a.linkedaccountid = b.linkedaccountid
where a.linkedaccountid is null
;
alter table bill_item_transfer drop column id
;
DO sleep(1);
-- copy bill_invoice_revenue
-- Create Table if not exists bill_invoice_revenue_transfer like bill_invoice_revenue;
-- insert into bill_invoice_revenue_transfer select * from bill_invoice_revenue 
-- where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
-- and bill_customer in ( select id from bill_customer where payeraccountid in (
--     select account_no from bill_payer_account where right(account_name,8)='transfer'));

-- copy bill_ri_new
Create Table if not exists bill_ri_new_transfer like bill_ri_new
;
insert into bill_ri_new_transfer select * from bill_ri_new 
where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and Payer_Account_Id in (
select account_no from bill_payer_account where right(account_name,8)='transfer'
)
;
alter table bill_ri_new_transfer drop column id
;
DO sleep(1);

-- copy bill_savingplan_list
-- Create Table if not exists bill_savingplan_list_transfer like bill_savingplan_list
-- ;
-- insert into bill_savingplan_list_transfer select * from bill_savingplan_list 
-- where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
-- and PayerAccountId in (
-- select account_no from bill_payer_account where right(account_name,8)='transfer'
-- )
-- ;
-- alter table bill_savingplan_list_transfer drop column id
-- ;
-- DO sleep(1);

-- copy bill_payer_account
Create Table if not exists bill_payer_account_transfer like bill_payer_account
;
insert into bill_payer_account_transfer select * from bill_payer_account 
where right(account_name,8)='transfer'
;
alter table bill_payer_account_transfer drop column id ,drop column release_date
;