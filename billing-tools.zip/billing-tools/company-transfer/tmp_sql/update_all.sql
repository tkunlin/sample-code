-- update information in bill_payer_account_transfer
update bill_payer_account_transfer
set s3_bucket = ''
, change_time=unix_timestamp()
, change_master = 1
, country = 'HK'
, payment_country = 'HK'
where job_status = ''
;
DO sleep(0.5);

-- update bill_payer_account if exists
update bill_payer_account bpa 
inner join bill_payer_account_transfer bpat
on bpa.account_no = bpat.account_no
set
bpa.account_no                  = bpat.account_no					
,bpa.account_name               = bpat.account_name
,bpa.account_key                = bpat.account_key
,bpa.account_secret             = bpat.account_secret
,bpa.s3_bucket                  = bpat.s3_bucket
,bpa.job_id                     = bpat.job_id
,bpa.shared                     = bpat.shared
,bpa.status                     = bpat.status
,bpa.hide                       = bpat.hide
,bpa.change_time                = bpat.change_time
,bpa.change_master              = bpat.change_master
,bpa.RI_Rebilling               = bpat.RI_Rebilling
,bpa.Enterprise_Support         = bpat.Enterprise_Support
,bpa.Disablecredit              = bpat.Disablecredit
,bpa.partnerID                  = bpat.partnerID
,bpa.cfrc_dfrc                  = bpat.cfrc_dfrc
,bpa.note                       = bpat.note
,bpa.billing_block              = bpat.billing_block
,bpa.edp                        = bpat.edp
,bpa.country                    = bpat.country
,bpa.support_plan               = bpat.support_plan
,bpa.rebate_rate                = bpat.rebate_rate
,bpa.cloudtrail_bucket          = bpat.cloudtrail_bucket
,bpa.payment_country            = bpat.payment_country
;
DO sleep(0.5);

-- insert if not exists
insert into bill_payer_account (
account_no,account_name,account_key,account_secret,s3_bucket,job_id,shared,status,hide,change_time,change_master
,RI_Rebilling,Enterprise_Support,Disablecredit,partnerID,cfrc_dfrc,note,billing_block,edp,country,support_plan
,rebate_rate,cloudtrail_bucket,payment_country
)
select
bpat.account_no,bpat.account_name,bpat.account_key,bpat.account_secret,bpat.s3_bucket,bpat.job_id,bpat.shared,bpat.status,bpat.hide
,bpat.change_time,bpat.change_master,bpat.RI_Rebilling,bpat.Enterprise_Support,bpat.Disablecredit,bpat.partnerID,bpat.cfrc_dfrc,bpat.note
,bpat.billing_block,bpat.edp,bpat.country,bpat.support_plan,bpat.rebate_rate,bpat.cloudtrail_bucket,bpat.payment_country
from bill_payer_account_transfer bpat
left join bill_payer_account bpa on bpat.account_no = bpa.account_no
where bpa.account_no is null
and bpat.job_status = ''
;
DO sleep(0.5);

update bill_payer_account_transfer
set job_time=unix_timestamp()
, job_status = 1
where job_status = ''
;
Do sleep(1);

-- update field bill_customer in bill_item_transfer
update bill_item_transfer bit 
left join (select id , PayerAccountId , linkedaccountid from bill_customer 
    where hide = 'n'
    and (cno = 'CH939'
    or (left(cno,1) = 'A' and payeraccountid in (
    select account_no from bill_payer_account where right(account_name,8)='transfer'
    )
    ))) bc 
on bit.linkedaccountid = bc.linkedaccountid
set 
bit.bill_customer   = bc.id
, bit.change_time       =unix_timestamp()
, bit.change_master     = 1
where bit.bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and bit.job_status = ''
;
DO sleep(0.5);

-- insert to prod bill_item
insert into bill_item (change_time,change_master,bill_period,bill_customer,linkedaccountid,bill_product,PayerAccountId,RateId,SubscriptionId,SubscriptionId_origin
,UsageType,Operation,AvailabilityZone,ReservedInstance,ItemDescription,UsageStartDate,UsageEndDate,UsageQuantity,BlendedRate,UnBlendedRate
,Credits,TotalCost,UnitPrice,DOP
,d01,d02,d03,d04,d05,d06,d07,d08,d09,d10,d11,d12,d13,d14,d15,d16,d17,d18,d19,d20,d21,d22,d23,d24,d25,d26,d27,d28,d29,d30,d31
,hide,invoiceid,billing_entity,bill_product_name,billtype,lineitem_type,pricing_term,os,product_location,pricing_LeaseContractLength,pricing_OfferingClass
,reservation_arn,reservation_StartTime,reservation_EndTime,reservation_ModificationStatus,reservation_AmortizedUpfrontCostForUsage,reservation_AmortizedUpfrontFeeForBillingPeriod,reservation_EffectiveCost
,reservation_NumberOfReservations,reservation_RecurringFeeForUsage,reservation_TotalReservedUnits,reservation_UnusedAmortizedUpfrontFeeForBillingPeriod,reservation_UnusedNormalizedUnitQuantity
,reservation_UnusedRecurringFee,reservation_UpfrontValue,normalizationsizefactor,product_instancetypefamily,pricing_publicOnDemandRate,purchaseoption,unitprice_si,product_instanceType,sum_normalizedUsageAmount
,sum_reservation_UnusedQuantity,OriginalCost,RealCostExcludeUpfront,RealCostIncludeUpfront,CostSavings,Revenue,Profit,RIUsageDescription,savingsplan_arn,itemdescription_ori,savingsPlan_UsedCommitment
,savingsPlanEffectiveCost,savingsPlan_TotalCommitmentToDate,savingsPlan_SavingsPlanRate
)
select change_time,change_master,bill_period,bill_customer,linkedaccountid,bill_product,PayerAccountId,RateId,SubscriptionId,SubscriptionId_origin
,UsageType,Operation,AvailabilityZone,ReservedInstance,ItemDescription,UsageStartDate,UsageEndDate,UsageQuantity,BlendedRate,UnBlendedRate
,Credits,TotalCost,UnitPrice,DOP
,d01,d02,d03,d04,d05,d06,d07,d08,d09,d10,d11,d12,d13,d14,d15,d16,d17,d18,d19,d20,d21,d22,d23,d24,d25,d26,d27,d28,d29,d30,d31
,hide,invoiceid,billing_entity,bill_product_name,billtype,lineitem_type,pricing_term,os,product_location,pricing_LeaseContractLength,pricing_OfferingClass
,reservation_arn,reservation_StartTime,reservation_EndTime,reservation_ModificationStatus,reservation_AmortizedUpfrontCostForUsage,reservation_AmortizedUpfrontFeeForBillingPeriod,reservation_EffectiveCost
,reservation_NumberOfReservations,reservation_RecurringFeeForUsage,reservation_TotalReservedUnits,reservation_UnusedAmortizedUpfrontFeeForBillingPeriod,reservation_UnusedNormalizedUnitQuantity
,reservation_UnusedRecurringFee,reservation_UpfrontValue,normalizationsizefactor,product_instancetypefamily,pricing_publicOnDemandRate,purchaseoption,unitprice_si,product_instanceType,sum_normalizedUsageAmount
,sum_reservation_UnusedQuantity,OriginalCost,RealCostExcludeUpfront,RealCostIncludeUpfront,CostSavings,Revenue,Profit,RIUsageDescription,savingsplan_arn,itemdescription_ori,savingsPlan_UsedCommitment
,savingsPlanEffectiveCost,savingsPlan_TotalCommitmentToDate,savingsPlan_SavingsPlanRate
from bill_item_transfer 
where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and job_status = ''
;
DO sleep(0.5);

update bill_item_transfer
set job_time=unix_timestamp()
, job_status = 1
where job_status = ''
;
Do sleep(1);


/*
-- update bill_invoice_revenue_transfer birt
-- left join (select * from bill_customer where cno = 'CH939') bc on birt.linkedaccountid = bc.linkedaccountid
-- set birt.bill_customer = bc.id
-- , change_time=unix_timestamp()
-- , birt.leadger_country = bc.leadger_country
-- , birt.invoice_merge_no = bc.invoice_merge_no
-- , change_time=unix_timestamp()
-- where birt.bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m");
*/


/*
-- insert into bill_invoice_revenue 
-- select * from bill_invoice_revenue_transfer 
-- where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m");
*/

-- update change time in bill_ri_new_transfer
update bill_ri_new_transfer
set change_time=unix_timestamp()
where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and job_status = ''
;
DO sleep(0.5);

-- insert into Prod bill_ri_new
insert into bill_ri_new (
bill_period,change_time,change_master,platform,Payer_Account_Id,Linked_Account_Id,Service,Begin_Date,End_Date,Offering_Type_Description
,Instance_Type,Fixed_Price,Product_Description,External_Az,Billing_Subscription_Id,Lease_Term,State,Lease_Id,Instance_Count,Charge_Amount_Before_Tax
,Region,Usage_Price,Tenancy,Usage_Type,Purchased_Hours,Unused_Hours,Utilization_Percentage,Total_Actual_Hours
)
select 
bill_period,change_time,change_master,platform,Payer_Account_Id,Linked_Account_Id,Service,Begin_Date,End_Date,Offering_Type_Description
,Instance_Type,Fixed_Price,Product_Description,External_Az,Billing_Subscription_Id,Lease_Term,State,Lease_Id,Instance_Count,Charge_Amount_Before_Tax
,Region,Usage_Price,Tenancy,Usage_Type,Purchased_Hours,Unused_Hours,Utilization_Percentage,Total_Actual_Hours
from bill_ri_new_transfer 
where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and job_status = ''
;
DO sleep(0.5);
-- update job status and time in bill_ri_new_transfer
update bill_ri_new_transfer
set job_time=unix_timestamp()
, job_status = 1
where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
and job_status = ''
;
DO sleep(1);

-- insert into Prod bill_savingplan_list
-- insert into bill_savingplan_list (
-- PayerAccountId,linkedaccountid,LinkedAccountName,bill_period,StartDateTime,EndDateTime,HourlyCommitment,InstanceFamily,PaymentOption,PurchaseTerm
-- ,RecurringHourlyFee,Region,SavingsPlanARN,SavingsPlansType,UpfrontFee,TotalCommitment,UsedCommitment,UnusedCommitment,UtilizationPercentage,NetSavings,OnDemandCostEquivalent
-- ,AmortizedRecurringCommitment,AmortizedUpfrontCommitment,TotalAmortizedCommitment,create_time,update_time
-- )
-- select
-- PayerAccountId,linkedaccountid,LinkedAccountName,bill_period,StartDateTime,EndDateTime,HourlyCommitment,InstanceFamily,PaymentOption,PurchaseTerm
-- ,RecurringHourlyFee,Region,SavingsPlanARN,SavingsPlansType,UpfrontFee,TotalCommitment,UsedCommitment,UnusedCommitment,UtilizationPercentage,NetSavings,OnDemandCostEquivalent
-- ,AmortizedRecurringCommitment,AmortizedUpfrontCommitment,TotalAmortizedCommitment,create_time,update_time
-- from bill_savingplan_list_transfer 
-- where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
-- and job_status = ''
-- ;
-- DO sleep(0.5);
-- update job status and time in bill_savingplan_list_transfer
-- update bill_savingplan_list_transfer
-- set job_time=unix_timestamp()
-- , job_status = 1
-- where bill_period = date_format(date_sub(now(), interval 1 month), "%Y/%m")
-- and job_status = ''
-- ;

/*
-- udpate log fields to tmp tables
-- update bill_item_transfer set job_time=unix_timestamp(), job_status=1;
-- update bill_invoice_revenue_transfer set job_time=unix_timestamp(), job_status=1;
-- update bill_ri_new_transfer set job_time=unix_timestamp(), job_status=1;
-- update bill_savingplan_list_transfer set job_time=unix_timestamp(), job_status=1;
*/