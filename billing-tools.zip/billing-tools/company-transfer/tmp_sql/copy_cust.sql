-- copy bill_customer 
Create Table if not exists bill_customer_transfer like bill_customer
;
insert into bill_customer_transfer select * from bill_customer 
where payeraccountid in (select account_no from bill_payer_account where right(account_name,8)='transfer')
;
update bill_customer_transfer
set cno = 'CH939'
where left (cno,1) = 'C'
;
-- alter table drop column id;
alter table bill_customer_transfer drop column id
;