#!/bin/bash
source ./config.sh
mkdir -p ./dump_files
#dump tables
if [ $table == "bc" ]
then
    #copy tables and drop id field
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Copy bill_customer table------"
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < $copy_cust
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Dump bill_customer table------"
    mysqldump -h $HOST -u $USER -p$PASSWORD $DBNAME --set-gtid-purged=OFF --skip-add-drop-table --no-create-info --default-character-set=utf8 --single-transaction --complete-insert \
    $tb_name_1 > ./dump_files/$billing_month-$cur_date-$tb_name_1.sql
    # sed -i 's/bill_customer_transfer/bill_customer/g' ./dump_files/$billing_month-$tb_name_1.sql

elif [ $table == "all" ]
then
    #copy tables and drop id field
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Copy all tables------"
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < $copy_all
    # mysqldump -h $HOST -u $USER -p$PASSWORD $DBNAME --set-gtid-purged=OFF --column-statistics=0 --skip-add-drop-table --no-create-info --default-character-set=utf8 --single-transaction --complete-insert \
    # $tb_name_2 > ./dump_files/$billing_month-$cur_date-$tb_name_2.sql
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Dump all tables------"
    mysqldump -h $HOST -u $USER -p$PASSWORD $DBNAME --set-gtid-purged=OFF --skip-add-drop-table --no-create-info --default-character-set=utf8 --single-transaction --complete-insert \
    $tb_name_3 > ./dump_files/$billing_month-$cur_date-$tb_name_3.sql

    mysqldump -h $HOST -u $USER -p$PASSWORD $DBNAME --set-gtid-purged=OFF --skip-add-drop-table --no-create-info --default-character-set=utf8 --single-transaction --complete-insert \
    $tb_name_4 > ./dump_files/$billing_month-$cur_date-$tb_name_4.sql

    # mysqldump -h $HOST -u $USER -p$PASSWORD $DBNAME --set-gtid-purged=OFF --skip-add-drop-table --no-create-info --default-character-set=utf8 --single-transaction --complete-insert \
    # $tb_name_5 > ./dump_files/$billing_month-$cur_date-$tb_name_5.sql

    mysqldump -h $HOST -u $USER -p$PASSWORD $DBNAME --set-gtid-purged=OFF --skip-add-drop-table --no-create-info --default-character-set=utf8 --single-transaction --complete-insert \
    $tb_name_6 > ./dump_files/$billing_month-$cur_date-$tb_name_6.sql

else
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") [Error] Wrong Input------"
fi

#upload S3
echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Upload files------"
/usr/local/bin/aws s3 cp ./dump_files/ $S3 --recursive

#drop tables
echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Drop tables------"
mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < $drop_tables
#remove local folder files
echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Remove files in dump_files folder------"
rm -rf ./dump_files/*.sql
echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Finished------"

