#!/bin/bash
source ./config.sh
mkdir -p ./insert_files
echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Download files------"
/usr/local/bin/aws s3 sync $S3 ./insert_files/


if [ $table == "bc" ]
then
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") insert to tmp table------"
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < ./insert_files/$billing_month-$cur_date-$tb_name_1.sql
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") update info and insert to prod table------"
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < $update_cust
elif [ $table == "all" ]
then
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Delete duplicate bill_item and ri_new data------"
    # mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < ./insert_files/$billing_month-$cur_date-$tb_name_2.sql
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < $delete_item_ri
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") insert to tmp tables------"
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < ./insert_files/$billing_month-$cur_date-$tb_name_3.sql
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < ./insert_files/$billing_month-$cur_date-$tb_name_4.sql
    # mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < ./insert_files/$billing_month-$cur_date-$tb_name_5.sql
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < ./insert_files/$billing_month-$cur_date-$tb_name_6.sql
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") update info and insert to prod tables------"
    mysql -h $HOST -u $USER -p$PASSWORD -D $DBNAME < $update_all
else
    echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") [Error] Wrong Input------"
fi

echo "------[Log] $(date "+%Y-%b-%d %H:%M:%S") Finished------"


