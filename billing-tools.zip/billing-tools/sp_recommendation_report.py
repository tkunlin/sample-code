import json
import sys
import os
import pandas as pd
from lib.db import DB
from lib import init_db
from datetime import datetime

# CLI： python3 sp_recommendation_report.py yyyy/mm link1,link2,link3 [init]
now = datetime.now()
date = sys.argv[1] #yyyy/mm
linkedaccount_list = sys.argv[2].split(',')
init_date = datetime.strptime(date, '%Y/%m').date()
init_year = init_date.year
init_month = init_date.month

# 跨年處理
if(init_year is not now.year):
    init_year = now.year
if(init_month is 12):
    init_month = 1
else:
    init_month = init_month+1

file_date = date.replace("/", "-")
backup_file_name = 'init_maindb_{}-{:0>2}-05_no_bill_item.sql'.format(init_year,init_month)
database_name = 'ecloud_tools'
db = DB(database=database_name,endpoint='main')
    

def generate_sp_report():
    for _id, linkedaccount in enumerate(linkedaccount_list):
        # res = db.execute("SELECT payeraccountid FROM bill_customer where linkedaccountid = '{}' and hide = 'n'".format(int(linkedaccount)), have_result=True)
        # try:
        #     p = res['result'][0]['payeraccountid']
        # except:
        #     print("LinkedAccounted:{} , no payer!!!".format(linkedaccount))
        #     continue
        # # key = "cur-stage/cur_hourly/{}/cur_{}_{}.sql".format('-'.join(date.split('/')),linkedaccount, p)
        # key = "ecv-us-west-2-dev/cur_hourly/{}/cur_{:0>12}_{}.sql --profile tw03".format('-'.join(date.split('/')),linkedaccount, p)
        # os.system("aws s3 cp s3://{} /tmp/".format(key))
        # os.system("mysql -u root -p!QAZ2wsx3edc -h atlas-stage-2.cnw7guvufew0.us-west-2.rds.amazonaws.com atlas_local < /tmp/cur_{:0>12}_{}.sql".format(linkedaccount, p))
        # os.system("python3 sp_recommend_main.py {} {:0>12} sp".format(date,linkedaccount))
        # os.system("rm /tmp/cur_{:0>12}_{}.sql".format(linkedaccount, p))
        # db.execute("delete table atlas_local.cur_{:0>12}".format(linkedaccount))
        # print("done", linkedaccount)
        # print(_id,"/", len(linkedaccount_list))
        # exit
        try:
            res = db.execute("""SELECT 
                r.linked_account 'Account ID',
                r.plan_type 'Plan Type',
                r.location 'Region',
                r.instance_type_family 'Instance Family',
                case when r.duration_seconds = 31536000 then '1-Year'
                when r.duration_seconds = 94608000 then '3-Year'
                end 'Term Length',
                r.payment_option 'Payment Option',
                r.total_hours 'Usage Hours',
                r.usage_rate 'Usage Rate',
                d.cost_on_demand 'On Demand Rate',
                r.total_on_demand_cost 'Total On Demand Cost',
                d.cost_recommend 'SP Hourly Commit',
                d.total_sp_cost 'Total SP Cost'
            FROM sp_recommendation r inner join sp_recommendation_detail d on r.id = d.spr_id where linked_account = '{:0>12}' and bill_period = '{}'""".format(linkedaccount,str(date)), have_result=True)
            
            if res['success'] and len(res['result'])>0:
            
                df = pd.DataFrame(res['result'])
                filename = '{}.csv'.format(int(linkedaccount))
                folder = 'sp_report/{}'.format(file_date)
                if not os.path.exists(folder):
                    os.system("mkdir {}".format(folder))
                fullname = os.path.join(folder, filename)
                df.to_csv(fullname, encoding='utf-8', index=False)
                print("LinkedAccounted:{} , report generated!!!".format(linkedaccount))
            else:
                print("LinkedAccounted:{} , no report!!!".format(linkedaccount))
        except Exception as e:
            print("Error!!!", e)
            continue

if __name__ == "__main__":
    print("==========開始初始化資料庫==========")
    init_db.init_data(backup_file_name,database_name)
    print("==========結束初始化資料庫==========")
    print("==========開始產生SP報告==========")
    generate_sp_report()
    print("==========結束產生SP報告==========")
