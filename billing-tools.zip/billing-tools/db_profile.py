import numpy as np
import pandas as pd
import getopt
import sys
from lib.db import DB
from pandas_profiling import ProfileReport

db = DB(database='ecloud',endpoint='main')

def generate_db_profiling(table):
    res = db.execute("""SELECT * FROM {table_name}""".format(table_name=table), have_result=True)['result']
    df = pd.DataFrame(
        res
    )
    profile = ProfileReport(df, title='{table_name} Profiling Report'.format(table_name=table), explorative=True)
    profile.to_file("DB-profiling/{table_name}.html".format(table_name=table))

if __name__ == "__main__":
    argv = sys.argv[1:]
    table_list = None
    help_text = """
===============================================
CLI     : python db_profile.py -t <table name>
Example : python db_profile.py -t bill_customer,bill_master
===============================================
"""
 
    try:
      opts, args = getopt.getopt(argv,"ht:")
    except getopt.GetoptError as e:
        print(help_text)
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print(help_text)
            sys.exit()
        elif opt in ("-t"):
            table_list = arg.split(',')
        else:
            print(help_text)
            sys.exit()
    if table_list is None:
        print(help_text)
        exit()

    for table in table_list:
        generate_db_profiling(table)