import boto3
import time
import datetime
from lib.db import DB
db = DB(endpoint='main',database='ecloud_tools')
res = db.execute("select account_no from bill_payer_account where hide = 'n' order by id",have_result=True)['result']

glue_client = boto3.client('glue')
athena_client = boto3.client('athena')

def create_crawler(crawlerName,role,databaseName,description,s3TargetPath):
    response = glue_client.create_crawler(
        Name=crawlerName,
        Role=role,
        DatabaseName=databaseName,
        Description=description,
        Targets={
            'S3Targets': [
                {
                    'Path': s3TargetPath,
                    'Exclusions': [
                    ]
                },
            ]
        },
        SchemaChangePolicy={
            'UpdateBehavior': 'UPDATE_IN_DATABASE',
            'DeleteBehavior': 'DELETE_FROM_DATABASE'
        }
        #,Configuration='{ "Version": 1.0, "CrawlerOutput": { "Partitions": { "AddOrUpdateBehavior": "InheritFromTable" } } }'
    )

def start_crawler(crawlerName):
    response = glue_client.start_crawler(
        Name=crawlerName
    )

def get_table(databaseName,payeraccountid):
    return glue_client.get_table(DatabaseName=databaseName,Name=payeraccountid)['Table']

def update_table_schema(origin_table):
    old_table = origin_table
    field_names = [
          "Name",
          "Description",
          "Owner",
          "LastAccessTime",
          "LastAnalyzedTime",
          "Retention",
          "StorageDescriptor",
          "PartitionKeys",
          "ViewOriginalText",
          "ViewExpandedText",
          "TableType",
          "Parameters"
        ]
    new_table = dict()
    for key in field_names:
        if key in old_table:
            new_table[key] = old_table[key]

    count = 0
    for col in new_table['StorageDescriptor']['Columns']:
        # print(col)
        if 'resourcetags' in col['Name']:
            count+=1
            col['Name'] = f"{col['Name']}_{count}"
        if  col['Type'] is not 'string':
            col['Type'] = "string"

    new_table['StorageDescriptor']['SerdeInfo']['SerializationLibrary'] = 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
    glue_client.update_table(DatabaseName='accounting',TableInput=new_table)

def get_crawler_status(crawlerName):
    return glue_client.get_crawler(Name=crawlerName)['Crawler']['State']

def run_glue(res):
    print(f"Start Time : {datetime.datetime.today()}")
    for i in res:
        payeraccountid = i['account_no']
        crawlerName = f"{payeraccountid}_Crawler"
        role = "AWSGlueForAccounting"
        databaseName = "accounting"
        description = "Crawler for generated payeraccount schema"
        s3TargetPath = f"s3://cur-compare/{payeraccountid}/"
        try:
            print(f"----------------------------{payeraccountid}----------------------------")
            # create_crawler(crawlerName,role,databaseName,description,s3TargetPath)
            start_crawler(crawlerName)
            print('Wait the crawler ready...')
            while get_crawler_status(crawlerName) != "READY":
                time.sleep(1)
            print('Get table schema...')
            origin_table = get_table(databaseName,payeraccountid)
            print('Update table schema...')
            update_table_schema(origin_table)
            print(f'{payeraccountid}:Done')
        except Exception as e:
            print(f'{payeraccountid}:Exception')
            print('/////////////////////Exception MSG///////////////////')
            print(e)
            print('/////////////////////Exception MSG///////////////////')
            continue
    print(f"End Time : {datetime.datetime.today()}")

def generate_query_for_athena():
    query_template = """select "LinkAccountID" ,"UnblendedCost" from ({})"""
    sub_query_template = """(select 
                            "lineItem/UsageAccountId" as LinkAccountID,
                            round(sum("lineItem/UnblendedCost"),4) as UnblendedCost  
                    from "accounting"."{}"
                    where "lineItem/LineItemType" not in ('Credit','Refund')
                    GROUP BY "lineItem/UsageAccountId")"""
    sub_query = ''
    final_query = ''
    count = 0
    for i in res:
        count +=1
        if count is not len(res):
            sub_query += sub_query_template.format(i['account_no'])+"UNION"
        else:
            sub_query += sub_query_template.format(i['account_no'])

        final_query = query_template.format(sub_query)
    return str(final_query)

def run_athena():
    print(f"Start Time : {datetime.datetime.today()}")
    try:
        query = generate_query_for_athena()
        response = athena_client.start_query_execution(
            QueryString=query,
            # ClientRequestToken='string',
            QueryExecutionContext={
                'Database': 'accounting'
            },
            ResultConfiguration={
                'OutputLocation': 's3://cur-stage/athena/'
            }
        )
        print(response)
    except Exception as e:
        print(e)
    print(f"End Time : {datetime.datetime.today()}")


run_glue([{'account_no':'601204252306'}])
# a = get_table('accounting','742095137571')
# update_table_schema(a)
# start_crawler('742095137571_Crawler')

