import getopt
import sys
from lib.db import DB
from datetime import datetime, timedelta
from lib import init_db
import csv
import requests
import json
from bs4 import BeautifulSoup

now_hour = datetime.now().hour+8
if now_hour < 11:
    init_date = (datetime.today() - timedelta(1)).strftime('%Y-%m-%d')
else:
    init_date = datetime.today().strftime('%Y-%m-%d')
backup_file_name = 'init_maindb_{}_no_bill_item.sql'.format(init_date)
database_name = 'ecloud_tools'
db = DB(database=database_name,endpoint='main')

# Get the session & billa (requried to login)
def get_init_session():

    endpoint = "https://service.ecloudvalley.com/bill_login.php"
    response = requests.get(endpoint)
    
    soup = BeautifulSoup(response.text, "html.parser") # parse the html response with bs

    session = soup.find("input", {"name": "session"}).get('value')  # get the initial session
    billa = soup.find("input", {"name": "billa"}).get('value')  # get the initial billa

    return [session, billa, response.cookies]

# Get the session after login to hit the api
def get_login_session(init_session, username, password):
    
    endpoint = "https://service.ecloudvalley.com/bill_login.php?login"
    headers = {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}
    cookies = init_session[2]
    login_data = {
        "session": init_session[0],
        "billa": init_session[1],
        "billb": username,
        "billc": password
    }

    response = requests.post(url=endpoint, headers=headers, cookies=cookies, data=login_data)

    if not response.cookies:
        print("[ERROR] Invalid Authentication. Please check username/password given is correct.")
        sys.exit()

    return cookies

def get_ri_suggestion_data(ri_condition, cookies):

    endpoint = "https://service.ecloudvalley.com/api/aws/reserved_instance/get_suggestion_report.php"
    headers = {"Content-type": "application/x-www-form-urlencoded; charset=UTF-8"}
    response = None
    try:
        response = requests.post(url=endpoint, headers=headers, cookies=cookies, data=ri_condition,)
    except requests.exceptions.HTTPError as HTTPError:
        print("Http Error:", HTTPError)
    
    return response

def gen_report(bill_period, lease_contract_length, offering_class, purchase_option, service, account_id, cookies):
    csv_header = ['Region', 'Suggested Quantity', 'Instance Type', 'Product Description', 'Pre-installed Software',
                  'Tenancy', 'On-Demand Cost', 'Fixed Price', 'Usage Price', 'Monthly Saving', 'Annual Cost Saving']
    ri_condition = {
        'bill_period': bill_period,
        'account_id': account_id,
        'lease_contract_length': lease_contract_length,
        'offering_class': offering_class,
        'purchase_option': purchase_option,
        'service': service
    }
    response = get_ri_suggestion_data(ri_condition, cookies)
    response_text = json.loads(response.text)
    if "error" in response_text:
        print("[ERROR] Invalid Authorization. Please check the system configuration.")
        sys.exit()
    
    ri_data = response.json()['data']
    if len(ri_data)>0:
        data_file = open(f'/var/www/tools/ri_report/{account_id}.csv', 'w')
        csv_writer = csv.writer(data_file)

        count = 0
        for info in ri_data:
            del info['linkedaccountid']
            info['monthly_saving'] = str(round(float(info['monthly_saving'])*100,2))+'%'
            if count == 0:
                # Writing headers of CSV file
                csv_writer.writerow(csv_header)
                count += 1

            # Writing data of CSV file
            csv_writer.writerow(info.values())

        data_file.close()
    else:
        print(f'{account_id} no data !')


if __name__ == "__main__":
    argv = sys.argv[1:]
    bill_period = None
    lease_contract_length = None
    offering_class = None
    purchase_option = None
    service = None
    linkedaccount_list = []
    username = None
    password = None
    help_text = """＊ All parameters are case-insensitive ＊
<== service ==>
'EC2':'Amazon Elastic Compute Cloud',
'RDS':'Amazon Relational Database Service',
'ElASTICCACHE':'Amazon ElastiCache',
'REDSHIFT':'Amazon Redshift',
'ElASTICSEARCH':'Amazon Elasticsearch Service'

<== payment option ==>
'NO':'No Upfront',
'PARTIAL':'Partial Upfront',
'ALL':'All Upfront'

<== RI Term ==>
1 : 1 year
3 : 3 year

<== offering class ==>
convertible
standard
===============================================================
CLI     : python ri_recommendation_report.py -l <account_id1,account_id2> -p <yyyy/mm> -s <service> -t <RI Term> -u <payment option> -o <offering class> --username=<altas-username> --password=<atlas-password>
Example : python ri_recommendation_report.py -l 204930765275 -p 2020/09 -s EC2 -t 1 -u no -o convertible --username=ecv-admin@ecloudvalley.com --password=ecv6689
===============================================================
CLI     : python ri_recommendation_report.py -c <cno1,cno2> -p <yyyy/mm> -s <service> -t <RI Term> -u <payment option> -o <offering class> --username=<altas-username> --password=<atlas-password>
Example : python ri_recommendation_report.py -c c0123 -p 2020/09 -s EC2 -t 1 -u no -o convertible --username=ecv-admin@ecloudvalley.com --password=ecv6689
===============================================================
"""

    try:
        opts, args = getopt.getopt(argv, "hc:l:p:s:t:u:o:", ['username=', 'password='])
    except getopt.GetoptError as e:
        print(help_text)
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-h':
            print(help_text)
            sys.exit()
        elif opt in ("-l"):
            linkedaccount_list = [int(i) for i in arg.split(',')]
        elif opt in ("-c"):
            cno_list = [x.upper() for x in arg.split(',')]
            for cno in cno_list:
                print("==========開始初始化資料庫==========")
                init_db.init_data(backup_file_name, database_name)
                print("==========結束初始化資料庫==========")
                results = db.execute("""SELECT linkedaccountid From bill_customer where cno = '{}' and hide = 'n'""".format(cno), have_result=True)['result']
                for result in results:
                    linkedaccount_list.append(int(result['linkedaccountid']))
        elif opt in ("-p"):
            bill_period = arg
        elif opt in ("-s"):
            service_dict = {
                'EC2': 'Amazon Elastic Compute Cloud',
                'RDS': 'Amazon Relational Database Service',
                'ElASTICCACHE': 'Amazon ElastiCache',
                'REDSHIFT': 'Amazon Redshift',
                'ElASTICSEARCH': 'Amazon Elasticsearch Service'
            }
            service = service_dict[arg.upper()]
        elif opt in ("-t"):
            lease_contract_length = arg
        elif opt in ("-u"):
            purchase_option_dict = {
                'NO': 'No Upfront',
                'PARTIAL': 'Partial Upfront',
                'ALL': 'All Upfront'
            }
            purchase_option = purchase_option_dict[arg.upper()]
        elif opt in ("-o"):
            offering_class = arg
        elif opt in ('--username'):
            username = arg
        elif opt in ("--password"):
            password = arg
        else:
            print(help_text)
            sys.exit()

    init_session = get_init_session()
    login_session = get_login_session(init_session, username, password)

    if bill_period is None or lease_contract_length is None or offering_class is None or purchase_option is None or service is None or len(linkedaccount_list) == 0:
        print(help_text)
        exit()

    print("==========開始產生Report==========")
    for account_id in linkedaccount_list:
        gen_report(bill_period, lease_contract_length, offering_class,
                   purchase_option, service, account_id, login_session)
    print("==========結束產生Report==========")
