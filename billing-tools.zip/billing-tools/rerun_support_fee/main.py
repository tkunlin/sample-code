## 計算因 eshield 而重新計算的 support partnerled

from support_partner_led import SupportPartnerLed

import os
import getopt
import sys


def main(bill_period: str, linkedaccount_list_str: str) -> None:
    spl = SupportPartnerLed(bill_period)
    linkedaccount_list = linkedaccount_list_str.split(",")
    spl.process(linkedaccount_list)


if __name__ == "__main__":
    
    def help_text():
        print("""
python3 main.py -p YYYY/MM -l 12345678912,23456678923....
        """)
        exit()

    bill_period = None
    linkedaccount_list_str = None
    
    argv = sys.argv[1:]
    try:
      opts, args = getopt.getopt(argv,"hp:l:")
    except getopt.GetoptError as e:
        help_text()
    for opt, arg in opts:
        if opt == '-h':
            help_text()
        elif opt in ("-p"):
            bill_period = arg
        elif opt in ("-l"):
            linkedaccount_list_str = arg
        else:
            help_text()
    
    if all([bill_period, linkedaccount_list_str]):
        # print(bill_period, linkedaccount_list_str)
        print("==============================================================")
        main(bill_period, linkedaccount_list_str)
    else:
        help_text()