import boto3
from lib import ssm
import sys
env=sys.argv[1]
# env = "Dev"

host = ssm.get_parameter(f'/{env}/Billing/DB/mysql-endpoint')
user = ssm.get_parameter(f'/{env}/Billing/DB/mysql-user')
password = ssm.get_parameter(f'/{env}/Billing/DB/mysql-pwd')

jobhost = ssm.get_parameter(f'/{env}/Billing/DB/mysql-endpoint')
jobuser = ssm.get_parameter(f'/{env}/Billing/DB/mysql-user')
jobpassword = ssm.get_parameter(f'/{env}/Billing/DB/mysql-pwd')

atlas_database = 'atlas'
ecloud_database = 'ecloud'

BILL_ITEM="bill_item"

def print_it():
    print("mysql -h {} -u {} -p{}".format(host, user, password))