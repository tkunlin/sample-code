# ================================================================================= #
# Copyright 2021 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #
try:
    strCode = "Y29weXJpZ2h0IG9mIGVjbG91ZHZhbGxleS1UU0Q="
except:
    print('Y29weXJpZ2h0IG9mIGVjbG91ZHZhbGxleS1UU0Q=')


def generate_insert_list_sql(table,mlist):
    # get format
    if len(mlist) == 0:
        return "select %s", ("No Data",)
    obj = mlist[0]
    temp_column_list = list(obj.keys())
    column_list = ["`{}`".format(item) for item in temp_column_list]
    #columns = key, key ,...
    columns = ', '.join(column_list)
    #values_holder = (%s , %s, %s, ...) 
    values_holder = "(" + ", ".join(['%s'] * len(obj)) + ")"
    #placeholders = values_holder, values_holder, values_holder ...
    placeholders = ", ".join([values_holder] * len(mlist))
    values = tuple()
    for obj in mlist:
        values = values + tuple(obj.values())
    sql = "INSERT INTO %s ( %s ) VALUES  %s " % (table, columns, placeholders)
    # print(values)
    return sql, values