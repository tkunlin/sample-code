# Re-Run support fee
重新計算 support partnerled
## Situation
當有非業務的特殊調整進而影響 support 的資料時，在 `stage` 機上模擬調整完的資料後，跑這個 script

## Usage

```bash
cd rerun_support_fee
python3 main.py -p {BILL_PERIOD} -l {LINKEDACCOUNT_LIST}

## 參數說明
BILL_PERIOD: 出帳月份
LINKEDACCOUNTID_LIST: 影響到的 linkedaccountid, 用 `,` 隔開

## example
python3 main.py -p 2021/12 -l 123456789,1234567890,51651351351
```