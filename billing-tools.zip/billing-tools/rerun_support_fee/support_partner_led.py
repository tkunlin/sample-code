# ================================================================================= #
# Copyright 2021 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #
try:
    strCode = "Y29weXJpZ2h0IG9mIGVjbG91ZHZhbGxleS1UU0Q="
except:
    print('Y29weXJpZ2h0IG9mIGVjbG91ZHZhbGxleS1UU0Q=')

import datetime
import time
import json

from lib import config
from lib.utils import generate_insert_list_sql
from lib.db import DB




"""
1. For Now Hourly is not avalible
"""


class SupportPartnerLed:
    def __init__(self, bill_period):
        self.proddb = DB(config.ecloud_database, endpoint = "main")
        self.bill_item_table_name = config.BILL_ITEM
        self.bill_period = bill_period
        

    def generate_billing_obj(self, billing_list):
        bill = {}
        for item in billing_list:
            if item['cno'] not in bill:
                obj = {
                    "cno":item["cno"],
                    "cid":[],
                    "linkedaccountid":[],
                    "payeraccountid":[],
                    "support_pl_cost":[],
                    "min_charge":[],
                    "pl": [],
                    "pid":[],
                    "total": [],
                    'product_name':[],
                    'description':[]
                }
            
            if item['pl'] == 'y':
                obj['pid'].append(19)
                obj['product_name'].append( "AWS Support (Business)")
                obj['description'].append( "AWS Business Support")
            elif item['pl'] in ('e', 'f'):
                obj['pid'].append(270)
                obj['product_name'].append( "AWS Support (Enterprise)")
                obj['description'].append( "AWS Enterprise Support")
            obj['pl'].append(item['pl'])
            obj['total'].append(float(item["totalmoney"]))
            obj['cid'].append(item["id"])
            obj['linkedaccountid'].append(item["linkedaccountid"].zfill(12))
            obj['payeraccountid'].append(item["payeraccountid"])
            obj['min_charge'].append(item["min_charge"])
            obj['support_pl_cost'].append( self.calc_support_fee(item['pl'], float(item["totalmoney"]), float(item["fixed_rate"]), float(item["min_charge"]))['support_fee'])
            # obj['support_pl_cost'].append( self.__calc_support_fee(item['pl'], float(item["totalmoney"]), float(item["fixed_rate"]), 0)['support_fee'])
            bill[item['cno']] = obj
        return bill
    

    def fix_min_charge(self, billing_list):
        for cno in billing_list:
            obj = billing_list[cno]
            min_charge = obj['min_charge'][-1]
            total_support = sum(obj['support_pl_cost'])
            if min_charge > total_support:
                billing_list[cno]['support_pl_cost'][-1] += (min_charge - total_support)
        return billing_list
            

    def get_billing_list(self, linkedaccount_list):
        linkedaccount_list = [ str(int(l)) for l in linkedaccount_list]

        sql = """SELECT cno, id, payeraccountid, linkedaccountid, pl, fixed_rate, min_charge, SUM(UsageAmount) totalmoney FROM 
        ( SELECT BC.id, BC.payeraccountid, BC.linkedaccountid, BC.cno, BC.business_support_pl pl, BC.business_support_rate fixed_rate, BC.business_support_mincharge min_charge,
        CASE WHEN (UnitPrice > 0 OR DOP ='y') THEN ROUND(UnitPrice*UsageQuantity, 2) 
        ELSE ROUND(TotalCost, 2) END UsageAmount FROM bill_customer BC, {} BI
        WHERE BC.business_support_pl in ('y', 'f', 'e') AND BC.id = BI.bill_customer 
        AND BI.bill_product not in (18, 19, 270)
        AND BI.bill_period = '{}' AND BI.TotalCost >= 0 AND BI.hide = 'n' 
        AND ((unitprice ='' AND totalcost > 0.005) OR unitprice*usagequantity > 0.005 OR dop='y')) a 
    GROUP BY cno, id,payeraccountid, linkedaccountid, pl, fixed_rate, min_charge 
    HAVING linkedaccountid in ('{}')
    ORDER BY cno desc, totalmoney
    ;""".format(self.bill_item_table_name, self.bill_period, "','".join(linkedaccount_list))

        res = self.proddb.execute(sql, have_result=True)
        if not res['success']: 
            print(sql)
            raise Exception(res['err'])
        return res['result']


    def calc_support_fee(self, pl, amount, fixed_rate, min_charge):
        support_obj ={
            "support_fee" : 0
        }
        if pl == 'y':
            level_list = [
                {
                    "min":0,
                    "max":10000,
                    "persent":0.1
                },
                {
                    "min":10000,
                    "max":80000,
                    "persent":0.07
                },
                {
                    "min":80000,
                    "max":250000,
                    "persent":0.05
                },
                {
                    "min":250000,
                    "max":100000000,
                    "persent":0.03
                }
            ]
        elif pl == 'e':
            level_list = [
                {
                    "min":0,
                    "max":150000,
                    "persent":0.1
                },
                {
                    "min":150000,
                    "max":500000,
                    "persent":0.07
                },
                {
                    "min":500000,
                    "max":1000000,
                    "persent":0.05
                },
                {
                    "min":1000000,
                    "max":100000000,
                    "persent":0.03
                }
            ]
        elif pl == 'f':
            support_obj['support_fee'] = fixed_rate * amount
            level_list = []

        for index,level in enumerate(level_list):
            if amount > level["min"]:
                if amount > level["max"]:
                    support_obj["support_fee"] += ( level["max"] - level["min"] ) * level["persent"]
                    support_obj[str(level["persent"])] = level["max"] - level["min"]
                else:
                    support_obj["support_fee"] += (amount - level["min"]) * level["persent"]
                    support_obj[str(level["persent"])] = amount - level["min"]
        if float(min_charge) >= support_obj["support_fee"]:
            support_obj["support_fee"] = float(min_charge)
        return support_obj


    def process(self, linkedaccount_list):
        billing_list = self.get_billing_list(linkedaccount_list)
        for item in billing_list:
            # update bill_item set UnitPrice =  '6103.14'  where bill_period = '2021/08' and bill_customer = 3724  and bill_product = 270;
            bill_product = 270 if item['pl'] in ('f', 'e') else 19
            support_fee = self.calc_support_fee(item['pl'], float(item["totalmoney"]), float(item["fixed_rate"]), float(item["min_charge"]))['support_fee']
            support_fee = round(support_fee, 4)
            sql = f"UPDATE bill_item SET UnitPrice = '{support_fee}' WHERE bill_period = '{self.bill_period}' AND bill_customer = {item['id']} and bill_product = {bill_product} and billing_entity = 'AWS-Ecloud-SPL';"
            print(sql)
        

