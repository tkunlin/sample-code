import datetime
import time
import json

from lib import config
from lib.utils import generate_insert_list_sql
from lib.db import DB
import pandas as pd
import sys
import getopt
jobdb = DB(endpoint="main", database="ecloud")
# bill_period='2023/01'
bill_period=sys.argv[2]
resold_shield_payeraccount_list_str = sys.argv[3]
payeraccount_list = resold_shield_payeraccount_list_str.split(",")
payeraccount_list = [ str(int(l)) for l in payeraccount_list]
resold_payeraccount_list = "','".join(payeraccount_list)
# print(resold_payeraccount_list)
# print(bill_period)
# print(jobdb)
def get_resold_billing_list(jobdb,bill_period,resold_payeraccount_list):
    sql = f"""SELECT a.cno, a.id, a.payeraccountid, a.linkedaccountid, SUM(a.UsageAmount) totalmoney, bal.contract_type,
                CASE WHEN bal.contract_type = 1 THEN 15000
                    WHEN bal.contract_type = 2 THEN 5500
                END es_min_rev,
                bai.revenue_min_charge, bai.revenue_discount_rate,bal.is_include_payer_fee 
                FROM
                (SELECT BC.id,BC.payeraccountid,BC.linkedaccountid,BC.cno,
                CASE WHEN (UnitPrice > 0
                    OR DOP = 'y') THEN ROUND(UnitPrice * UsageQuantity,2)
                    ELSE ROUND(TotalCost,2)
                    END UsageAmount
                FROM bill_customer BC, bill_item BI
                WHERE 1=1
                -- AND LEFT(BC.cno,1) = 'C'
                AND BC.hide = 'n'
                AND BC.id = BI.bill_customer
                AND BI.bill_product NOT IN (18, 19, 270)
                AND BI.bill_period = '{bill_period}'
                AND BI.TotalCost >= 0
                AND BI.hide = 'n'
                AND ((unitprice = ''
                AND totalcost > 0.005) OR unitprice * usagequantity > 0.005 OR dop = 'y')) a
                INNER JOIN bill_awscontract_payer bap 
                ON bap.PayerAccountId = a.payeraccountid
                INNER JOIN (
                SELECT * FROM bill_awscontract_list WHERE status = 1) bal
                ON bap.list_id = bal.id
                INNER JOIN bill_awscontract_info bai
                ON bap.list_id = bai.list_id
                WHERE bai.status = 1
                GROUP BY cno, id, payeraccountid, linkedaccountid
                HAVING 
                -- totalmoney > 0
                payeraccountid IN ('{resold_payeraccount_list}')
                ORDER BY cno DESC,totalmoney;
            """

    res = jobdb.execute(sql, have_result=True)
    res_df =pd.DataFrame(res['result'])
    # print(res_df)
    if not res['success']: 
        print(sql)
        raise Exception(res['err'])
    return res_df


#計算Payer根據原始使用量按照Resold及On-ramp邏輯計算後的support fee
def calc_resold_on_ramp_shield_support_fee(df):
    amount = df['sum_totalmoney']
    es_min_charge = df['es_min_rev']
    contract_type = df['contract_type']
    support_obj ={
        "support_fee" : 0
        }
    if contract_type == '1':
        level_list = [
            {
                "min":0,
                "max":150000,
                "persent":0.1
            },
            {
                "min":150000,
                "max":500000,
                "persent":0.07
            },
            {
                "min":500000,
                "max":1000000,
                "persent":0.05
            },
            {
                "min":1000000,
                "max":100000000,
                "persent":0.03
            }
        ]
    elif contract_type == '2':
        support_obj["support_fee"] = amount * 0.1
        if support_obj["support_fee"] > es_min_charge:
            support_obj["support_fee"] = support_obj["support_fee"]
        else:
            support_obj["support_fee"] = es_min_charge
            level_list=[]
    for index,level in enumerate(level_list):
        if amount > level["min"]:
            if amount > level["max"]:
                support_obj["support_fee"] += ( level["max"] - level["min"] ) * level["persent"]
                support_obj[str(level["persent"])] = level["max"] - level["min"]
            else:
                support_obj["support_fee"] += (amount - level["min"]) * level["persent"]
                support_obj[str(level["persent"])] = amount - level["min"]
        if support_obj["support_fee"] < es_min_charge:
            support_obj["support_fee"] = es_min_charge
        else:
            support_obj["support_fee"] = support_obj["support_fee"]
    return support_obj["support_fee"]

def real_discount_rate(df):
    payer_discount_rate = float(df['revenue_discount_rate'])
    real_discount_rate = df['ori_sup_fee'] * df['rev_ratio'] * (1+payer_discount_rate)
    return real_discount_rate

def generate_sql(df):
    row_count = len(df.index)
    # print(len(df.index))
    for item in range(row_count):
        linkedaccountid = df['linkedaccountid'].values.tolist()[item]
        real_sup_fee = round(float(df['real_sup_fee_includ_discount'].values.tolist()[item]),4)
        sql=f"UPDATE bill_item SET unitprice={real_sup_fee} WHERE bill_period = '{bill_period}' AND linkedaccountid = {linkedaccountid} AND bill_product = 270 AND billing_entity = 'AWS-Ecloud-Resold';"
        print(sql)
 

def main(): 
    df = get_resold_billing_list(jobdb,bill_period,resold_payeraccount_list)
    if df.empty:
        print('Dataframe is empty')
    else:
        df['filter_col'] = df['cno'].str[:1]
        df_no_payer=df.loc[(df['filter_col'] == "C") & (df['is_include_payer_fee'] == 0)] #不包含payer使用金額
        df_include_payer=df.loc[df['is_include_payer_fee'] == 1] #包含payer使用金額
        if df_no_payer.empty:
            print('Exclude payer dataframe is empty')
        else:
            df_no_payer['sum_totalmoney'] = df_no_payer.groupby('payeraccountid')['totalmoney'].transform('sum')  #計算各linkedaccountid的sum_totalmoney for each payer
            df_no_payer['rev_ratio'] = df_no_payer['totalmoney'] / df_no_payer.groupby('payeraccountid')['totalmoney'].transform('sum')  #計算各linkedaccountid在Payer之下的收入占比
            df_no_payer['ori_sup_fee'] = df_no_payer.apply(calc_resold_on_ramp_shield_support_fee,axis=1) #新增各Payer原始的Support Fee
            df_no_payer['real_sup_fee_includ_discount'] = df_no_payer.apply(real_discount_rate,axis=1)  #計算各LinkedID的Real Support Fee
            print(df_no_payer)
            no_payer_sql = generate_sql(df_no_payer)
        if df_include_payer.empty:
            print('Include payer dataframe is empty')
        else:
            df_include_payer['sum_totalmoney'] = df_include_payer.groupby('payeraccountid')['totalmoney'].transform('sum')  #計算各linkedaccountid的sum_totalmoney for each payer
            df_include_payer['rev_ratio'] = df_include_payer['totalmoney'] / df_include_payer.groupby('payeraccountid')['totalmoney'].transform('sum')  #計算各linkedaccountid在Payer之下的收入占比
            df_include_payer['ori_sup_fee'] = df_include_payer.apply(calc_resold_on_ramp_shield_support_fee,axis=1) #新增各Payer原始的Support Fee
            df_include_payer['real_sup_fee_includ_discount'] = df_include_payer.apply(real_discount_rate,axis=1)  #計算各LinkedID的Real Support Fee
            print(df_include_payer)
            include_payer = generate_sql(df_include_payer)

if __name__ == "__main__":
    main()