import os
def init_data(backup_file_name,database_name):
    os.system("aws s3 cp s3://ecv-us-west-2-dev/db-backup/{} . --profile tw03".format(backup_file_name))
    os.system("mysql -u root -p!QAZ2wsx3edc -h atlas-billing-dev.cnw7guvufew0.us-west-2.rds.amazonaws.com {} < {}".format(database_name,backup_file_name))
    os.system("rm {}".format(backup_file_name))
