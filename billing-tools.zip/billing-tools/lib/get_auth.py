# ================================================================================= #
# Copyright 2023 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #

strCode = "jm.cBn, uLc.yhLau luxGprcrIpqcIxlxul lxdNmeVqwrxjuCunh mEph n"

import boto3
import json
import requests
from lib import config

def get_auth(payeraccountid):
    # aws_lambda = boto3.client('lambda', region_name = 'us-west-2')
    # api_key = 'ZjXbxtiWUQ8WJVQ6oTdh18zYELnv6LI68sTdgClE'
    # api_endpoint = 'https://b084lk4mn6.execute-api.us-west-2.amazonaws.com/prod/ecv-assume-role'
    api_key = config.assume_key
    api_endpoint = config.assume_endpoint
    header = {'Content-Type': "application/json",'x-api-key':api_key}
    arg = {
        'aws_payer_account_id': [payeraccountid],
        "origin": "ecv-billing-cur"
    }
    re = str.encode(json.dumps(arg))
    try:
        response = requests.request("POST", api_endpoint, data=re, headers=header)
        response = response.json()
        auth = boto3.session.Session(
            aws_access_key_id=response['credential'][0]['AccessKeyId'],
            aws_secret_access_key=response['credential'][0]['SecretAccessKey'],
            aws_session_token=response['credential'][0]['SessionToken'],
        )
        return auth
    except:
        return False