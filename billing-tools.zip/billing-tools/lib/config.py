# ================================================================================= #
# Copyright 2023 (c) eCloudvalley Digital Technology Co., Ltd. All Rights Reserved. #
# ================================================================================= #

strCode = "jm.cBn, uLc.yhLau luxGprcrIpqcIxlxul lxdNmeVqwrxjuCunh mEph n"

from lib import ssm
import os


env = 'Prod'

host = ssm.get_parameter(f'/{env}/Billing/DB/mysql-endpoint')
user = ssm.get_parameter(f'/{env}/Billing/DB/mysql-user')
password = ssm.get_parameter(f'/{env}/Billing/DB/mysql-pwd')

jobhost = ssm.get_parameter(f'/{env}/Billing/DB/mysql-endpoint')
jobuser = ssm.get_parameter(f'/{env}/Billing/DB/mysql-user')
jobpassword = ssm.get_parameter(f'/{env}/Billing/DB/mysql-pwd')

atlas_database = 'atlas'
ecloud_database = ssm.get_parameter(f'/{env}/Billing/DB/mysql-db')

assume_endpoint = ssm.get_parameter(f'/{env}/Billing/Lambda/AssumeRole/Api/Endpoint')
assume_key = ssm.get_parameter(f'/{env}/Billing/Lambda/AssumeRole/Api/Key')

s3_bill_invoice_bucket = ssm.get_parameter(f'/{env}/Billing/S3/invoice/bucket-name')

## TABLE
BILL_ITEM = "bill_item"
BILL_INVOICE = "bill_invoice_revenue"
BILL_CUSTOMER = "bill_customer"

DIRNAME=os.getcwd()

