How to run this:

$1 = uat / stage / prod

./update-version-for-sap-transform-taskdef.sh $1
